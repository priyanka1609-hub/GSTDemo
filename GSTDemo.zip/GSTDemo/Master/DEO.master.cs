﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;//using FoodSecurity.SqlserverData;
using System.Web.Security;

public partial class DEOMaster : System.Web.UI.MasterPage
{
    private const string AntiXsrfTokenKey = "__AntiXsrfToken";
    private const string AntiXsrfUserNameKey = "__AntiXsrfUserName";
    private string _antiXsrfTokenValue;

    Random randObj = new Random();
    Int32 UniqueRandomNumber = 0;

    protected void Page_Init(object sender, EventArgs e)
    {
        var requestCookie = Request.Cookies[AntiXsrfTokenKey];
        Guid requestCookieGuidValue;
        if (requestCookie != null && Guid.TryParse(requestCookie.Value, out requestCookieGuidValue))
        {
            _antiXsrfTokenValue = requestCookie.Value;

            Page.ViewStateUserKey = _antiXsrfTokenValue;
        }
        else
        {
            _antiXsrfTokenValue = Guid.NewGuid().ToString("N");
            Page.ViewStateUserKey = _antiXsrfTokenValue;
            var responseCookie = new HttpCookie(AntiXsrfTokenKey)
            {
                HttpOnly = true,
                Value = _antiXsrfTokenValue
            };
            if (FormsAuthentication.RequireSSL && Request.IsSecureConnection) responseCookie.Secure = true;
            Response.Cookies.Set(responseCookie);
        }
        Page.PreLoad += master_Page_PreLoad;
    }

    protected void master_Page_PreLoad(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ViewState[AntiXsrfTokenKey] = Page.ViewStateUserKey;
            ViewState[AntiXsrfUserNameKey] = Context.User.Identity.Name ?? String.Empty;
        }
        else
        {
            if ((string)ViewState[AntiXsrfTokenKey] != _antiXsrfTokenValue || (string)ViewState[AntiXsrfUserNameKey] != (Context.User.Identity.Name ?? String.Empty))
            {
                throw new InvalidOperationException("Validation of Anti-XSRF token failed.");
            }
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            UniqueRandomNumber = randObj.Next(1, 10000);
            Session["token"] = UniqueRandomNumber.ToString();
            this.csrftoken.Value = Session["token"].ToString();
        }

        else
        {
            if (((Request.Form["ctl00$csrftoken"] != null) && (Session["token"] != null)) && (Request.Form["ctl00$csrftoken"].ToString().Equals(Session["token"].ToString())))
            {
                //valid Page
            }
            else
            {
                Server.Transfer("~/Account/Login.aspx");
            }
        }

        if (Request.IsAuthenticated)
        {
            string usertype = "";

            if (!string.IsNullOrEmpty(Session["USER_TYPE"].ToString()))
            {
                usertype = Session["USER_TYPE"].ToString();
                if (usertype == "FSI")
                {
                    LblWelcome.Text = Session["LoginDetail"].ToString();
                    LblLastDateTime.Text = "Last login:" + Session["dtLastLOginDate"].ToString();
                    MenuSiteMapDataProvider.SiteMapProvider = "FSISiteMap";
                }
                else if (usertype == "DEO")
                {
                    LblWelcome.Text = Session["LoginDetail"].ToString();
                    LblLastDateTime.Text = "Last login:" + Session["dtLastLOginDate"].ToString();
                    if (Session["USERFLAG"].ToString() == "G")
                        MenuSiteMapDataProvider.SiteMapProvider = "DEOSiteMap";
                    else if (Session["USERFLAG"].ToString() == "P")
                        MenuSiteMapDataProvider.SiteMapProvider = "DEOPSiteMap";
                }
                else if (usertype == "MON")
                {
                    LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
                    LblLastDateTime.Text = "Last login:" + Session["dtLastLOginDate"].ToString();
                    MenuSiteMapDataProvider.SiteMapProvider = "MonSiteMap";
                }
                else if (usertype == "FSO")
                {
                    LblWelcome.Text = Session["LoginDetail"].ToString();
                    LblLastDateTime.Text = "Last login:" + Session["dtLastLOginDate"].ToString();
                    MenuSiteMapDataProvider.SiteMapProvider = "FSOSiteMap";
                }
                else if (usertype == "ADMIN")
                {
                    //LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
                    //LblLastDateTime.Text = "Last login:" + Session["dtLastLOginDate"].ToString();
                    //MenuSiteMapDataProvider.SiteMapProvider = "ADMINSiteMap";

                    LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
                    LblLastDateTime.Text = "Last login:" + Session["dtLastLOginDate"].ToString();
                    MenuSiteMapDataProvider.SiteMapProvider = "NICADMINSiteMap";
                }

                else if (usertype == "PADMIN")
                {
                    LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
                    LblLastDateTime.Text = "Last login:" + Session["dtLastLOginDate"].ToString();
                    MenuSiteMapDataProvider.SiteMapProvider = "PrivateSiteMap";
                }

                else if (usertype == "NICADMIN")
                {
                    LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
                    LblLastDateTime.Text = "Last login:" + Session["dtLastLOginDate"].ToString();
                    MenuSiteMapDataProvider.SiteMapProvider = "NICADMINSiteMap";
                }
                else if (usertype == "UIDAI")
                {
                    LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
                    LblLastDateTime.Text = "Last login:" + Session["dtLastLOginDate"].ToString();
                    MenuSiteMapDataProvider.SiteMapProvider = "UIDAISiteMap";
                }
                else if (usertype == "AC")
                {
                    LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
                    LblLastDateTime.Text = "Last login:" + Session["dtLastLOginDate"].ToString();
                    MenuSiteMapDataProvider.SiteMapProvider = "ACSiteMap";
                }

                else if (usertype == "VIG")
                {
                    LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
                    LblLastDateTime.Text = "Last login:" + Session["dtLastLOginDate"].ToString();
                    MenuSiteMapDataProvider.SiteMapProvider = "VigilanceSiteMap";
                }
                else if (usertype == "ONLINEADMIN")
                {
                    LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
                    LblLastDateTime.Text = "Last login:" + Session["dtLastLOginDate"].ToString();
                    MenuSiteMapDataProvider.SiteMapProvider = "OnlineAdminSiteMap";
                }
                else if (usertype == "GUEST")
                {
                    LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
                    LblLastDateTime.Text = "Last login:" + Session["dtLastLOginDate"].ToString();
                    MenuSiteMapDataProvider.SiteMapProvider = "GUESTSiteMap";
                }

            }
            else
            {
                Server.Transfer("~/Account/Login.aspx");
            }

        }
        else
        {
            Server.Transfer("~/Account/Login.aspx");
        }
    }
}
