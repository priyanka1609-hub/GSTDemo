﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;//using FoodSecurity.SqlserverData;
using System.Web.Security;

public partial class DEOMaster : System.Web.UI.MasterPage
{
    private const string AntiXsrfTokenKey = "__AntiXsrfToken";
    private const string AntiXsrfUserNameKey = "__AntiXsrfUserName";
    private string _antiXsrfTokenValue;


    protected void Page_Init(object sender, EventArgs e)
    {
        var requestCookie = Request.Cookies[AntiXsrfTokenKey];
        Guid requestCookieGuidValue;
        if (requestCookie != null && Guid.TryParse(requestCookie.Value, out requestCookieGuidValue))
        {
            _antiXsrfTokenValue = requestCookie.Value;

            Page.ViewStateUserKey = _antiXsrfTokenValue;
        }
        else
        {
            _antiXsrfTokenValue = Guid.NewGuid().ToString("N");
            Page.ViewStateUserKey = _antiXsrfTokenValue;
            var responseCookie = new HttpCookie(AntiXsrfTokenKey)
            {
                HttpOnly = true,
                Value = _antiXsrfTokenValue
            };
            if (FormsAuthentication.RequireSSL && Request.IsSecureConnection) responseCookie.Secure = true;
            Response.Cookies.Set(responseCookie);
        }
        Page.PreLoad += master_Page_PreLoad;
    }

    protected void master_Page_PreLoad(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ViewState[AntiXsrfTokenKey] = Page.ViewStateUserKey;
            ViewState[AntiXsrfUserNameKey] = Context.User.Identity.Name ?? String.Empty;
        }
        else
        {
            if ((string)ViewState[AntiXsrfTokenKey] != _antiXsrfTokenValue || (string)ViewState[AntiXsrfUserNameKey] != (Context.User.Identity.Name ?? String.Empty))
            {
                throw new InvalidOperationException("Validation of Anti-XSRF token failed.");
            }
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Request.IsAuthenticated)
        //{
        //    string usertype = "";

        //    if (!string.IsNullOrEmpty(Session["USER_TYPE"].ToString()))
        //    {
        //        usertype = Session["USER_TYPE"].ToString();
        //        if (usertype == "FSI")
        //        {
        //            LblWelcome.Text = Session["LoginDetail"].ToString();
        //            MenuSiteMapDataProvider.SiteMapProvider = "FSISiteMap";
        //        }
        //        else if (usertype == "DEO")
        //        {
        //            LblWelcome.Text = Session["LoginDetail"].ToString();
        //            if (Session["USERFLAG"].ToString() == "G")
        //                MenuSiteMapDataProvider.SiteMapProvider = "DEOSiteMap";
        //            else if (Session["USERFLAG"].ToString() == "P")
        //                MenuSiteMapDataProvider.SiteMapProvider = "DEOPSiteMap";
        //        }
        //        else if (usertype == "MON")
        //        {
        //            LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
        //            MenuSiteMapDataProvider.SiteMapProvider = "MonSiteMap";
        //        }
        //        else if (usertype == "FSO")
        //        {
        //            LblWelcome.Text = Session["LoginDetail"].ToString();
        //            MenuSiteMapDataProvider.SiteMapProvider = "FSOSiteMap";
        //        }
        //        else if (usertype == "ADMIN")
        //        {
        //            LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
        //            MenuSiteMapDataProvider.SiteMapProvider = "ADMINSiteMap";
        //        }

        //        else if (usertype == "PADMIN")
        //        {
        //            LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
        //            MenuSiteMapDataProvider.SiteMapProvider = "PrivateSiteMap";
        //        }

        //        else if (usertype == "NICADMIN")
        //        {
        //            LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
        //            MenuSiteMapDataProvider.SiteMapProvider = "NICADMINSiteMap";
        //        }
        //        else if (usertype == "UIDAI")
        //        {
        //            LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
        //            MenuSiteMapDataProvider.SiteMapProvider = "UIDAISiteMap";
        //        }
        //        else if (usertype == "AC")
        //        {
        //            LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
        //            MenuSiteMapDataProvider.SiteMapProvider = "ACSiteMap";
        //        }

        //        else if (usertype == "VIG")
        //        {
        //            LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
        //            MenuSiteMapDataProvider.SiteMapProvider = "VigilanceSiteMap";
        //        }
        //        else if (usertype == "ONLINEADMIN")
        //        {
        //            LblWelcome.Text = Session["UC_USER_NAME"].ToString().ToUpper();
        //            MenuSiteMapDataProvider.SiteMapProvider = "OnlineAdminSiteMap";
        //        }
        //    }
        //    else
        //    {
        //        Server.Transfer("~/Account/Login.aspx");
        //    }
                   
        //}
        //else
        //{
        //    Server.Transfer("~/Account/Login.aspx");
        //}
    }
}
