﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using GstDelhi.PostgresData;//using FoodSecurity.SqlserverData;
//using System.Data.SqlClient;
using System.Text;
using System.Web.Security;
using GstDelhi.PostgresData;
using Npgsql;
using System.Globalization;

public partial class NewUserCreation : System.Web.UI.Page
{

  

    protected void Page_Load(object sender, EventArgs e)
    {
        if ((!String.Equals(Session["USER_TYPE"].ToString().Trim(), "NICADMIN")) && (!String.Equals(Session["USER_TYPE"].ToString().Trim(), "ADMIN")))
        {
            Response.Redirect("~/Account/Login.aspx");
        }


        Random randomobj = new Random();
        Session["randomno"] = randomobj.Next();
        csrfval.Value = Session["randomno"].ToString();

        CreateUserButton.Attributes.Add("onclick", "return SignValidate();");


        UserNametxt.Focus();  

        if (!Page.IsPostBack)
        {
            HttpContext.Current.Session["salt"] = PostgresGetData.GetRandomString(50);
           // TehsilCodeDD.Items.Add("Select");
            //ddfill();

        }

    }

    public static string GetRandomString(int Length)
    {
        Random rnd = new Random();
        StringBuilder str = new StringBuilder("");
        for (int i = 0; i < Length; i++)
            str.Append(Convert.ToChar(rnd.Next(65, 90)).ToString());
        return str.ToString();
    }

    //private void ddfill()
    //{
        

    //    PostgresGetData getdata = new PostgresGetData();
    //    DistCodeDD.DataSource = getdata.FillDropDown("Select * from master_district where Status=true ");
    //    DistCodeDD.DataValueField = "dist_code";
    //    DistCodeDD.DataTextField = "dist_name_en";
    //    DistCodeDD.DataBind();
    //    ListItem defautitem1 = new ListItem("Select", "", true);
    //    DistCodeDD.Items.Insert(0, defautitem1);

       
        
    //    ListItem defautitem = new ListItem("Select", "", true);
    //    TehsilCodeDD.Items.Insert(0, defautitem);
       
       
    //}

    protected void chkButton_Click(object sender, EventArgs e)
    {
        PostgresGetData data = new PostgresGetData();
        List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

        StringBuilder SelectQuery = new StringBuilder("select UC_USER_NAME from MASTER_USERS where UC_USER_NAME=@uname");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@uname", UserNametxt.Text.ToString().Trim());
        DataTable getValue = data.GetDataTable(SelectCmd,"nfs");
        if (getValue.Rows.Count == 0)
        {
            ChkLable.Visible = true;
            ChkLable.Text = "User Name Available.";
            Panel1.Visible = true;
        }
        else
        {
            ChkLable.Visible = true;
            ChkLable.Text = "User Already Exist !! Try Another";
            Panel1.Visible = false;

        }
    }
    protected void CreateUserButton_Click(object sender, EventArgs e)
    {
        if (csrfval.Value.ToString() != Session["randomno"].ToString())
        {
            Response.Redirect("../Account/Login.aspx");
            return;
        }

        try
        {

            PostgresGetData getdata = new PostgresGetData();

            StringBuilder SelectQuery = new StringBuilder("select UC_USER_NAME from MASTER_USERS where UC_USER_NAME=@uname");
            NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
            SelectCmd.Parameters.AddWithValue("@uname", UserNametxt.Text.ToString().Trim());
            DataTable getValue = getdata.GetDataTable(SelectCmd, "nfs");

            if (getValue.Rows.Count > 0)
            {
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "myScript", "alert('User ID is already Exists.Kindly Try Again!!');window.location='NewUserCreation.aspx';", true);
                return;
                //ChkLable.Text = "User ID is already Exists.Kindly Try Again";
                //reset();
            }

            
            string UserName = Session["UC_USER_NAME"].ToString();

            SelectQuery = new StringBuilder("select UC_PASSWORD from MASTER_USERS where uc_user_name=@uname and user_type in ('PAOADMIN','ADMIN');");
            SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
            SelectCmd.Parameters.AddWithValue("@uname", UserName.ToLower().Trim());

            DataTable usr = getdata.GetDataTable(SelectCmd,"nfs");

            if (usr.Rows.Count > 0)
            {
                string hash = usr.Rows[0][0].ToString();
            
                string salt = HttpContext.Current.Session["salt"].ToString();
                DataTable currentUser = getdata.ValidateUser(UserName.Trim(), CurrentPassword.Text.ToString().Trim());
                if (currentUser != null)
                {
                    //string RandomID = getdata.generateID(Session["user_id"].ToString());
                

                    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                    StringBuilder insert_qry = new StringBuilder("insert into  MASTER_USERS(Uc_User_Name,UC_Password,UC_Name,User_Designation,User_Type ,Is_PWD_CHNAGE,INVALID_LOGINCOUNT,ACTIVE,Mobile,Ipaddress,DoneBy,CreationDate) Values (@Uc_User_Name,@UC_Password,@UC_Name,@User_Designation,@User_Type,@Is_PWD_CHNAGE,@INVALID_LOGINCOUNT,@ACTIVE,@Mobile,@Ipaddress,@DoneBy,now())");
                    NpgsqlCommand insertCmd = new NpgsqlCommand(insert_qry.ToString());
                    insertCmd.Parameters.AddWithValue("@Uc_User_Name", UserNametxt.Text);
                    insertCmd.Parameters.AddWithValue("@UC_Password", FormsAuthentication.HashPasswordForStoringInConfigFile(UserNametxt.Text+"@123#", "md5").ToString().ToLower());//123
                    insertCmd.Parameters.AddWithValue("@Uc_Name", OfficerText.Text);
                    insertCmd.Parameters.AddWithValue("@User_Designation", DesigText.Text);
                    insertCmd.Parameters.AddWithValue("@User_Type", UsertypeDD.SelectedValue);                            
                    insertCmd.Parameters.AddWithValue("@Is_PWD_CHNAGE", "0");
                    insertCmd.Parameters.AddWithValue("@INVALID_LOGINCOUNT", "0");
                    insertCmd.Parameters.AddWithValue("@ACTIVE", "Y");
                    insertCmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);
                    insertCmd.Parameters.AddWithValue("@Ipaddress", PostgresGetData.GetIP4Address());
                    insertCmd.Parameters.AddWithValue("@DoneBy", Session["USER_ID"].ToString().Trim());
                    
                    cmdList.Add(insertCmd);

    

                    int getRecordUpdated=getdata.SaveData(cmdList,"nfs");

                    if (getRecordUpdated > 0)
                    {
                        //getdata.SendSMS(txtMobile.Text, "To Access NFS Portal, Your User ID is " + UserNametxt.Text + " and password is " + RandomID,"E");
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "myScript", "alert('User Created SuccessFully!!');window.location='NewUserCreation.aspx';", true);
                        return;
                        //ChkLable.Text = "User Created SuccessFully.";
                        //reset();

                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "myScript", "alert('User Not Created.Kindly Try Again!!');window.location='NewUserCreation.aspx';", true);
                        return;
                        //ChkLable.Text = "User Not Created.Kindly Try Again";
                        //reset();
                    }

                }
                else
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "myScript", "alert('Admin Password does not match with current logged user!!');window.location='NewUserCreation.aspx';", true);
                    return;
                    //Session.Add("Message", "Admin Password does not match with current logged user");
                    //ChkLable.Text = "Admin Password does not match with current logged user !!";
                    //reset();
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "myScript", "alert('Only Admin is Allowed for creating UserID!!');window.location='NewUserCreation.aspx';", true);
                return;
                //ChkLable.Text = "Only Admin is Allowed for creating UserID.";
                //reset();
            }
        }

        catch(Exception ex)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "myScript", "alert('Error in creating userID!!');window.location='NewUserCreation.aspx';", true);
            return;
            //Successlbl.Text = "Error in creating userID!!";
            //reset();
        }
        
    }

    

    //protected void DistCodeDD_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    if (DistCodeDD.SelectedItem.Text == "Select")
    //    {
    //        TehsilCodeDD.Items.Clear();
    //        ListItem defautitem = new ListItem("Select", "", true);
    //        TehsilCodeDD.Items.Insert(0, defautitem);
    //    }
    //    else
    //    {
    //        TehsilCodeDD.Items.Clear();
    //        PostgresGetData getdata = new PostgresGetData();
    //        String dst_code = DistCodeDD.SelectedValue.ToString();
    //        TehsilCodeDD.DataSource = getdata.FillDropDown("select * from Master_Tehsil where Status=true and District_Code='" + dst_code + "'");
    //        TehsilCodeDD.DataValueField = "Tehsil_Code";
    //        TehsilCodeDD.DataTextField = "tehsil_name_en";
    //        TehsilCodeDD.DataBind();
    //    }
    //}


    public void reset()
    {
        UserNametxt.Text = "";
        OfficerText.Text = "";
        txtMobile.Text = "";
        //DistCodeDD.Items.Clear();
        //TehsilCodeDD.Items.Clear();
        UsertypeDD.Items.Clear();
        Panel1.Visible = false;
    }
}