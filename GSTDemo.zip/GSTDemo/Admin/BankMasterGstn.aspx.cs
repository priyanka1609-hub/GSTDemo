﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using Newtonsoft.Json;
using System.Globalization;


public partial class Admin_BankMasterGstn : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    message msg = new message();

    void Page_PreInit(Object sender, EventArgs e)
    {
        if (Session["USER_TYPE"].ToString() == "ADMIN")
        {
            this.MasterPageFile = "~/Master/DEO.master";
        }
        else
        {
            this.MasterPageFile = "~/Master/PAO.master";
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        BindGrid();
    }

    private void BindGrid()
    {

        if (Session["USER_TYPE"].ToString() == "ADMIN")
        {
            tbladd.Visible = true;
        }

        StringBuilder SelectQuery = new StringBuilder("select bankcode, bankname, case banktype when 'G' then 'Public Sector Bank' when 'P' then 'Other Nominated Bank' when 'R' then 'RBI' end as banktype from master_gstn_banks order by bankname");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        DataTable dtbanks = data.GetDataTable(SelectCmd, "nfs");

        gdvbankmaster.DataSource = dtbanks;
        gdvbankmaster.DataBind();

    }

    protected void Insert(object sender, EventArgs e)
    {
        if (txtbankcode.Text != "" && txtbankname.Text != "")
        {
            string bankcode = txtbankcode.Text;
            string bankname = txtbankname.Text;

            if (!isExistsBank(bankcode))
            {
                string Qry = @"INSERT INTO master_gstn_banks(bankcode, bankname, edatetime) values(@bankcode, @bankname, now()); SELECT lastval();";
                NpgsqlCommand objdbManager = new NpgsqlCommand(Qry);
                objdbManager.Parameters.AddWithValue("@bankcode", bankcode);
                objdbManager.Parameters.AddWithValue("@bankname", bankname);
                int insertedrow = data.UpdateScalarData(objdbManager, "nfs");

                if (insertedrow > 0)
                {
                    txtbankcode.Text = "";
                    txtbankname.Text = "";
                    this.BindGrid();
                }
            }
            else
            {
                msg.Show("Bank code " + bankcode + " is already exists.");
            }

        }
        else
        {
            msg.Show("Both the fields are mandatory");
        }
    }


    protected bool isExistsBank(string bankcode)
    {
        StringBuilder SelectQuery = new StringBuilder("select  bankname from master_gstn_banks where bankcode=@bankcode");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@bankcode", bankcode);
        DataTable dtbanks = data.GetDataTable(SelectCmd, "nfs");

        if (dtbanks.Rows.Count > 0)
        {
            return true;
        }

        return false;
    }


}