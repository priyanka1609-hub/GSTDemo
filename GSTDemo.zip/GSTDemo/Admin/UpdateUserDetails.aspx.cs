﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using GstDelhi.PostgresData;//using FoodSecurity.SqlserverData;
//using System.Data.SqlClient;
using System.Text;
using System.Web.Security;
using Npgsql;


public partial class UpdateUserDetails : System.Web.UI.Page
{
   
    protected void Page_Load(object sender, EventArgs e)
    {
   if ((!String.Equals(Session["USER_TYPE"].ToString().Trim(), "NICADMIN")) && (!String.Equals(Session["USER_TYPE"].ToString().Trim(), "ADMIN")))
        {
            Response.Redirect("~/Account/Login.aspx");
        }
        

    }


    protected void chkButton_Click(object sender, EventArgs e)
    {
        PostgresGetData data = new PostgresGetData();
        List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

        StringBuilder SelectQuery = new StringBuilder(@"select  case when A.is_usb_require=true then 'Y' else 'N' end as is_usb_require,A.UC_USER_NAME as UC_USER_NAME,A.UC_NAME as UC_NAME,A.USER_TYPE as USER_TYPE,B.dist_name_en as District,C.tehsil_name_en as Tehsil,A.DISTRICT_CODE as DistCode,A.TEHSIL_CODE as tehsilcode,Mobile,Active,uc_aadharno,user_designation as designation from MASTER_USERS A
                                                        left outer join master_district B on A.DISTRICT_CODE=b.dist_code  left outer join Master_Tehsil C 
                                                        on A.TEHSIL_CODE=C.Tehsil_Code  where trim(UC_USER_NAME)=@uname and A.USER_TYPE in ('MONITOR','PAO');");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@uname", UserNametxt.Text.ToString().Trim());
        DataTable getValue = data.GetDataTable(SelectCmd,"nfs");
        if (getValue.Rows.Count == 0)
        {

            lblchk.Visible = true;
            lblchk.Text = "User Not Exist !!";
           
        }
        else
        {
            
            UserNametxt.ReadOnly = true;
            lblUserName.Visible = true;
            Panel1.Visible = true;
            Visible_Ctrl();
            //if (DdListActive.SelectedValue == "0" || DdListActive.SelectedValue == "Y")
            //{
            //    DdListActive.SelectedItem.Text = "Yes";
            //}



            if (getValue.Rows[0]["Active"].ToString() == "Y")
            {
               // DdListActive.SelectedItem.Text = "Yes";
                DdListActive.SelectedIndex = 0;
            }
            else if (getValue.Rows[0]["Active"].ToString() == "N")
            {
                //DdListActive.SelectedItem.Text = "No";
                DdListActive.SelectedIndex = 1;
            }
                      
            OfficerText.Text = getValue.Rows[0]["UC_NAME"].ToString();
            UsertypeDD.SelectedItem.Text = getValue.Rows[0]["USER_TYPE"].ToString();
           
            txtMobile.Text = getValue.Rows[0]["Mobile"].ToString();
            DesigText.Text = getValue.Rows[0]["designation"].ToString();
           
           
            UsertypeDD.Enabled = false;

             Successlbl.Visible = false;

        }
    }

    public void Visible_Ctrl()
    {
        lblActive.Visible = true;
        DdListActive.Visible = true;
        Officerlable.Visible = true;
        OfficerText.Visible = true;
        UsertypeLabel.Visible = true;
        UsertypeDD.Visible = true;
        //TehsilCodeLabel.Visible = true;
        //DistCodeLabel.Visible = true;
        //DistCodeDD.Visible = true;
        //TehsilCodeDD.Visible = true;
       // Successlbl.Visible = true;
        UpdateUserBtn.Visible = true;
        txtMobile.Visible = true;
        lblMobile.Visible = true;
        DesigText.Visible = true;
        Desiglable.Visible = true;
        btnresetpwd.Visible = true;
        
    
    }

    public void hide_Ctrl()
    {
        DesigText.Visible = false;
        Desiglable.Visible = false;
        lblActive.Visible = false;
        DdListActive.Visible =false;
        Officerlable.Visible = false;
        OfficerText.Visible = false;
        UsertypeLabel.Visible = false;
        UsertypeDD.Visible = false;
       
        UpdateUserBtn.Visible = false;
        txtMobile.Visible = false;
        lblMobile.Visible = false;
        btnresetpwd.Visible = false;
       
    
    }

    protected void UpdateUserBtn_Click(object sender, EventArgs e)
    
    {
        try
        {
            PostgresGetData getdata = new PostgresGetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            StringBuilder Update_qry = new StringBuilder(@"Update MASTER_USERS Set UC_Name=@UC_Name,Mobile=@Mobile,Active=@Active,
                                                            UpdatedBy=@UpdatedBy,Updation_IP=@Updation_IP,Updation_Date=now(), user_designation=@user_designation  
                                                            where Uc_User_Name='" + UserNametxt.Text.Trim() + "'");
            NpgsqlCommand UpdateCmd = new NpgsqlCommand(Update_qry.ToString());
                       
            UpdateCmd.Parameters.AddWithValue("@Uc_Name", OfficerText.Text);
            UpdateCmd.Parameters.AddWithValue("@Active",DdListActive.SelectedValue);
            UpdateCmd.Parameters.AddWithValue("@Mobile", Convert.ToInt64(txtMobile.Text));
            UpdateCmd.Parameters.AddWithValue("@UpdatedBy", Session["USER_ID"].ToString().Trim());
            UpdateCmd.Parameters.AddWithValue("@Updation_IP", PostgresGetData.GetIP4Address());
            UpdateCmd.Parameters.AddWithValue("@user_designation", DesigText.Text);
           
               
            cmdList.Add(UpdateCmd );
            getdata.SaveData(cmdList, "nfs");
             Successlbl.Visible = true;
             Successlbl.Text = "User Data Updated SuccessFully.";

             hide_Ctrl();
            
        }

        catch (Exception ex)
        {
            // Successlbl.Text = "Error !!";
             Session.Add("Message", "There was an Error During Update Operation!.");
             Response.Redirect("~/Message.aspx", true);
        }
    }

    protected void btnresetpwd_Click(object sender, EventArgs e)
    {
        try
        {
            PostgresGetData getdata = new PostgresGetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            StringBuilder Update_qry = new StringBuilder(@"Update MASTER_USERS Set uc_password=@uc_password,UpdatedBy=@UpdatedBy,Updation_IP=@Updation_IP,Updation_Date=now(),  
                                                            Is_PWD_CHNAGE=@Is_PWD_CHNAGE where Uc_User_Name='" + UserNametxt.Text.Trim() + "'");
            NpgsqlCommand UpdateCmd = new NpgsqlCommand(Update_qry.ToString());

            UpdateCmd.Parameters.AddWithValue("@uc_password", FormsAuthentication.HashPasswordForStoringInConfigFile(UserNametxt.Text + "@123#", "md5").ToString().ToLower());
            UpdateCmd.Parameters.AddWithValue("@UpdatedBy", Session["USER_ID"].ToString().Trim());
            UpdateCmd.Parameters.AddWithValue("@Updation_IP", PostgresGetData.GetIP4Address());
            UpdateCmd.Parameters.AddWithValue("@Is_PWD_CHNAGE", "0");
            
            cmdList.Add(UpdateCmd);
            getdata.SaveData(cmdList, "nfs");
            Successlbl.Visible = true;
            Successlbl.Text = "User Password Reseted SuccessFully.";

            hide_Ctrl();

        }

        catch (Exception ex)
        {
            // Successlbl.Text = "Error !!";
            Session.Add("Message", "There was an Error During Update Operation!.");
            Response.Redirect("~/Message.aspx", true);
        }
    }
}

