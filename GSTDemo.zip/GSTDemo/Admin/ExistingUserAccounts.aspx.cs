﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using GstDelhi.PostgresData;//using FoodSecurity.SqlserverData;
//using System.Data.SqlClient;
using System.Text;
using Npgsql;

public partial class ExistingUserAccounts : System.Web.UI.Page
{
    public DataTable dt = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        if ((!String.Equals(Session["USER_TYPE"].ToString().Trim(), "NICADMIN")) && (!String.Equals(Session["USER_TYPE"].ToString().Trim(), "ADMIN")) && (!String.Equals(Session["USER_TYPE"].ToString().Trim(), "AC")) && (!String.Equals(Session["USER_TYPE"].ToString().Trim(), "FSO")))
        {
            Response.Redirect("~/Account/Login.aspx");
        }

       
        if (!IsPostBack)
        {
            UserDropDownFill();

        }
       
    }

    private void UserDropDownFill()
    {
        PostgresGetData getdata = new PostgresGetData();
        string query = @"select distinct User_type as UserTypeCode,
                            case when User_type='PAOADMIN' then 'PAOADMIN' 
                                 when User_type='MONITOR' then 'MONITOR' 
                                 when User_type='PAO' then 'PROCESS' 
                                   end as UserTypeDesc
                            from master_users where User_TYPE in ('PAO','MONITOR','PAOADMIN') order by User_Type";

       ddUsertype.DataSource = getdata.FillDropDown(query);
       ddUsertype.DataValueField = "UserTypeCode";
       ddUsertype.DataTextField = "UserTypeDesc";
       ddUsertype.DataBind();
       ddUsertype.Items.Insert(0, new ListItem("---Select---", "0"));
    }


    public void filldata()
    {
        if (ddUsertype.SelectedIndex > 0)
        {
            GridView1.Visible = true;
            PostgresGetData getdata = new PostgresGetData();
//            StringBuilder selectQuery_ddl = new StringBuilder(@"select 
//                                                                case when user_type='AC' then 'All Circles of This District' else (right(MT.Tehsil_Code,2) || ' - ' || MT.tehsil_name_en) end as Circle_Name,
//                                                                MD.dist_name_en as District_Name,
//                                                                MU.UC_USER_NAME as Login_User_Id,
//                                                                Mu.UC_NAME as User_Name,
//                                                                MU.USER_TYPE as Designation,
//                                                                case when MU.mobile='' OR MU.mobile IS Null then 'NA' else MU.mobile end as Mobileno,
//                                                                case when MU.Active='Y' then 'Active' else 'Inactive' end as ActiveStatus
//                                                                from master_users MU
//                                                                LEFT OUTER JOIN Master_Tehsil MT on Mt.Tehsil_Code=MU.TEHSIL_CODE
//                                                                Left OUTER JOIN master_district MD on MD.dist_code=MU.DISTRICT_CODE
//                                                                where MU.USER_TYPE=@UserType and USER_ID not in (524,525,873) and UserFlag='G'
//                                                                order by right(MT.Tehsil_Code,2),Active desc ");

            StringBuilder selectQuery_ddl = new StringBuilder(@" 
select 
                                                              
                                                                MU.UC_USER_NAME as Login_User_Id,
                                                                Mu.UC_NAME as User_Name,
                                                                MU.USER_TYPE ,
                                                                MU.user_designation as Designation,
                                                                case when MU.mobile='' OR MU.mobile IS Null then 'NA' else MU.mobile end as Mobileno,
                                                                case when MU.Active='Y' then 'Active' else 'Inactive' end as ActiveStatus
                                                                from master_users MU
                                                                where MU.USER_TYPE= @UserType and USER_ID not in (524,525,873)");

            NpgsqlCommand cmd_ddl = new NpgsqlCommand(selectQuery_ddl.ToString());
            cmd_ddl.Parameters.AddWithValue("@UserType", ddUsertype.SelectedValue.ToString());
            dt = getdata.GetDataTable(cmd_ddl, "nfs");
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
       
    }

    protected void btnview_Click(object sender, EventArgs e)
    {
        if (ddUsertype.SelectedIndex>0)
        {
            GridView1.Visible = true;
            filldata();

        }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
   
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        filldata();
    }

    protected void GridView1_RowDataBound1(object sender, GridViewRowEventArgs e)
    {
        
    }
}
