﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;

public partial class ADMINHome : System.Web.UI.Page
{
    MD5Util md5util = new MD5Util();

    protected void Page_Load(object sender, EventArgs e)
    {
        //fillgrid();
        //fillgridRbi();

        //filltiles();
    }


//    private void fillgrid()
//    {
//        PostgresGetData data = new PostgresGetData();
//        StringBuilder SelectQuery = new StringBuilder(@"select fcountid,num_files,count(frcid) incorporated,to_char(fc.filedate,'DD/MM/YYYY') as filedate,fc.filetype from files_count fc
//                                                        inner join file_record_count frc on fc.fcountid = frc.filecntid 
//                                                        where fc.status='1' and frc.validfile='Y'
//                                                        group by fcountid,fc.filetype,fc.filedate,num_files order by fc.filedate desc");
//        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
//        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

//        grdgstfiles.DataSource = dt;
//        grdgstfiles.DataBind();
//    }


//    protected void grdgstfiles_RowDataBound(object sender, GridViewRowEventArgs e)
//    {

//        if (e.Row.RowType == DataControlRowType.DataRow)
//        {

//            string id = grdgstfiles.DataKeys[e.Row.RowIndex].Values["fcountid"].ToString();
//            HyperLink hylnkhylnkavail = (HyperLink)e.Row.FindControl("hylnkavail");
//            hylnkhylnkavail.NavigateUrl = md5util.CreateTamperProofURL("~/Reports/RprtGstnFileRec.aspx", null, "id=" + MD5Util.Encrypt(id, true) + "&flg=" + MD5Util.Encrypt("A", true));


//            string idcpin = grdgstfiles.DataKeys[e.Row.RowIndex].Values["fcountid"].ToString();
//            HyperLink hylnkhylnkincor = (HyperLink)e.Row.FindControl("hylnkincor");
//            hylnkhylnkincor.NavigateUrl = md5util.CreateTamperProofURL("~/Reports/RprtGstnFileRec.aspx", null, "id=" + MD5Util.Encrypt(id, true) + "&flg=" + MD5Util.Encrypt("I", true));
//        }

//    }
//    private void fillgridRbi()
//    {
//        PostgresGetData data = new PostgresGetData();
//        StringBuilder SelectQuery = new StringBuilder(@"select count(headerid) filecount,to_char(scrolldate,'DD/MM/YYYY') scrolldate from rbi_response_header 
//                                                        group by scrolldate order by scrolldate desc");
//        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
//        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

//        grdrbifiles.DataSource = dt;
//        grdrbifiles.DataBind();
//    }

//    private void filltiles()
//    {
//        PostgresGetData data = new PostgresGetData();

//        StringBuilder SelectQuery = new StringBuilder(@"select COALESCE(sum(totaltxnamt),'0.00') sum from rbi_response_txns_details where isprocessed is null");
//        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
//        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
//        lblrbiamt.Text = dt.Rows[0]["sum"].ToString();

//        SelectQuery = new StringBuilder(@"select COALESCE(sum(sgst_total),'0.00') sum from transactions_eod_cin  where isprocessed is null");
//        SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
//        dt = data.GetDataTable(SelectCmd, "nfs");
//        lblgstamt.Text = dt.Rows[0]["sum"].ToString();


//        SelectQuery = new StringBuilder(@"select sum(totaltxnamt) from rbi_response_txns_details rbi
//                                        inner join transactions_eod_cin tec on tec.cin=rbi.cin
//                                        where rbi.isprocessed is null and tec.isprocessed is null and totaltxnamt=sgst_total ");
//        SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
//        dt = data.GetDataTable(SelectCmd, "nfs");
//        lblmatched.Text = dt.Rows[0]["sum"].ToString();

//        lblunmatched.Text = Math.Abs(Convert.ToDecimal(lblrbiamt.Text) - Convert.ToDecimal(lblgstamt.Text)).ToString();
       
//    }
}