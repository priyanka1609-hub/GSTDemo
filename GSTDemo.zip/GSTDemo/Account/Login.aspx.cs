﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
//using GstDelhi.PostgresData;//using FoodSecurity.SqlserverData;
//using System.Data.SqlClient;
using System.Text;
using System.Web.Security;
using System.Net;
using Npgsql;
using GstDelhi.PostgresData;
using System.Globalization;
using System.Threading;
using System.IO;

public partial class Account_Login : System.Web.UI.Page
{
    private const string AntiXsrfTokenKey = "__AntiXsrfToken";
    private const string AntiXsrfUserNameKey = "__AntiXsrfUserName";
    private string _antiXsrfTokenValue;

    protected void Page_Init(object sender, EventArgs e)
    {
        var requestCookie = Request.Cookies[AntiXsrfTokenKey];
        Guid requestCookieGuidValue;
        if (requestCookie != null && Guid.TryParse(requestCookie.Value, out requestCookieGuidValue))
        {
            _antiXsrfTokenValue = requestCookie.Value;

            Page.ViewStateUserKey = _antiXsrfTokenValue;
        }
        else
        {
            _antiXsrfTokenValue = Guid.NewGuid().ToString("N");
            Page.ViewStateUserKey = _antiXsrfTokenValue;
            var responseCookie = new HttpCookie(AntiXsrfTokenKey)
            {
                HttpOnly = true,
                Value = _antiXsrfTokenValue
            };
            if (FormsAuthentication.RequireSSL && Request.IsSecureConnection) responseCookie.Secure = true;
            Response.Cookies.Set(responseCookie);
        }
        //Page.PreLoad += master_Page_PreLoad;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            HttpContext.Current.Session["salt"] = GetRandomString(50);
        }

    }
    protected void Login_click(object sender, EventArgs e)
    {
        Captcha1.ValidateCaptcha(txtCaptcha.Text.Trim());

        if (Captcha1.UserValidated)
        {
            string userId = DataOperationsEncrypt.DecryptStringAES(UserName.Text.ToString());
            PostgresGetData data = new PostgresGetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

            StringBuilder SelectQuery = new StringBuilder("select INVALID_LOGINCOUNT,IS_PWD_CHNAGE,User_ID,isSHA,uc_user_name,uc_password,uc_name,USER_TYPE,DISTRICT_CODE,TEHSIL_CODE,USERFLAG,mobile,is_usb_require,uc_aadharno,User_Type || ',' || UC_NAME  as LoginDetail from master_users where upper(trim(uc_user_name))=@uname and Active='Y' ");
            NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
            SelectCmd.Parameters.AddWithValue("@uname", userId.ToUpper());
            DataTable getHitValue = data.GetDataTable(SelectCmd, "nfs");
            
            if (getHitValue.Rows.Count == 0)
            {
                Session.Add("Message", "UserID or Password does not exist,Kindly Try Again.");
                Response.Redirect("~/Message.aspx", true);
            }
            Session["UserId"] = getHitValue.Rows[0]["uc_user_name"].ToString();
            if (getHitValue.Rows[0]["INVALID_LOGINCOUNT"].ToString().Trim() == "5")
            {
                Session.Add("Message", "You have enter maximum number of Hit, Your password has been blocked, Please Contact to Admin.!!!");
                Response.Redirect("~/Message.aspx", true);
            }
            if (getHitValue.Rows[0]["isSHA"].ToString().Trim() == "False")
            {
                Session.Add("Message", "Change Password");
                Response.Redirect("~/Account/ChangePasswordSHA.aspx", true);
            }

            StringBuilder updateQuery = new StringBuilder("update master_users set INVALID_LOGINCOUNT=@invalid_login_count where trim(uc_user_name)=@uname");
            NpgsqlCommand updateCmd = new NpgsqlCommand(updateQuery.ToString());
            updateCmd.Parameters.AddWithValue("@invalid_login_count", (Convert.ToInt32(getHitValue.Rows[0]["INVALID_LOGINCOUNT"].ToString().Trim()) + 1));
            updateCmd.Parameters.AddWithValue("@uname", UserName.Text.ToString().Trim());
            cmdList.Add(updateCmd);

            data.SaveData(cmdList, "nfs");
            bool svrSignature = false;

            string pass = getHitValue.Rows[0]["uc_password"].ToString().Trim();

            //GetRandomString(50);

            if (PostgresGetData.VerifySHA512Hash(pass + Session["salt"], Password.Text.ToString().Trim()))
            {
                svrSignature = true;
            }
            else
            {
                svrSignature = false;
            }
            DataTable currentUser = getHitValue;
            if (svrSignature)
            {
                StringBuilder InsertHistQuery = new StringBuilder("select coalesce(actiondatetime,now()) as NewDate from loginhistory where usercode=@usercode order by actiondatetime desc limit 1;");
                NpgsqlCommand InsertHistCmd = new NpgsqlCommand(InsertHistQuery.ToString());
                InsertHistCmd.Parameters.AddWithValue("@usercode", getHitValue.Rows[0]["User_ID"].ToString());
                DataTable dtLastLOginDate = data.GetDataTable(InsertHistCmd, "nfs");

                if (dtLastLOginDate.Rows.Count > 0)
                    Session["dtLastLOginDate"] = dtLastLOginDate.Rows[0]["NewDate"].ToString();
                else
                    Session["dtLastLOginDate"] = System.DateTime.Now.ToString("dd/MM/yyyy HH:MM:SS");

                InsertHistQuery = new StringBuilder("insert into loginhistory(usercode,userid,IP,ActionDatetime,Loginstatus) values(@usercode,@userid,@IP,now(),@Loginstatus)");
                InsertHistCmd = new NpgsqlCommand(InsertHistQuery.ToString());
                InsertHistCmd.Parameters.AddWithValue("@usercode", getHitValue.Rows[0]["User_ID"].ToString());
                InsertHistCmd.Parameters.AddWithValue("@userid", UserName.Text.ToString().Trim());
                InsertHistCmd.Parameters.AddWithValue("@IP", PostgresGetData.GetIP4Address());
                InsertHistCmd.Parameters.AddWithValue("@Loginstatus", "true");
                data.UpdateData(InsertHistCmd, "nfs");



                FormsAuthentication.SetAuthCookie(currentUser.Rows[0]["UC_USER_NAME"].ToString().Trim(), false);
                var authTicket = new FormsAuthenticationTicket(1,                    // version
                                                                currentUser.Rows[0]["UC_USER_NAME"].ToString().Trim(),       // user name
                                                                DateTime.Now,         // created 
                                                                DateTime.Now.AddMinutes(30),// expires
                                                                false,                // persistent Remeber me?
                                                                currentUser.Rows[0]["USER_TYPE"].ToString().Trim() // can be used to store roles
                                                                );
                string encryptedTicket = FormsAuthentication.Encrypt(authTicket);
                var authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);
                HttpContext.Current.Response.Cookies.Add(authCookie);

                Session.Add("USER_ID", currentUser.Rows[0]["user_id"].ToString().Trim());
                Session.Add("UC_USER_NAME", currentUser.Rows[0]["uc_user_name"].ToString().Trim());
                Session.Add("DISTRICT_CODE", currentUser.Rows[0]["district_code"].ToString().Trim());
                Session.Add("TEHSIL_CODE", currentUser.Rows[0]["tehsil_code"].ToString().Trim());
                Session.Add("USER_TYPE", currentUser.Rows[0]["user_type"].ToString().Trim());
                Session.Add("UC_NAME", currentUser.Rows[0]["UC_NAME"].ToString().Trim());
                Session.Add("USERFLAG", currentUser.Rows[0]["UserFlag"].ToString().Trim());
                Session.Add("LoginDetail", currentUser.Rows[0]["LoginDetail"].ToString().Trim());
                Session.Add("Loginmobile", currentUser.Rows[0]["mobile"].ToString().Trim());
                Session.Add("cardType", "4");
                Session.Add("WhetherActive", "Active");
                Session.Add("SessionId", Session.SessionID);
                Session.Add("is_usb_require", currentUser.Rows[0]["is_usb_require"].ToString().Trim());
                Session.Add("Aadharno", currentUser.Rows[0]["uc_aadharno"].ToString().Trim());


                //string check = Session["USERFLAG"].ToString();

                // data.setCurrentUserDetails(currentUser);
                DataTable dt = PostgresGetData.CurrentUserDetails;
                // HttpContext.Response.Cookies.Add(authCookie);

                if (currentUser.Rows[0]["IS_PWD_CHNAGE"].ToString().Trim() == "0")
                {
                    Response.Redirect("~/Account/ChangePassword.aspx", true);
                }
                else
                {
                    if (currentUser.Rows[0]["USER_TYPE"].ToString().Trim() == "ADMIN" || currentUser.Rows[0]["USER_TYPE"].ToString().Trim() == "NICADMIN" || currentUser.Rows[0]["USER_TYPE"].ToString().Trim() == "UIDAI")
                        Response.Redirect("~/ADMIN/ADMINHome.aspx", true);
                    else if (currentUser.Rows[0]["USER_TYPE"].ToString().Trim() == "PAO" || currentUser.Rows[0]["USER_TYPE"].ToString().Trim() == "MONITOR")
                        //Response.Redirect("~/Reports/HeadwiseReport.aspx", true);
                        Response.Redirect("~/PAO/DefaultHome.aspx", true);
                    else
                        Response.Redirect("~/Account/Login.aspx", true);
                }



            }
            else
            {

                StringBuilder InsertHistQuery = new StringBuilder("insert into loginhistory(usercode,userid,IP,ActionDatetime,Loginstatus) values(@usercode,@userid,@IP,now(),@Loginstatus)");
                NpgsqlCommand InsertHistCmd = new NpgsqlCommand(InsertHistQuery.ToString());
                InsertHistCmd.Parameters.AddWithValue("@usercode", getHitValue.Rows[0]["User_ID"].ToString());
                InsertHistCmd.Parameters.AddWithValue("@userid", UserName.Text.ToString().Trim());
                InsertHistCmd.Parameters.AddWithValue("@IP", PostgresGetData.GetIP4Address());
                InsertHistCmd.Parameters.AddWithValue("@Loginstatus", "true");
                data.UpdateData(InsertHistCmd, "nfs");

                LblMessage.Visible = true;
                LblMessage.Text = "The user name or password provided is incorrect.";
                UserName.Text = "";
                return;
            }
        }
        else
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Invalid Captcha!');", true);
        }
    }
          
            // If we got this far, something failed, redisplay form
            //Sessions.setSalt(Utility.GetRandomString(50));

    public static string GetRandomString(int Length)
    {
        Random rnd = new Random();
        StringBuilder str = new StringBuilder("");
        for (int i = 0; i < Length; i++)
            str.Append(Convert.ToChar(rnd.Next(65, 90)).ToString());
        return str.ToString();
    }
   
    public void checkCheckBox(object o, ServerValidateEventArgs e)
    {
        //if (CbOTP.Checked)
        //{
        //    e.IsValid = true;
        //}
        //else
        //{
        //    e.IsValid = false;
        //}
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        PostgresGetData data = new PostgresGetData();
        List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

        StringBuilder SelectQuery = new StringBuilder("select INVALID_LOGINCOUNT,IS_PWD_CHNAGE,User_ID,mobile from master_users where trim(uc_user_name)=@uname and Active='Y'");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@uname", UserName.Text.ToString().Trim());
        DataTable getHitValue = data.GetDataTable(SelectCmd, "nfs");

        if (getHitValue.Rows.Count == 0)
        {
            Session.Add("Message", "UserID or Password does not exist,Kindly Try Again.");
            Response.Redirect("~/Message.aspx", true);
        }

        string OTPID = data.generateID(getHitValue.Rows[0]["User_ID"].ToString());
        //StringBuilder InsertHistQuery = new StringBuilder("insert into sms(sms,mobile) Values(@sms,@mobile)");
        //NpgsqlCommand InsertHistCmd = new NpgsqlCommand(InsertHistQuery.ToString());
        //InsertHistCmd.Parameters.AddWithValue("@sms",   "OTP for Reset of Password to UserID[" + UserName.Text.ToString().Trim() + "] is " + OTPID + ".Do not share it with anyone.");
        //InsertHistCmd.Parameters.AddWithValue("@mobile", getHitValue.Rows[0]["mobile"].ToString());
        //cmdList.Add(InsertHistCmd);

        StringBuilder InsertHistQuery = new StringBuilder("update master_users set otp=@otp,whether_otp_used=false where trim(uc_user_name)=@uname and Active='Y'");
        NpgsqlCommand InsertHistCmd = new NpgsqlCommand(InsertHistQuery.ToString());
        InsertHistCmd.Parameters.AddWithValue("@otp", OTPID);
        InsertHistCmd.Parameters.AddWithValue("@uname", UserName.Text.ToString().Trim());
        cmdList.Add(InsertHistCmd);

        int recInsert=data.SaveData(cmdList, "nfs");

        if (recInsert > 0)
        {
            data.SendSMS(getHitValue.Rows[0]["mobile"].ToString(), "OTP for Reset of Password to UserID[" + UserName.Text.ToString().Trim() + "] is " + OTPID + ".Do not share it with anyone.","E");
            
            Session["OTPUserid"] = UserName.Text.ToString().Trim();
            Session["OTP"] = OTPID.ToString().Trim();
           
            // this is throw the ThreadAbortException exception
            Response.Redirect("ChangePasswordByOTP.aspx", false);
            Context.ApplicationInstance.CompleteRequest();
        }
    }


    private void CheckDigitalSignature()
    {
        PostgresGetData data = new PostgresGetData();
     
        StringBuilder InsertHistQuery = new StringBuilder("SELECT * FROM digitalcardtypemaster WHERE cardtypeid=@cardType");
        NpgsqlCommand InsertHistCmd = new NpgsqlCommand(InsertHistQuery.ToString());
        InsertHistCmd.Parameters.AddWithValue("@cardType", Session["cardType"]);
        DataTable DT_SignatureType = data.GetDataTable(InsertHistCmd, "nfs");

        if (DT_SignatureType.Rows.Count > 0)
        {
            Session["JarNameLogin"] = DT_SignatureType.Rows[0]["jaraccountlogin"].ToString();
            Session["JarNameExtnLogin"] = DT_SignatureType.Rows[0]["jaraccountname"].ToString();
            Session["cardpath"] = DT_SignatureType.Rows[0]["cardpath"].ToString();
        }

        InsertHistQuery = new StringBuilder("SELECT * FROM userdigitalmaster WHERE whetheractive=true and userid=@user_id order by actiondatetime desc limit 1;");
        InsertHistCmd = new NpgsqlCommand(InsertHistQuery.ToString());
        InsertHistCmd.Parameters.AddWithValue("@user_id", Session["user_id"]);
        DataTable userDigitalSignTable = data.GetDataTable(InsertHistCmd, "nfs");
       
        if (userDigitalSignTable.Rows.Count > 0)
        {
            Session["CardName"] = userDigitalSignTable.Rows[0]["UserName"].ToString();
            String no_of_valid_days = (Convert.ToDateTime(userDigitalSignTable.Rows[0]["validto"]) - DateTime.Now).Days.ToString();
            Session["SmartCardID"] = userDigitalSignTable.Rows[0]["rowid"].ToString();
            Session["DSC_certificate"] = userDigitalSignTable.Rows[0]["certificateChain"].ToString();
            Session["Chain_flag"] = "Y";
            Session["valid_days"] = no_of_valid_days;
            Session["SerialNum"] = userDigitalSignTable.Rows[0]["serialno"].ToString();


            string datavalue = Session["CardName"].ToString() + "," + no_of_valid_days + "," + Session["SmartCardID"] + "," + Session["Chain_flag"].ToString();
            string dir = Server.MapPath("~//localfile//");

            string path = dir + Session["uc_user_name"].ToString() + "user.txt";
            using (StreamWriter w = new StreamWriter(path))
            {
                w.WriteLine(datavalue); // Write the text
            }

            string url = HttpContext.Current.Request.Url.Authority + Request.ApplicationPath;
            string filepath = url + "/localfile/";

            Response.Redirect("~/Account/CardLogin.aspx?filepath=" + filepath);
        }
        else
        {
            string filepath = string.Empty;
            string datavalue = Session["uc_user_name"].ToString();
            string dir = Server.MapPath("~//localfile//");

            string path = dir + Session["uc_user_name"].ToString() + "user.txt";
            using (StreamWriter w = new StreamWriter(path))
            {
                w.WriteLine(datavalue); // Write the text
            }

            string url = HttpContext.Current.Request.Url.Authority + Request.ApplicationPath;
            filepath = url + "/localfile/";
            filepath = "";

            Response.Redirect("~/Account/Card_register.aspx?filepath=" + filepath);
        }
    }

    
}

