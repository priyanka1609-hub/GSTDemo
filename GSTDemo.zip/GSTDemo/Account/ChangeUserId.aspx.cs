﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using GstDelhi.PostgresData;//using FoodSecurity.SqlserverData;
//using System.Data.SqlClient;
using System.Text;
using System.Web.Security;
using GstDelhi.PostgresData;
using Npgsql;

public partial class ChangeUserId : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            PostgresGetData data = new PostgresGetData();
            lblexistingUserId.Text = Session["UC_USER_NAME"].ToString().Trim();
            StringBuilder SelectQuery = new StringBuilder("select user_id from MASTER_USERS where lower(uc_user_name)=@existing_user_id");
            NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
            SelectCmd.Parameters.AddWithValue("@existing_user_id", (lblexistingUserId.Text).ToLower().Trim());
            DataTable resultusercode = data.GetDataTable(SelectCmd, "nfs");
            hdnusercode.Value = resultusercode.Rows[0][0].ToString();
        }

    }


    protected void chkButton_Click(object sender, EventArgs e)
    {
        PostgresGetData data = new PostgresGetData();
        List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

        StringBuilder SelectQuery = new StringBuilder("select UC_USER_NAME from MASTER_USERS where UC_USER_NAME=@uname");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@uname", txtnewUserid.Text.ToString().Trim());
        DataTable getValue = data.GetDataTable(SelectCmd,"nfs");
        if (getValue.Rows.Count == 0)
        {
            ChkLable.Visible = true;
            ChkLable.Text = "Available.";
            txtnewUserid.ReadOnly = true;
            btnChange.Visible = true;
            btnreset.Visible = true;
            lblnote.Visible = true;
            chkButton.Visible = false;
        }
        else
        {
            ChkLable.Visible = true;
            ChkLable.Text = "Not Available";
            btnChange.Visible = false;
            btnreset.Visible = true;
            lblnote.Visible = false;
            chkButton.Visible = true;
        }
    }
    protected void btnChange_Click(object sender, EventArgs e)
    {
        try
        {
            PostgresGetData getdata = new PostgresGetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            StringBuilder update_qry = new StringBuilder("Update MASTER_USERS set Uc_User_Name=@New_User_Id where user_ID=@user_ID_Code");
            NpgsqlCommand updateCmd = new NpgsqlCommand(update_qry.ToString());
            updateCmd.Parameters.AddWithValue("@New_User_Id", txtnewUserid.Text);
            updateCmd.Parameters.AddWithValue("@user_ID_Code", hdnusercode.Value);
            cmdList.Add(updateCmd);


            string insertintohistory = "";
            NpgsqlCommand insertintohistoryC = new NpgsqlCommand();
            insertintohistory = @" insert into User_ID_Changed_History(User_Code,Existing_User_Id,New_User_Id,Ipaddress,UpdatedBy,ActionDateTime) 
                                                                  values(@User_Code,@Existing_User_Id,@New_User_Id,@Ipaddress,@UpdatedBy,now() ) ";
            insertintohistoryC = new NpgsqlCommand(insertintohistory.ToString());
            insertintohistoryC.Parameters.AddWithValue("@User_Code", hdnusercode.Value);
            insertintohistoryC.Parameters.AddWithValue("@Existing_User_Id", Session["UC_USER_NAME"].ToString());
            insertintohistoryC.Parameters.AddWithValue("@New_User_Id", txtnewUserid.Text);
            insertintohistoryC.Parameters.AddWithValue("@Ipaddress", PostgresGetData.GetIP4Address());
            insertintohistoryC.Parameters.AddWithValue("@UpdatedBy", Session["USER_ID"].ToString().Trim());
            cmdList.Add(insertintohistoryC);

            Int32 Recordsupdated = getdata.SaveData(cmdList, "nfs");

            if (Recordsupdated > 0)
            {
                //string script = "<script type='text/javascript'>alert('User ID has been Changed.You have to login again.');</script>";
                //ClientScript.RegisterStartupScript(GetType(), "Message", script);

                FormsAuthentication.SignOut();
                Session.Abandon();
                FormsAuthentication.RedirectToLoginPage();
            }
            else
            {
                string script = "<script type='text/javascript'>alert('Please try again later.');</script>";
                ClientScript.RegisterStartupScript(GetType(), "Message", script);
            }
           
        }

        catch(Exception ex)
        {
            lblerrormsg.Visible = true;
            lblerrormsg.Text = "'Please Try Again later.";
        }
        
    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        txtnewUserid.ReadOnly = false;
        txtnewUserid.Text = "";
        ChkLable.Visible = false;
        btnChange.Visible = false;
        lblnote.Visible = false;
        btnreset.Visible = false;
        chkButton.Visible = true;
    }
}