﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class Account_LogOut : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //FormsAuthentication.SignOut();
        //foreach (var cookie in Request.Cookies.AllKeys)
        //{
        //    Request.Cookies.Remove(cookie);
        //}
        //foreach (var cookie in Response.Cookies.AllKeys)
        //{
        //    Response.Cookies.Remove(cookie);
        //}
        FormsAuthentication.SignOut();
		 Session.Abandon();
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.Cache.SetExpires(DateTime.Now.AddSeconds(-1));
        Response.Cache.SetNoStore();
        Response.AppendHeader("Pragma", "no-cache");
        FormsAuthentication.RedirectToLoginPage();
       
    }
    protected void Timer1_Tick(object sender, EventArgs e)
    {
        FormsAuthentication.SignOut();
        Session.Abandon();
        FormsAuthentication.RedirectToLoginPage();
    }
}