﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using GstDelhi.PostgresData;//using FoodSecurity.SqlserverData;
//using System.Data.SqlClient;
using System.Text;
using System.Web.Security;
using GstDelhi.PostgresData;
using Npgsql;
public partial class Account_ChangePasswordSHA : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblUser.Text = Session["userid"].ToString();
        Random randomobj = new Random();
        Session["randomno"] = randomobj.Next();
        csrfval.Value = Session["randomno"].ToString();

        ChangePasswordPushButton.Attributes.Add("onclick", "return SignValidate();");

        if (!Page.IsPostBack)
        {
            HttpContext.Current.Session["salt"] = PostgresGetData.GetRandomString(50);
        }
    }
    protected void ChangePasswordPushButton_Click(object sender, EventArgs e)
    {
        if (csrfval.Value.ToString() != Session["randomno"].ToString())
        {
            Response.Redirect("../Account/Login.aspx");
            return;
        }

        PostgresGetData data = new PostgresGetData();
        //DataTable dt = PostgresGetData.CurrentUserDetails;


        string UserName = Session["UserId"].ToString();
        if ((lblUser.Text).ToLower() == UserName.ToLower())
        {
            StringBuilder SelectQuery = new StringBuilder("select UC_PASSWORD from MASTER_USERS where uc_user_name=@uname");
            NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
            SelectCmd.Parameters.AddWithValue("@uname", UserName.Trim());

            DataTable usr = data.GetDataTable(SelectCmd, "nfs");

            if (usr.Rows.Count > 0)
            {
                string hash = usr.Rows[0][0].ToString();
            }
            string salt = HttpContext.Current.Session["salt"].ToString();
            DataTable currentUser = data.ValidateUser(UserName.Trim(), CurrentPassword.Text.ToString().Trim());
            if (currentUser != null)
            {
                if (NewPassword.Text.Equals(ConfirmNewPassword.Text))
                {
                    data.ChangePasswordUser(UserName.Trim(), HdNewPass.Value.Trim(), "USER");
                    Session.Add("Message", "Password Change sucessfully ");
                    Response.Redirect("../Message.aspx");
                }
                else
                {
                    Session.Add("Message", "New Password and Confirm password does not match ");
                    Response.Redirect("../Message.aspx");

                }
            }
        }
        else
        {
            Session.Add("Message", "User id does not match with current logged user");
            Response.Redirect("../Message.aspx");
        }
    }
}