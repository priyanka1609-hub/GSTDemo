﻿function loadXmlHttp() {
    if (window.XMLHttpRequest) { // IE7, Mozilla, Safari, Opera
        xmlHttp = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        try {
            xmlHttp = new ActiveXObject("Microsoft.XMLHTTP"); //IE 5.x, 6
        }
        catch (e) { }
    }
}
function sendRequest(url) {
    if (xmlHttp) {
        xmlHttp.open("GET", url, true); // true = async
        xmlHttp.onreadystatechange = onCallback;

        xmlHttp.send(null);
    }
}
function onCallback() {
    // alert(xmlHttp.readyState);
    // alert(xmlHttp.status);
    if (xmlHttp.readyState == 4) {
        if (xmlHttp.status == 200) {
            var j = xmlHttp.responseText;
            //var continents = eval(j);

            //for (i = 0; i < continents.length; i++)
             //   alert(continents[i]);

        }
        else {
            alert('Error: ' + xmlHttp.status);
        }
    }
}