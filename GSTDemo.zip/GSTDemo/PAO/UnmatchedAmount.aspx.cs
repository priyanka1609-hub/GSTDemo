﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
public partial class PAO_UnmatchedAmount : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
        {

            if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
            StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
            {
                Response.Redirect("Logout.aspx");
            }
        }

        // showData();

        if (Request.QueryString["dt"] != null)
        {
            lblpymtdate.Text = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true);
            filltiles();
        }

       
    }

    private void filltiles()
    {

        StringBuilder SelectQuery = new StringBuilder(@"select COALESCE(sum(sgst_total),'0.00') sum from transactions_eod_cin where isprocessed is null and cin not in (select cin from rbi_response_txns_details)  and to_char(paymentdatetime,'DD/MM/YYYY')=@paymentdate");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdate", lblpymtdate.Text);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
        lblmissingcin.Text = dt.Rows[0]["sum"].ToString();

        if (Convert.ToDecimal(dt.Rows[0]["sum"].ToString()) > 0)
        {
            hylnkmissingcin.Visible = true;
            lnkmissingcin.Visible = true;
        }

        SelectQuery = new StringBuilder(@"select COALESCE(sum(totaltxnamt),'0.00') sum from rbi_response_txns_details where isprocessed is null and cin not in (select cin from transactions_eod_cin) and to_char(paymentdatetime,'DD/MM/YYYY')=@paymentdate");
        SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdate", lblpymtdate.Text);
        dt = data.GetDataTable(SelectCmd, "nfs");
        lblinvalidcin.Text = dt.Rows[0]["sum"].ToString();

        if (Convert.ToDecimal(dt.Rows[0]["sum"].ToString()) > 0)
        {
            hylnkinvalidcin.Visible = true;
            lnkinvalidcin.Visible = true;
        }


        SelectQuery = new StringBuilder(@"select count(rbi.cin) from rbi_response_txns_details  rbi
                                            inner join transactions_eod_cin eod on eod.cin=rbi.cin where rbi.isprocessed is null and totaltxnamt>sgst_total and to_char(rbi.paymentdatetime,'DD/MM/YYYY')=@paymentdate ");
        SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdate", lblpymtdate.Text);
        dt = data.GetDataTable(SelectCmd, "nfs");
        lblmoreamt.Text = dt.Rows[0]["count"].ToString();

        if (Convert.ToInt32(dt.Rows[0]["count"].ToString()) > 0)
        {
            hylnkmoreamt.Visible = true;
            lnkmoreamt.Visible = true;
        }


        SelectQuery = new StringBuilder(@"select count(rbi.cin) from rbi_response_txns_details  rbi
                                            inner join transactions_eod_cin eod on eod.cin=rbi.cin where rbi.isprocessed is null and totaltxnamt<sgst_total and to_char(rbi.paymentdatetime,'DD/MM/YYYY')=@paymentdate ");
        SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdate", lblpymtdate.Text);
        dt = data.GetDataTable(SelectCmd, "nfs");
        lbllessamt.Text = dt.Rows[0]["count"].ToString();

        if (Convert.ToInt32(dt.Rows[0]["count"].ToString()) > 0)
        {
            hylnklessamt.Visible = true;
            lnklessamt.Visible = true;
        }


    }
    protected void lnkmissingcin_Click(object sender, EventArgs e)
    {
        StringBuilder SelectQuery = new StringBuilder(@"select cin from transactions_eod_cin where isprocessed is null and cin not in (select cin from rbi_response_txns_details) and to_char(paymentdatetime,'DD/MM/YYYY')=@paymentdate");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdate", lblpymtdate.Text);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
        processCin(dt, "1");

    }

    private void processCin(DataTable dt, string moetype)
    {

        if (dt.Rows.Count > 0)
        {
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            string Qry = @"INSERT INTO moe_compact(cin, status, userid, ipaddress, insertdatetime,moetype)
                                    VALUES (@cin, @status, @userid, @ipaddress, now(), @moetype);";
            string ipaddrs = PostgresGetData.GetIP4Address();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                cmd.Parameters.AddWithValue("@cin", dt.Rows[i]["cin"].ToString());
                cmd.Parameters.AddWithValue("@status", "M");
                //cmd.Parameters.AddWithValue("@filedate", Utility.converttodate_from_DDMMYYYY(dt.Rows[i]["filedate"].ToString()));
                cmd.Parameters.AddWithValue("@userid", Session["USER_ID"].ToString());
                cmd.Parameters.AddWithValue("@ipaddress", ipaddrs);
                cmd.Parameters.AddWithValue("@moetype", moetype);
                cmdList.Add(cmd);


                StringBuilder updateqry = new StringBuilder(@"update transactions_eod_cin set isprocessed=@isprocessed where cin=@cin ;");
                NpgsqlCommand Up1cmd = new NpgsqlCommand(updateqry.ToString());
                Up1cmd.Parameters.AddWithValue("@isprocessed", "Y");
                Up1cmd.Parameters.AddWithValue("@cin", dt.Rows[i]["cin"].ToString());
                cmdList.Add(Up1cmd);


                if (moetype != "1")
                {
                    updateqry = new StringBuilder(@"update rbi_response_txns_details set isprocessed=@isprocessed where cin=@cin ;");
                    Up1cmd = new NpgsqlCommand(updateqry.ToString());
                    Up1cmd.Parameters.AddWithValue("@isprocessed", "Y");
                    Up1cmd.Parameters.AddWithValue("@cin", dt.Rows[i]["cin"].ToString());
                    cmdList.Add(Up1cmd);
                }

            }

            int savedrec = data.SaveData(cmdList, "nfs");
            if (savedrec > 0)
            {
                string script = "<script type='text/javascript'>alert('Action completed successfully.');window.location='/Moe/CinConsiderForMoe.aspx';</script>";
                ClientScript.RegisterStartupScript(GetType(), "Message", script);
            }
        }


    }
    protected void lnkinvalidcin_Click(object sender, EventArgs e)
    {
        StringBuilder SelectQuery = new StringBuilder(@"select cin from rbi_response_txns_details where isprocessed is null and cin not in (select cin from transactions_eod_cin) and to_char(paymentdatetime,'DD/MM/YYYY')=@paymentdate");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdate", lblpymtdate.Text);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
        processCin(dt, "2");
    }
    protected void lnkmoreamt_Click(object sender, EventArgs e)
    {
        StringBuilder SelectQuery = new StringBuilder(@"select rbi.cin from rbi_response_txns_details  rbi
                                            inner join transactions_eod_cin eod on eod.cin=rbi.cin where rbi.isprocessed is null and totaltxnamt>sgst_total and to_char(rbi.paymentdatetime,'DD/MM/YYYY')=@paymentdate");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
        SelectCmd.Parameters.AddWithValue("@paymentdate", lblpymtdate.Text);
        processCin(dt, "3");
    }
    protected void lnklessamt_Click(object sender, EventArgs e)
    {
        StringBuilder SelectQuery = new StringBuilder(@"select rbi.cin from rbi_response_txns_details  rbi
                                            inner join transactions_eod_cin eod on eod.cin=rbi.cin where rbi.isprocessed is null and totaltxnamt<sgst_total and to_char(rbi.paymentdatetime,'DD/MM/YYYY')=@paymentdate");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdate", lblpymtdate.Text);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
        processCin(dt, "4");
    }
}
