﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Threading;
using System.Globalization;

public partial class PAO_Dashboard : System.Web.UI.Page
{
    MD5Util md5util = new MD5Util();
    PostgresGetData data = new PostgresGetData();

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnshowdata_Click(object sender, EventArgs e)
    {
        StringBuilder SelectQuery = new StringBuilder(@"select COALESCE(count(cin),'0') txns,COALESCE(sum(sgst_total),'0.00') totalsum,mode from transactions_eod_cin where to_char(paymentdatetime,'DD/MM/YYYY')=@paymentdate and cin not in (select cin from moe_compact) group by mode ");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdate", txtdate.Text);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
        if (dt.Rows.Count > 0)
        {
            lblpymtdate.Text = txtdate.Text;
            tbldata.Visible = true;
            
            decimal epy_otc_amt=0,ner_amt=0;
            int epy_otc_txns=0,ner_txns=0;
            
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i]["mode"].ToString() == "ner")
                {
                    ner_amt = Convert.ToDecimal(dt.Rows[i]["totalsum"].ToString());
                    ner_txns = Convert.ToInt32(dt.Rows[i]["txns"].ToString());

                }
                if (dt.Rows[i]["mode"].ToString() == "epy")
                {
                    epy_otc_amt = epy_otc_amt + Convert.ToDecimal(dt.Rows[i]["totalsum"].ToString());
                    epy_otc_txns = epy_otc_txns + Convert.ToInt32(dt.Rows[i]["txns"].ToString());
                }
                if (dt.Rows[i]["mode"].ToString() == "otc")
                {
                    epy_otc_amt = epy_otc_amt + Convert.ToDecimal(dt.Rows[i]["totalsum"].ToString());
                    epy_otc_txns = epy_otc_txns + Convert.ToInt32(dt.Rows[i]["txns"].ToString());
                }
            }


            lblneramt.Text = ner_amt.ToString();
            hylnkner.Text = "No. of Transactions " + ner_txns.ToString();

            lblpsbamt.Text = epy_otc_amt.ToString();
            hylnkpsb.Text = "No. of Transactions " + epy_otc_txns.ToString();


            SelectQuery = new StringBuilder(@"select COALESCE(sum(sgst_tax),'0.00') tax, COALESCE(sum(sgst_intr),'0.00') intr, COALESCE(sum(sgst_pnlty),'0.00') pnlty, COALESCE(sum(sgst_fee),'0') fee, COALESCE(sum(sgst_oth),'0.00') oth, COALESCE(sum(sgst_total),'0.00') total from transactions_eod_cin  where to_char(paymentdatetime,'DD/MM/YYYY')=@paymentdate ");
             SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
             SelectCmd.Parameters.AddWithValue("@paymentdate", txtdate.Text);
             dt = data.GetDataTable(SelectCmd, "nfs");

             if (dt.Rows.Count > 0)
             {
                 lbltax.Text = dt.Rows[0]["tax"].ToString();
                 lblintr.Text = dt.Rows[0]["intr"].ToString();
                 lblpnlty.Text = dt.Rows[0]["pnlty"].ToString();
                 lblfee.Text = dt.Rows[0]["fee"].ToString();
                 lbloth.Text = dt.Rows[0]["oth"].ToString();
                 lbltotal.Text = dt.Rows[0]["total"].ToString();
             }

        }
    }
}