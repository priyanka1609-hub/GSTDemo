﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;

public partial class PAO_PaoHome : System.Web.UI.Page
{
    message msg = new message();
    int gsttxns, rbitxns;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            {
                txtdate.Text = DateTime.Today.AddDays(-1).ToString("dd/MM/yyyy");
                checkPaymentDate(txtdate.Text);

            }
       
    }
    protected void btnshowdata_Click(object sender, EventArgs e)
    {
        checkPaymentDate(txtdate.Text);
    }

    private void checkPaymentDate(string selectDate)
    {
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select count(cin) from transactions_eod_cin  where to_char(paymentdatetime,'DD/MM/YYYY')=@paymentdate and sgst_total != 0.00");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdate", selectDate);
        DataTable dtgst = data.GetDataTable(SelectCmd, "nfs");

        SelectQuery = new StringBuilder(@"select count(cin) from rbi_response_txns_details  where to_char(paymentdatetime,'DD/MM/YYYY')=@paymentdate");
        SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdate", selectDate);
        DataTable dtrbi = data.GetDataTable(SelectCmd, "nfs");

         gsttxns = Convert.ToInt32(dtgst.Rows[0]["count"].ToString());
         rbitxns = Convert.ToInt32(dtrbi.Rows[0]["count"].ToString());

         lblgstntxncount.Text = gsttxns.ToString();
        lblrbitxncount.Text = rbitxns.ToString();

        if (gsttxns == 0 && rbitxns == 0)
        {
            divgstn.Visible = false;
            divmatched.Visible = false;
            divmatched.Visible = false;
            divrbi.Visible = false;
            msg.Show("Nothing to display as no transaction found from GSTN and RBI for this Date");
        }
        else if (gsttxns == 0)
        {
            divrbi.Visible = true;
            divgstn.Visible = false;
            divmatched.Visible = false;
            divunmatched.Visible = false;
            filltiles("R", selectDate);
            msg.Show("No transaction found from GSTN for this Date");
        }
        else if (rbitxns == 0)
        {
            divgstn.Visible = true;
            divrbi.Visible = false;
            divmatched.Visible = false;
            divunmatched.Visible = false;
            filltiles("G", selectDate);
            msg.Show("No transaction found from RBI for this Date");
        }
        else
        {
            divgstn.Visible = true;
            divrbi.Visible = true;
            divmatched.Visible = true;
            divunmatched.Visible = true;
            filltiles("B", selectDate);
        }
        
    }

    private void filltiles(string flg, string date)
    {
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery;
        NpgsqlCommand SelectCmd;
        DataTable dt;
        if (flg == "R" || flg == "B")
        {
            SelectQuery = new StringBuilder(@"select COALESCE(sum(totaltxnamt),'0.00') sum from rbi_response_txns_details where isprocessed is null and to_char(paymentdatetime,'DD/MM/YYYY')=@paymentdate ");
            SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
            SelectCmd.Parameters.AddWithValue("@paymentdate", date);
            dt = data.GetDataTable(SelectCmd, "nfs");
            lblrbiamt.Text = dt.Rows[0]["sum"].ToString();
        }

        if (flg == "G" || flg == "B")
        {
            SelectQuery = new StringBuilder(@"select COALESCE(sum(sgst_total),'0.00') sum from transactions_eod_cin  where isprocessed is null and to_char(paymentdatetime,'DD/MM/YYYY')=@paymentdate ");
            SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
            SelectCmd.Parameters.AddWithValue("@paymentdate", date);
            dt = data.GetDataTable(SelectCmd, "nfs");
            lblgstamt.Text = dt.Rows[0]["sum"].ToString();
        }

        if (flg == "B")
        {
            MD5Util md5util = new MD5Util();

            SelectQuery = new StringBuilder(@"select count(rbi.cin), COALESCE(sum(amt),'0.00') sum from rbi_response_txns_details rbi
                                        inner join transactions_eod_cin tec on tec.cin=rbi.cin
                                        where rbi.isprocessed is null and tec.isprocessed is null and totaltxnamt=sgst_total and to_char(rbi.paymentdatetime,'DD/MM/YYYY')=@paymentdate ");
            SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
            SelectCmd.Parameters.AddWithValue("@paymentdate", date);
            dt = data.GetDataTable(SelectCmd, "nfs");
            lblmatched.Text = dt.Rows[0]["sum"].ToString();

            lblmatchedcount.Text = dt.Rows[0]["count"].ToString();

            if (dt.Rows[0]["sum"].ToString() != "0.00")
            {
                hylnkmatched.Visible = true;
                hylnkmatched.NavigateUrl = md5util.CreateTamperProofURL("~/Compact/GenerateCompact.aspx", null, "dt=" + MD5Util.Encrypt(date, true));
            }

            lblunmatched.Text = Math.Abs(Convert.ToDecimal(lblrbiamt.Text) - Convert.ToDecimal(lblgstamt.Text)).ToString();

            hylnkunmatched.NavigateUrl = md5util.CreateTamperProofURL("~/PAO/UnmatchedAmount.aspx", null, "dt=" + MD5Util.Encrypt(date, true));
        }

    }
}