﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Cin
/// </summary>
public class Cin
{
	public Cin()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public string cin { get; set; }
    public string txnid { get; set; }
    public string utr_num { get; set; }
    public string ack_num { get; set; }
    public string bank_ref_num { get; set; }
    public string status { get; set; }
    public string igst_amt { get; set; }
    public string sgst_amt { get; set; }
    public string cgst_amt { get; set; }
    public string total_amt { get; set; }
    public string payment_dt { get; set; }
    public string payment_tim { get; set; }
    public string gstin { get; set; }
    public string temp_id { get; set; }
    public string cpin { get; set; }
    public string instrument_ty { get; set; }
    public string bank_cd { get; set; }
    public string br_ifsc_cd { get; set; }
    public string br_location { get; set; }
    public string br_name { get; set; }
    public string instrument_no { get; set; }
    public string instrument_micr_cd { get; set; }
    public string submission_dt { get; set; }
    public string submission_tim { get; set; }
    public string error_cd { get; set; }
    public string message { get; set; }
}