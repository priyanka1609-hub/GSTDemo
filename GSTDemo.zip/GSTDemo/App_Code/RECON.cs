﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for RECON
/// </summary>
public class RECON
{
	public RECON()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public string ner_recon_dt { get; set; }
    public string othr_recon_dt { get; set; }
    public string e_scroll_num { get; set; }
    public string cin { get; set; }
    public string cpin { get; set; }
    public string gstin { get; set; }
   



}