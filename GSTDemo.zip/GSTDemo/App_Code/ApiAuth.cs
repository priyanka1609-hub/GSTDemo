﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ApiAuth
/// </summary>
public class ApiAuth
{
    public string status_cd { get; set; }
    public string auth_token { get; set; }
    public string sek { get; set; }
    public Error error { get; set; }

    public class Error
    {
        public string message { get; set; }
        public string error_cd { get; set; }
    }
}
