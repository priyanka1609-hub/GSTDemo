﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for UnprocessedFileReasons
/// </summary>
public static class UnprocessedFileReasons
{
    public static string INVALID_FILE_HASH = "Invalid file hash";
    public static string INVALID_HMAC = "Invalid HMAC";
}