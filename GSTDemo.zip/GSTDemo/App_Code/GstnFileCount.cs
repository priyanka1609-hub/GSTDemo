﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for GstnFileCount
/// </summary>
public class GstnFileCount
{
    public string eod_closed { get; set; }
    public string date { get; set; }
    public string num_files { get; set; }
}

