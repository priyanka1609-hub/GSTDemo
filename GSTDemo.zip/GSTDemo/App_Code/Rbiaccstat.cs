﻿using System;
using System.Xml.Serialization;
using System.Collections.Generic;
namespace Rbiaccstat
{
    [XmlRoot(ElementName = "ClrSysMmbId")]
    public class ClrSysMmbId
    {
        [XmlElement(ElementName = "MmbId")]
        public string MmbId { get; set; }
    }

    [XmlRoot(ElementName = "FinInstnId")]
    public class FinInstnId
    {
        [XmlElement(ElementName = "ClrSysMmbId")]
        public ClrSysMmbId ClrSysMmbId { get; set; }
    }

    [XmlRoot(ElementName = "FIId")]
    public class FIId
    {
        [XmlElement(ElementName = "FinInstnId")]
        public FinInstnId FinInstnId { get; set; }
    }

    [XmlRoot(ElementName = "Fr")]
    public class Fr
    {
        [XmlElement(ElementName = "FIId")]
        public FIId FIId { get; set; }
    }

    [XmlRoot(ElementName = "Othr")]
    public class Othr
    {
        [XmlElement(ElementName = "Id")]
        public string Id { get; set; }
    }

    [XmlRoot(ElementName = "OrgId")]
    public class OrgId
    {
        [XmlElement(ElementName = "Id")]
        public Id Id { get; set; }
        [XmlElement(ElementName = "Othr")]
        public Othr Othr { get; set; }
    }

    [XmlRoot(ElementName = "Id")]
    public class Id
    {
        [XmlElement(ElementName = "OrgId")]
        public OrgId OrgId { get; set; }
        [XmlElement(ElementName = "Othr")]
        public Othr Othr { get; set; }
    }

    [XmlRoot(ElementName = "To")]
    public class To
    {
        [XmlElement(ElementName = "OrgId")]
        public OrgId OrgId { get; set; }
    }

    [XmlRoot(ElementName = "AppHdr")]
    public class AppHdr
    {
        [XmlElement(ElementName = "Fr")]
        public Fr Fr { get; set; }
        [XmlElement(ElementName = "To")]
        public To To { get; set; }
        [XmlElement(ElementName = "BizMsgIdr")]
        public string BizMsgIdr { get; set; }
        [XmlElement(ElementName = "MsgDefIdr")]
        public string MsgDefIdr { get; set; }
        [XmlElement(ElementName = "BizSvc")]
        public string BizSvc { get; set; }
        [XmlElement(ElementName = "CreDt")]
        public string CreDt { get; set; }
    }

    [XmlRoot(ElementName = "GrpHdr")]
    public class GrpHdr
    {
        [XmlElement(ElementName = "MsgId")]
        public string MsgId { get; set; }
        [XmlElement(ElementName = "CreDtTm")]
        public string CreDtTm { get; set; }
    }

    [XmlRoot(ElementName = "StmtPgntn")]
    public class StmtPgntn
    {
        [XmlElement(ElementName = "PgNb")]
        public string PgNb { get; set; }
        [XmlElement(ElementName = "LastPgInd")]
        public string LastPgInd { get; set; }
    }

    [XmlRoot(ElementName = "FrToDt")]
    public class FrToDt
    {
        [XmlElement(ElementName = "FrDtTm")]
        public string FrDtTm { get; set; }
        [XmlElement(ElementName = "ToDtTm")]
        public string ToDtTm { get; set; }
    }

    [XmlRoot(ElementName = "Acct")]
    public class Acct
    {
        [XmlElement(ElementName = "Id")]
        public Id Id { get; set; }
    }

    [XmlRoot(ElementName = "CdOrPrtry")]
    public class CdOrPrtry
    {
        [XmlElement(ElementName = "Cd")]
        public string Cd { get; set; }
    }

    [XmlRoot(ElementName = "Tp")]
    public class Tp
    {
        [XmlElement(ElementName = "CdOrPrtry")]
        public CdOrPrtry CdOrPrtry { get; set; }
    }

    [XmlRoot(ElementName = "Amt")]
    public class Amt
    {
        [XmlAttribute(AttributeName = "Ccy")]
        public string Ccy { get; set; }
        [XmlText]
        public string Text { get; set; }
    }

    [XmlRoot(ElementName = "Dt")]
    public class Dt
    {
        [XmlElement(ElementName = "DtTm")]
        public string DtTm { get; set; }
    }

    [XmlRoot(ElementName = "Bal")]
    public class Bal
    {
        [XmlElement(ElementName = "Tp")]
        public Tp Tp { get; set; }
        [XmlElement(ElementName = "Amt")]
        public Amt Amt { get; set; }
        [XmlElement(ElementName = "CdtDbtInd")]
        public string CdtDbtInd { get; set; }
        [XmlElement(ElementName = "Dt")]
        public Dt Dt { get; set; }
    }

    [XmlRoot(ElementName = "TtlCdtNtries")]
    public class TtlCdtNtries
    {
        [XmlElement(ElementName = "NbOfNtries")]
        public string NbOfNtries { get; set; }
        [XmlElement(ElementName = "Sum")]
        public string Sum { get; set; }
    }

    [XmlRoot(ElementName = "TtlDbtNtries")]
    public class TtlDbtNtries
    {
        [XmlElement(ElementName = "NbOfNtries")]
        public string NbOfNtries { get; set; }
        [XmlElement(ElementName = "Sum")]
        public string Sum { get; set; }
    }

    [XmlRoot(ElementName = "TxsSummry")]
    public class TxsSummry
    {
        [XmlElement(ElementName = "TtlCdtNtries")]
        public TtlCdtNtries TtlCdtNtries { get; set; }
        [XmlElement(ElementName = "TtlDbtNtries")]
        public TtlDbtNtries TtlDbtNtries { get; set; }
    }

    [XmlRoot(ElementName = "BookgDt")]
    public class BookgDt
    {
        [XmlElement(ElementName = "Dt")]
        public string Dt { get; set; }
    }

    [XmlRoot(ElementName = "ValDt")]
    public class ValDt
    {
        [XmlElement(ElementName = "Dt")]
        public string Dt { get; set; }
    }

    [XmlRoot(ElementName = "Prtry")]
    public class Prtry
    {
        [XmlElement(ElementName = "Cd")]
        public string Cd { get; set; }
    }

    [XmlRoot(ElementName = "BkTxCd")]
    public class BkTxCd
    {
        [XmlElement(ElementName = "Prtry")]
        public Prtry Prtry { get; set; }
    }

    [XmlRoot(ElementName = "Ntry")]
    public class Ntry
    {
        [XmlElement(ElementName = "NtryRef")]
        public string NtryRef { get; set; }
        [XmlElement(ElementName = "Amt")]
        public Amt Amt { get; set; }
        [XmlElement(ElementName = "CdtDbtInd")]
        public string CdtDbtInd { get; set; }
        [XmlElement(ElementName = "RvslInd")]
        public string RvslInd { get; set; }
        [XmlElement(ElementName = "Sts")]
        public string Sts { get; set; }
        [XmlElement(ElementName = "BookgDt")]
        public BookgDt BookgDt { get; set; }
        [XmlElement(ElementName = "ValDt")]
        public ValDt ValDt { get; set; }
        [XmlElement(ElementName = "BkTxCd")]
        public BkTxCd BkTxCd { get; set; }
    }

    [XmlRoot(ElementName = "Stmt")]
    public class Stmt
    {
        [XmlElement(ElementName = "Id")]
        public string Id { get; set; }
        [XmlElement(ElementName = "StmtPgntn")]
        public StmtPgntn StmtPgntn { get; set; }
        [XmlElement(ElementName = "CreDtTm")]
        public string CreDtTm { get; set; }
        [XmlElement(ElementName = "FrToDt")]
        public FrToDt FrToDt { get; set; }
        [XmlElement(ElementName = "Acct")]
        public Acct Acct { get; set; }
        [XmlElement(ElementName = "Bal")]
        public List<Bal> Bal { get; set; }
        [XmlElement(ElementName = "TxsSummry")]
        public TxsSummry TxsSummry { get; set; }
        [XmlElement(ElementName = "Ntry")]
        public List<Ntry> Ntry { get; set; }
    }

    [XmlRoot(ElementName = "BkToCstmrStmt")]
    public class BkToCstmrStmt
    {
        [XmlElement(ElementName = "GrpHdr")]
        public GrpHdr GrpHdr { get; set; }
        [XmlElement(ElementName = "Stmt")]
        public Stmt Stmt { get; set; }
    }

    [XmlRoot(ElementName = "Document")]
    public class Document
    {
        [XmlElement(ElementName = "BkToCstmrStmt")]
        public BkToCstmrStmt BkToCstmrStmt { get; set; }
    }

    [XmlRoot(ElementName = "RequestPayload")]
    public class RequestPayload
    {
        [XmlElement(ElementName = "AppHdr")]
        public AppHdr AppHdr { get; set; }
        [XmlElement(ElementName = "Document")]
        public Document Document { get; set; }
    }
}