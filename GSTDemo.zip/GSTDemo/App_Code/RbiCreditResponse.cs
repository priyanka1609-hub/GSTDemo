﻿using System;
using System.Xml.Serialization;
using System.Collections.Generic;
namespace RbiCreditResponse
{
    [XmlRoot(ElementName = "ClrSysMmbId")]
    public class ClrSysMmbId
    {
        [XmlElement(ElementName = "MmbId")]
        public string MmbId { get; set; }
    }

    [XmlRoot(ElementName = "FinInstnId")]
    public class FinInstnId
    {
        [XmlElement(ElementName = "ClrSysMmbId")]
        public ClrSysMmbId ClrSysMmbId { get; set; }
    }

    [XmlRoot(ElementName = "FIId")]
    public class FIId
    {
        [XmlElement(ElementName = "FinInstnId")]
        public FinInstnId FinInstnId { get; set; }
    }

    [XmlRoot(ElementName = "Fr")]
    public class Fr
    {
        [XmlElement(ElementName = "FIId")]
        public FIId FIId { get; set; }
    }

    [XmlRoot(ElementName = "Othr")]
    public class Othr
    {
        [XmlElement(ElementName = "Id")]
        public string Id { get; set; }
    }

    [XmlRoot(ElementName = "OrgId")]
    public class OrgId
    {
        [XmlElement(ElementName = "Id")]
        public Id Id { get; set; }
        [XmlElement(ElementName = "Othr")]
        public Othr Othr { get; set; }
    }

    [XmlRoot(ElementName = "Id")]
    public class Id
    {
        [XmlElement(ElementName = "OrgId")]
        public OrgId OrgId { get; set; }
        [XmlElement(ElementName = "Othr")]
        public Othr Othr { get; set; }
    }

    [XmlRoot(ElementName = "To")]
    public class To
    {
        [XmlElement(ElementName = "OrgId")]
        public OrgId OrgId { get; set; }
    }

    [XmlRoot(ElementName = "AppHdr")]
    public class AppHdr
    {
        [XmlElement(ElementName = "Fr")]
        public Fr Fr { get; set; }
        [XmlElement(ElementName = "To")]
        public To To { get; set; }
        [XmlElement(ElementName = "BizMsgIdr")]
        public string BizMsgIdr { get; set; }
        [XmlElement(ElementName = "MsgDefIdr")]
        public string MsgDefIdr { get; set; }
        [XmlElement(ElementName = "BizSvc")]
        public string BizSvc { get; set; }
        [XmlElement(ElementName = "CreDt")]
        public string CreDt { get; set; }
    }

    [XmlRoot(ElementName = "GrpHdr")]
    public class GrpHdr
    {
        [XmlElement(ElementName = "MsgId")]
        public string MsgId { get; set; }
        [XmlElement(ElementName = "CreDtTm")]
        public string CreDtTm { get; set; }
    }

    [XmlRoot(ElementName = "NtfctnPgntn")]
    public class NtfctnPgntn
    {
        [XmlElement(ElementName = "PgNb")]
        public string PgNb { get; set; }
        [XmlElement(ElementName = "LastPgInd")]
        public string LastPgInd { get; set; }
    }

    [XmlRoot(ElementName = "Acct")]
    public class Acct
    {
        [XmlElement(ElementName = "Id")]
        public Id Id { get; set; }
    }

    [XmlRoot(ElementName = "TtlCdtNtries")]
    public class TtlCdtNtries
    {
        [XmlElement(ElementName = "NbOfNtries")]
        public string NbOfNtries { get; set; }
        [XmlElement(ElementName = "Sum")]
        public string Sum { get; set; }
    }

    [XmlRoot(ElementName = "TxsSummry")]
    public class TxsSummry
    {
        [XmlElement(ElementName = "TtlCdtNtries")]
        public TtlCdtNtries TtlCdtNtries { get; set; }
    }

    [XmlRoot(ElementName = "ValDt")]
    public class ValDt
    {
        [XmlElement(ElementName = "Dt")]
        public string Dt { get; set; }
    }

    [XmlRoot(ElementName = "Btch")]
    public class Btch
    {
        [XmlElement(ElementName = "NbOfTxs")]
        public string NbOfTxs { get; set; }
    }

    [XmlRoot(ElementName = "Refs")]
    public class Refs
    {
        [XmlElement(ElementName = "MsgId")]
        public string MsgId { get; set; }
        [XmlElement(ElementName = "AcctSvcrRef")]
        public string AcctSvcrRef { get; set; }
        [XmlElement(ElementName = "InstrId")]
        public string InstrId { get; set; }
        [XmlElement(ElementName = "EndToEndId")]
        public string EndToEndId { get; set; }
        [XmlElement(ElementName = "TxId")]
        public string TxId { get; set; }
        [XmlElement(ElementName = "ClrSysRef")]
        public string ClrSysRef { get; set; }
        [XmlElement(ElementName = "ChqNb")]
        public string ChqNb { get; set; }
    }

    [XmlRoot(ElementName = "BrnchId")]
    public class BrnchId
    {
        [XmlElement(ElementName = "Id")]
        public string Id { get; set; }
    }

    [XmlRoot(ElementName = "DbtrAgt")]
    public class DbtrAgt
    {
        [XmlElement(ElementName = "FinInstnId")]
        public FinInstnId FinInstnId { get; set; }
        [XmlElement(ElementName = "BrnchId")]
        public BrnchId BrnchId { get; set; }
    }

    [XmlRoot(ElementName = "RltdAgts")]
    public class RltdAgts
    {
        [XmlElement(ElementName = "DbtrAgt")]
        public DbtrAgt DbtrAgt { get; set; }
    }

    [XmlRoot(ElementName = "Cdtr")]
    public class Cdtr
    {
        [XmlElement(ElementName = "TaxId")]
        public string TaxId { get; set; }
    }

    [XmlRoot(ElementName = "TaxRmt")]
    public class TaxRmt
    {
        [XmlElement(ElementName = "Cdtr")]
        public Cdtr Cdtr { get; set; }
        [XmlElement(ElementName = "AdmstnZone")]
        public string AdmstnZone { get; set; }
        [XmlElement(ElementName = "TtlTaxAmt")]
        public string TtlTaxAmt { get; set; }
    }

    [XmlRoot(ElementName = "Strd")]
    public class Strd
    {
        [XmlElement(ElementName = "TaxRmt")]
        public TaxRmt TaxRmt { get; set; }
    }

    [XmlRoot(ElementName = "RmtInf")]
    public class RmtInf
    {
        [XmlElement(ElementName = "Strd")]
        public Strd Strd { get; set; }
    }

    [XmlRoot(ElementName = "RltdDts")]
    public class RltdDts
    {
        [XmlElement(ElementName = "AccptncDtTm")]
        public string AccptncDtTm { get; set; }
        [XmlElement(ElementName = "TxDtTm")]
        public string TxDtTm { get; set; }
    }

    [XmlRoot(ElementName = "TxDtls")]
    public class TxDtls
    {
        [XmlElement(ElementName = "Refs")]
        public Refs Refs { get; set; }
        [XmlElement(ElementName = "Amt")]
        public string Amt { get; set; }
        [XmlElement(ElementName = "RltdAgts")]
        public RltdAgts RltdAgts { get; set; }
        [XmlElement(ElementName = "RmtInf")]
        public RmtInf RmtInf { get; set; }
        [XmlElement(ElementName = "RltdDts")]
        public RltdDts RltdDts { get; set; }
        [XmlElement(ElementName = "AddtlTxInf")]
        public string AddtlTxInf { get; set; }
    }

    [XmlRoot(ElementName = "NtryDtls")]
    public class NtryDtls
    {
        [XmlElement(ElementName = "Btch")]
        public Btch Btch { get; set; }
        [XmlElement(ElementName = "TxDtls")]
        public List<TxDtls> TxDtls { get; set; }
    }

    [XmlRoot(ElementName = "Ntry")]
    public class Ntry
    {
        [XmlElement(ElementName = "NtryRef")]
        public string NtryRef { get; set; }
        [XmlElement(ElementName = "Amt")]
        public string Amt { get; set; }
        [XmlElement(ElementName = "ValDt")]
        public ValDt ValDt { get; set; }
        [XmlElement(ElementName = "NtryDtls")]
        public NtryDtls NtryDtls { get; set; }
    }

    [XmlRoot(ElementName = "Ntfctn")]
    public class Ntfctn
    {
        [XmlElement(ElementName = "Id")]
        public string Id { get; set; }
        [XmlElement(ElementName = "NtfctnPgntn")]
        public NtfctnPgntn NtfctnPgntn { get; set; }
        [XmlElement(ElementName = "CreDtTm")]
        public string CreDtTm { get; set; }
        [XmlElement(ElementName = "Acct")]
        public Acct Acct { get; set; }
        [XmlElement(ElementName = "TxsSummry")]
        public TxsSummry TxsSummry { get; set; }
        [XmlElement(ElementName = "Ntry")]
        public List<Ntry> Ntry { get; set; }
    }

    [XmlRoot(ElementName = "BkToCstmrDbtCdtNtfctn")]
    public class BkToCstmrDbtCdtNtfctn
    {
        [XmlElement(ElementName = "GrpHdr")]
        public GrpHdr GrpHdr { get; set; }
        [XmlElement(ElementName = "Ntfctn")]
        public Ntfctn Ntfctn { get; set; }
    }

    [XmlRoot(ElementName = "Document")]
    public class Document
    {
        [XmlElement(ElementName = "BkToCstmrDbtCdtNtfctn")]
        public BkToCstmrDbtCdtNtfctn BkToCstmrDbtCdtNtfctn { get; set; }
    }

    [XmlRoot(ElementName = "RequestPayload")]
    public class RequestPayload
    {
        [XmlElement(ElementName = "AppHdr")]
        public AppHdr AppHdr { get; set; }
        [XmlElement(ElementName = "Document")]
        public Document Document { get; set; }
    }

}