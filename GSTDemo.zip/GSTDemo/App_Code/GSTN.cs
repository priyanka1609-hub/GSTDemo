﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Security.Cryptography;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Crypto.Parameters;
using System.Text;
using System.Net;
using System.IO;
using GstDelhi.PostgresData;
using Newtonsoft.Json;
using Npgsql;
using ICSharpCode.SharpZipLib.GZip;
using ICSharpCode.SharpZipLib.Tar;
using System.Globalization;
using System.Data;




/// <summary>
/// Summary description for GSTN
/// </summary>
public class GSTN
{
    public GSTN()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public byte[] CreateKey()
    {
        try
        {
            RijndaelManaged Cipher = new RijndaelManaged();
            Cipher.GenerateKey();
            Cipher.KeySize = 256;
            Cipher.BlockSize = 256;
            Cipher.Mode = CipherMode.ECB;
            Cipher.Padding = PaddingMode.PKCS7;
            return (Cipher.Key);
        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
            return null;
        }

    }


    public bool apiAuthentication(string username, string pwd, string clientid, string clientsecret, string statecode, string url_auth)
    {
        bool result = false;

        //string filepath = HttpContext.Current.Server.MapPath(@"~/key/GSTN_G2A_SANDBOX_UAT_public.pem");
        string filepath = System.IO.Path.GetFullPath(Constants.Keys_Path + "GSTN_G2B_Prod_Public.pem");

        byte[] appkey = CreateKey();
        HttpContext.Current.Session.Add("appkey", Convert.ToBase64String(appkey));

        string Encrypted_App_key = encryptwithPK_PEM_key(appkey, filepath);
        string encrypted_pwd = encryptwithPK_PEM_pwd(pwd, Convert.ToBase64String(appkey));
        string tnxn_no = "DEL" + DateTime.Now.ToString("ddMMyyyy") + DateTime.Now.TimeOfDay.ToString().Replace(":", "").Replace(".", "");


        ServicePointManager.SecurityProtocol = (SecurityProtocolType)768 | (SecurityProtocolType)3072;
        string postString = "{\"action\":\"AUTHTOKEN\",\"app_key\":\"" + Encrypted_App_key + "\",\"username\":\"" + username + "\",\"password\":\"" + encrypted_pwd + "\"}";
        WebRequest myWebRequest = WebRequest.Create(url_auth);
        myWebRequest.ContentType = "application/json";
        myWebRequest.Method = "POST";

        myWebRequest.Headers.Add("Clientid", clientid);
        myWebRequest.Headers.Add("client-secret", clientsecret);
        myWebRequest.Headers.Add("state-cd", statecode);
        myWebRequest.Headers.Add("txn", tnxn_no);
        myWebRequest.Headers.Add("ip-usr", PostgresGetData.GetIP4Address());

        try
        {
            StreamWriter requestWriter = new StreamWriter(myWebRequest.GetRequestStream());
            requestWriter.Write(postString);
            requestWriter.Close();

            StreamReader responseReader = new StreamReader(myWebRequest.GetResponse().GetResponseStream());
            WebResponse myWebResponse = myWebRequest.GetResponse();
            Stream ReceiveStream = myWebResponse.GetResponseStream();
            Encoding encode = System.Text.Encoding.GetEncoding("utf-8");
            StreamReader readStream = new StreamReader(ReceiveStream, encode);
            string responseFromServer = readStream.ReadToEnd();

            if (GstnValidations.IsValidJson(responseFromServer))
            {
                ApiAuth values = JsonConvert.DeserializeObject<ApiAuth>(responseFromServer);
                PostgresGetData data = new PostgresGetData();
                string Qry = @"INSERT INTO auth_reqs(txnid, status, errcode, errmsg, edate) VALUES (@txnid, @status, @errcode, @errmsg, now()); SELECT lastval();";
                NpgsqlCommand objdbManager = new NpgsqlCommand(Qry);
                objdbManager.Parameters.AddWithValue("@txnid", tnxn_no);
                objdbManager.Parameters.AddWithValue("@status", values.status_cd);

                if (values.status_cd == "1")
                {
                    objdbManager.Parameters.AddWithValue("@errcode", System.DBNull.Value);
                    objdbManager.Parameters.AddWithValue("@errmsg", System.DBNull.Value);

                    HttpContext.Current.Session.Add("auth_token", values.auth_token);
                    HttpContext.Current.Session.Add("sek", values.sek);
                    HttpContext.Current.Session.Add("txnid", tnxn_no);
                    result = true;
                }
                else
                {
                    objdbManager.Parameters.AddWithValue("@errcode", values.error.error_cd);
                    objdbManager.Parameters.AddWithValue("@errmsg", values.error.message);

                    result = false;
                }

                int insertedrow = data.UpdateScalarData(objdbManager, "nfs");

                if (insertedrow > 0)
                {
                    HttpContext.Current.Session.Add("authreqid", insertedrow.ToString());
                }
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
            result = false;
        }

        return result;
    }

    public string encryptwithPK_PEM_key(byte[] planTextToEncrypt, string filePath)
    {

        try
        {
            var keyBytes = Convert.FromBase64String(System.IO.File.ReadAllText(filePath).Replace("\r\n", "").Replace("-----BEGIN RSA PUBLIC KEY-----", "").Replace("-----END RSA PUBLIC KEY-----", "")); // your key here

            string key = Convert.ToBase64String(keyBytes);
            AsymmetricKeyParameter asymmetricKeyParameter = PublicKeyFactory.CreateKey(keyBytes);
            RsaKeyParameters rsaKeyParameters = (RsaKeyParameters)asymmetricKeyParameter;
            RSAParameters rsaParameters = new RSAParameters();
            rsaParameters.Modulus = rsaKeyParameters.Modulus.ToByteArrayUnsigned();
            rsaParameters.Exponent = rsaKeyParameters.Exponent.ToByteArrayUnsigned();

            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(); rsa.ImportParameters(rsaParameters);


            byte[] ciphertext = rsa.Encrypt(planTextToEncrypt, false);
            string cipherresult = Convert.ToBase64String(ciphertext);
            return cipherresult;
        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
            return null;
        }

    }

    public string encryptwithPK_PEM_pwd(string textToEncrypt, string key)
    {
        try
        {
            AesManaged tdes = new AesManaged();
            tdes.Key = Convert.FromBase64String(key);
            tdes.Mode = CipherMode.ECB;
            tdes.Padding = PaddingMode.PKCS7;
            ICryptoTransform crypt = tdes.CreateEncryptor();
            byte[] plain = Encoding.UTF8.GetBytes(textToEncrypt);
            byte[] cipher = crypt.TransformFinalBlock(plain, 0, plain.Length);
            return Convert.ToBase64String(cipher);
        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
            return null;
        }
    }

    public string getFilesCount(string date, string filetype, string urlpay, string username, string clientid, string clientsecret, string statecode)
    {
        string returnval = "";
        string postString = "?action=FILECNT&state_cd=07&date=" + date + "&file_type=" + filetype + "";
        WebRequest myWebRequest = WebRequest.Create(urlpay + postString);
        myWebRequest.ContentType = "application/json";
        myWebRequest.Method = "GET";

        myWebRequest.Headers.Add("Clientid", clientid);
        myWebRequest.Headers.Add("client-secret", clientsecret);
        myWebRequest.Headers.Add("state-cd", statecode);
        myWebRequest.Headers.Add("txn", HttpContext.Current.Session["txnid"].ToString());
        myWebRequest.Headers.Add("ip-usr", PostgresGetData.GetIP4Address());
        myWebRequest.Headers.Add("auth-token", HttpContext.Current.Session["auth_token"].ToString().Trim());
        myWebRequest.Headers.Add("username", username);

        StreamReader responseReader = new StreamReader(myWebRequest.GetResponse().GetResponseStream());
        WebResponse myWebResponse = myWebRequest.GetResponse();
        Stream ReceiveStream = myWebResponse.GetResponseStream();
        Encoding encode = System.Text.Encoding.GetEncoding("utf-8");
        StreamReader readStream = new StreamReader(ReceiveStream, encode);

        string responseFromServer = readStream.ReadToEnd();

        if (GstnValidations.IsValidJson(responseFromServer))
        {
            string schemapath = HttpContext.Current.Server.MapPath(@"~/JsonSchemas/getFileCount_response_schema.json");
            GstnResponse values = JsonConvert.DeserializeObject<GstnResponse>(responseFromServer);
            if (values.status_cd == "1")
            {
                //if (GstnValidations.checkJsonSchema(responseFromServer, schemapath))
                //{
                //decrypt sek using appkey ---> [decrypted sek]
                byte[] sek = decrypt_sek(Convert.FromBase64String(HttpContext.Current.Session["appkey"].ToString().Trim()), HttpContext.Current.Session["sek"].ToString().Trim());
                //decrypt rek using decyrpted sek[sekres] -----> [decrypted rek]
                byte[] rek = decrypt_sek(sek, values.rek);
                //decrypt data using decrypted rek [sekres1]
                byte[] data = decrypt_sek(rek, values.data);

                string json = Encoding.UTF8.GetString(data);


                if (GstnValidations.checkHmac(rek, json, values.hmac))
                {
                    byte[] decodeJson = Convert.FromBase64String(json);
                    string finalJson = Encoding.UTF8.GetString(decodeJson);
                    GstnFileCount filecountval = JsonConvert.DeserializeObject<GstnFileCount>(finalJson);
                    int getRecordInsereted = insertFileCount(filetype, filecountval.eod_closed, filecountval.date, filecountval.num_files, "", "", values.status_cd);

                    if (getRecordInsereted > 0)
                    {
                        HttpContext.Current.Session.Add("filecntid", getRecordInsereted.ToString());
                        returnval = finalJson;
                    }
                }
                else
                {
                    int getRecordInsereted = insertFileCount(filetype, "", date, "", "", "Invalid HMAC", "");
                }
                //}
                ////else
                //{
                //    // Json Schema check failed
                //}
            }
            else
            {
                int getRecordInsereted = insertFileCount(filetype, "", date, "", values.error.error_cd, values.error.message, values.status_cd);
            }


        }

        else
        {
            // if invalid json
        }

        return returnval;
    }

    public byte[] decrypt_sek(byte[] AESKEY, string sek)
    {
        string key = Convert.ToBase64String(AESKEY);
        byte[] dataToDecrypt = Convert.FromBase64String(sek);
        var keyBytes = Convert.FromBase64String(key);
        AesManaged tdes = new AesManaged();
        tdes.KeySize = 256;
        tdes.BlockSize = 128;
        tdes.Key = keyBytes;
        tdes.Mode = CipherMode.ECB;
        tdes.Padding = PaddingMode.PKCS7;
        ICryptoTransform decrypt__1 = tdes.CreateDecryptor();
        byte[] deCipher = decrypt__1.TransformFinalBlock(dataToDecrypt, 0, dataToDecrypt.Length);
        tdes.Clear();
        return deCipher;
    }


    private int insertFileCount(string filetype, string eod_closed, string filedate, string num_files, string errcode, string errmsg, string status)
    {
        PostgresGetData getdata = new PostgresGetData();
        string tablename = string.Empty;
        if (filetype == "CIN")
        {
            tablename = "files_count_cin";
        }
        else
        {
            tablename = "files_count";
        }

        StringBuilder insert_qry = new StringBuilder("insert into  "+tablename+@"(filetype, eod_closed, filedate, num_files, edatetime, errcode, errmsg, authreqid,status) Values (@filetype,@eod_closed,@filedate,@num_files, now(),@errcode, @errmsg, @authreqid,@status); select lastval();");
        NpgsqlCommand insertCmd = new NpgsqlCommand(insert_qry.ToString());
        insertCmd.Parameters.AddWithValue("@filetype", filetype);

        if (string.IsNullOrEmpty(eod_closed))
        {
            insertCmd.Parameters.AddWithValue("@eod_closed", System.DBNull.Value);
        }
        else
        {
            insertCmd.Parameters.AddWithValue("@eod_closed", eod_closed);
        }

        insertCmd.Parameters.AddWithValue("@filedate", Utility.converttodate_from_DDMMYYYY(filedate));
        if (string.IsNullOrEmpty(num_files))
        {
            insertCmd.Parameters.AddWithValue("@num_files", System.DBNull.Value);
        }
        else
        {
            insertCmd.Parameters.AddWithValue("@num_files", num_files);
        }
        insertCmd.Parameters.AddWithValue("@authreqid", HttpContext.Current.Session["authreqid"].ToString());

        if (string.IsNullOrEmpty(errcode))
        {
            insertCmd.Parameters.AddWithValue("@errcode", System.DBNull.Value);
        }
        else
        {
            insertCmd.Parameters.AddWithValue("@errcode", errcode);
        }
        if (string.IsNullOrEmpty(errmsg))
        {
            insertCmd.Parameters.AddWithValue("@errmsg", System.DBNull.Value);
        }
        else
        {
            insertCmd.Parameters.AddWithValue("@errmsg", errmsg);
        }
        insertCmd.Parameters.AddWithValue("@status", status);
        int recordInsereted = getdata.UpdateScalarData(insertCmd, "nfs");
        return recordInsereted;
    }

    public string GetFileDetail(string fileno, string fileType, string filedate, string urlpay, string clientid, string clientsecret, string statecode, string username)
    {
        string returnval = "";
        PostgresGetData getdata = new PostgresGetData();
        string postString = "?action=FILEDTLS&state_cd=" + statecode + "&date=" + filedate + "&file_num=" + fileno + "&file_type=" + fileType + "";
        WebRequest myWebRequest = WebRequest.Create(urlpay + postString);
        myWebRequest.ContentType = "application/json";
        myWebRequest.Method = "GET";

        myWebRequest.Headers.Add("Clientid", clientid);
        myWebRequest.Headers.Add("client-secret", clientsecret);
        myWebRequest.Headers.Add("state-cd", statecode);
        myWebRequest.Headers.Add("txn", HttpContext.Current.Session["txnid"].ToString());
        myWebRequest.Headers.Add("ip-usr", PostgresGetData.GetIP4Address());
        myWebRequest.Headers.Add("auth-token", HttpContext.Current.Session["auth_token"].ToString().Trim());
        myWebRequest.Headers.Add("username", username);

        StreamReader responseReader = new StreamReader(myWebRequest.GetResponse().GetResponseStream());
        WebResponse myWebResponse = myWebRequest.GetResponse();
        Stream ReceiveStream = myWebResponse.GetResponseStream();
        Encoding encode = System.Text.Encoding.GetEncoding("utf-8");
        StreamReader readStream = new StreamReader(ReceiveStream, encode);

        string responseFromServer = readStream.ReadToEnd();
        if (GstnValidations.IsValidJson(responseFromServer))
        {
            string schemapath = HttpContext.Current.Server.MapPath(@"~/JsonSchemas/getFileDetails_response_schema.json");

            //if (GstnValidations.checkJsonSchema(responseFromServer, schemapath))
            //{
            GstnResponse values = JsonConvert.DeserializeObject<GstnResponse>(responseFromServer);
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

            if (values.status_cd == "1")
            {
                //decrypt sek using appkey ---> [decrypted sek]
                byte[] sek = decrypt_sek(Convert.FromBase64String(HttpContext.Current.Session["appkey"].ToString().Trim()), HttpContext.Current.Session["sek"].ToString().Trim());
                //decrypt rek using decyrpted sek[sekres] -----> [decrypted rek]
                byte[] rek = decrypt_sek(sek, values.rek);
                //decrypt data using decrypted rek [sekres1]
                byte[] data = decrypt_sek(rek, values.data);
                string json = Encoding.UTF8.GetString(data);
                if (GstnValidations.checkHmac(rek, json, values.hmac))
                {

                    string tablename = string.Empty;
                    if (fileType == "CIN")
                    {
                        tablename = "file_record_count_cin";
                    }
                    else
                    {
                        tablename = "file_record_count";
                    }
                    byte[] decodeJson = Convert.FromBase64String(json);
                    string finalJson = Encoding.UTF8.GetString(decodeJson);


                    Dictionary<string, string> valuess = JsonConvert.DeserializeObject<Dictionary<string, string>>(finalJson);
                    StringBuilder insert_qry = new StringBuilder("insert into "+tablename+@"(filetype, filedate, file_num, cnt, edatetime,filecntid) Values (@filetype,@filedate,@file_num,@cnt, now(),@filecntid); SELECT lastval();");
                    NpgsqlCommand insertCmd = new NpgsqlCommand(insert_qry.ToString());
                    insertCmd.Parameters.AddWithValue("@filetype", fileType);
                    insertCmd.Parameters.AddWithValue("@filedate", Utility.converttodate_from_DDMMYYYY(valuess["date"]));
                    insertCmd.Parameters.AddWithValue("@file_num", valuess["file_num"]);
                    insertCmd.Parameters.AddWithValue("@cnt", valuess["cnt"]);
                    insertCmd.Parameters.AddWithValue("@filecntid", HttpContext.Current.Session["filecntid"].ToString());
                    //cmdList.Add(insertCmd);
                    //int getRecordInsereted = getdata.SaveData(cmdList, "nfs");
                    int getRecordInsereted = getdata.UpdateScalarData(insertCmd, "nfs");
                    HttpContext.Current.Session.Add("frcid", getRecordInsereted.ToString());
                    HttpContext.Current.Session.Add("recordcount", valuess["cnt"]);
                    if (getRecordInsereted > 0)
                    {
                        if (Convert.ToInt32(valuess["file_num"]) > 0)
                        {
                            string filename = DownloadFile_URL(valuess["url"]);
                            string dataa = string.Empty;

                            //string fileHash = Utility.GetFileChecksum(@"D:\GSTN_dwnload_files\" + filename).ToLower();

                            //if (fileHash.Equals(valuess["hash"]))
                            //if (GstnValidations.checkFileChecksum(@"D:\GSTN_dwnload_files\" + filename, valuess["hash"]))
                            if (GstnValidations.checkFileChecksum(Constants.GSTN_FILE_DOWNLOAD_PATH + filename, valuess["hash"]))
                            {
                                updateDownloadedValidFileStatus(getRecordInsereted.ToString(), "Y", "");

                                string directoryName = ExtractTGZ(filename);

                                //string source = @"D:\GSTN_dwnload_files\" + filename + "";
                                string source = Constants.GSTN_FILE_DOWNLOAD_PATH + filename + "";
                                string path = Utility.getFileToSavePath("GSTN", fileType, "", DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture)) + filename;
                                if (File.Exists(path))
                                {
                                    File.Delete(path);
                                }
                                System.IO.File.Move(source, path);

                                string[] files = Directory.GetFiles(directoryName);
                                string JsonFromFile = System.IO.File.ReadAllText(files[0]);
                                Dictionary<string, string> JsonFromFilevalues = JsonConvert.DeserializeObject<Dictionary<string, string>>(JsonFromFile);
                                byte[] ab = decrypt_sek(Convert.FromBase64String(HttpContext.Current.Session["appkey"].ToString().Trim()), HttpContext.Current.Session["sek"].ToString().Trim());
                                byte[] cd = decrypt_sek(ab, values.rek);
                                byte[] ef = decrypt_sek(cd, JsonFromFilevalues["data"]);
                                string json1 = Encoding.UTF8.GetString(ef);
                                returnval = json1;
                            }
                            else
                            {
                                updateDownloadedValidFileStatus(getRecordInsereted.ToString(), "N", UnprocessedFileReasons.INVALID_FILE_HASH);
                            }

                        }

                    }

                }
            }
            //}
            //else
            //{
            //    // Json schema checked fail
            //}
        }
        else
        {
            // invalid json
        }
        return returnval;
    }

    protected string DownloadFile_URL(string url)
    {
        string filename = "", filenamewithoutext = "";

        try
        {

            Uri uri = new Uri(url);
            filename = System.IO.Path.GetFileName(uri.LocalPath);
            filenamewithoutext = System.IO.Path.GetFileNameWithoutExtension(uri.LocalPath);
            filenamewithoutext = System.IO.Path.GetFileNameWithoutExtension(filenamewithoutext);
            HttpContext.Current.Session.Add("filenamewithoutext", filenamewithoutext);
            WebClient webClient = new WebClient();
            webClient.DownloadFile(uri, @"E:\GSTN_dwnload_files\" + filenamewithoutext + ".tar.gz");

            //webClient.DownloadFile(uri, Constants.GSTN_FILE_DOWNLOAD_PATH + filename);

            System.Threading.Thread.Sleep(5000);
        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
            return null;
        }
        return filename;
    }
    public string ExtractTGZ(String gzArchiveName)
    {

        Stream inStream = File.OpenRead(Constants.GSTN_FILE_DOWNLOAD_PATH + gzArchiveName);
        Stream gzipStream = new GZipInputStream(inStream);
        TarArchive tarArchive = TarArchive.CreateInputTarArchive(gzipStream);

        string[] splittedPath = gzArchiveName.Split('.');
        string direc = Constants.GSTN_FILE_DOWNLOAD_PATH + splittedPath[0];
        bool exists = System.IO.Directory.Exists(direc);

        if (!exists)
            System.IO.Directory.CreateDirectory(direc);

        tarArchive.ExtractContents(direc);
        tarArchive.Close();

        gzipStream.Close();
        inStream.Close();

        return direc;
    }

    
    public void updateDownloadedValidFileStatus(string frcid, string validfile, string reason)
    {
        string tablename = string.Empty;
        PostgresGetData getdata = new PostgresGetData();
        if (HttpContext.Current.Session["filetype"].ToString() == "CIN")
        {
            tablename = " file_record_count_cin ";
        }
        else
        {
            tablename = " file_record_count ";
        }
        StringBuilder insertUp1 = new StringBuilder(@"update "+tablename+@" set validfile=@validfile, reason=@reason where frcid=@frcid ;");
        NpgsqlCommand insertUp1cmd = new NpgsqlCommand(insertUp1.ToString());
        insertUp1cmd.Parameters.AddWithValue("@validfile", validfile);
        if (string.IsNullOrEmpty(reason))
        {
            insertUp1cmd.Parameters.AddWithValue("@reason", System.DBNull.Value);
        }
        else
        {
            insertUp1cmd.Parameters.AddWithValue("@reason", reason);
        }
        insertUp1cmd.Parameters.AddWithValue("@frcid", frcid);
        int RecordInsereted1 = getdata.UpdateScalarData(insertUp1cmd, "nfs");
    }
}