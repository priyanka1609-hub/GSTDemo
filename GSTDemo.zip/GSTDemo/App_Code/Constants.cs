﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Constants
/// </summary>
public static class Constants
{
    public static string STATE_CODE = "07";
    public static string PADDED_UDCH_CODE = "0750";
    public static string UDCH_CODE = "750";
    public static string TREASURY_ACCOUNT = "000000000000";
    public static string MOE_FORMAT_NR = "camt.027.001.04";
    public static string MOE_SERVICE_NR = "ClaimNonReceiptV04";
    public static int FINANCIAL_YEAR_START_MONTH = 4;
    public static string MOE_FORMAT_UA = "camt.026.001.04";
    public static string MOE_SERVICE_UA = "UnableToApplyV04";
    public static string SAVED_FILE_PATH = @"E:\Files\";
    public static string RBI_EXTRACTED_PATH = @"E:\RBI_SFTP_Download_Files\Extracted\";
    public static string RBI_EXTRACTED_PATH_AS = @"E:\RBI_Downloaded_AS\Extracted\";
    public static string Keys_Path = @"E:\key\";
    public static string RBI_FILE_CN_DOWNLOAD_PATH = @"E:\RBI_SFTP_Download_Files\";
    public static string RBI_FILE_AS_DOWNLOAD_PATH = @"E:\RBI_Downloaded_AS\";
    public static string RBI_SFTP_HOST_NAME = "125.18.33.233";
    public static string RBI_SFTP_USER_NAME = "GODL";
    public static string RBI_SFTP_PWD = "GodlGsntRbi@123#";
    public static string RBI_SFTP_KEY = "ecdsa-sha2-nistp256 256 f6:c7:89:18:eb:b6:3a:e2:c7:37:59:80:54:73:cb:25";
public static string RBI_PULL_AS_FROM = @"/ACST/";
    public static string RBI_PULL_AS_TO = @"E:\RBI_Downloaded_AS\\";
    public static string RBI_AS_DONE_PATH = @"/ACST/Done/";
    public static string GSTN_FILE_DOWNLOAD_PATH = @"E:\GSTN_dwnload_files\";
  
  
    
}