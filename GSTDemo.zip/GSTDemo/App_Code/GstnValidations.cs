﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using Npgsql;
using System.Data;
using GstDelhi.PostgresData;
using System.Security.Cryptography;
using System.IO;
using System.Security.Cryptography.Pkcs;
using System.Security.Cryptography.X509Certificates;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using Org.BouncyCastle.Bcpg.OpenPgp;
using ICSharpCode.SharpZipLib.Zip;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Crypto.Parameters;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.Xml.Schema;
using System.Xml.XPath;
using Newtonsoft.Json.Schema;

/// <summary>
/// Summary description for GstnValidations
/// </summary>
public static class GstnValidations
{
    public static bool IsValidJson(string strInput)
    {
        strInput = strInput.Trim();
        if ((strInput.StartsWith("{") && strInput.EndsWith("}")) || //For object
            (strInput.StartsWith("[") && strInput.EndsWith("]"))) //For array
        {
            try
            {
                var obj = JToken.Parse(strInput);
                return true;
            }
            catch (JsonReaderException jex)
            {

                ExceptionLogging.logException(jex);
                return false;
            }
            catch (Exception ex)
            {
                ExceptionLogging.logException(ex);
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    public static bool checkHmac(byte[] deCipher, string data, string resphmac)
    {
        string EK_result = Convert.ToBase64String(deCipher);
        Console.WriteLine(EK_result);
        var EK = Convert.FromBase64String(EK_result);

        string gen_hmac = "";
        string message = data;

        using (var HMACSHA256 = new HMACSHA256(EK))
        {
            byte[] data1 = Encoding.UTF8.GetBytes(message);
            byte[] hashmessage = HMACSHA256.ComputeHash(data1);
            gen_hmac = Convert.ToBase64String(hashmessage);
        }
        if (gen_hmac.Equals(resphmac))
        {
            return true;
        }
        return false;
    }

    public static bool checkJsonSchema(string response, string schemapath)
    {
        try
        {
            string schemastring = File.ReadAllText(schemapath);
            JSchema schema = JSchema.Parse(schemastring);
            JObject responseJson = JObject.Parse(response);

            bool res = responseJson.IsValid(schema);
            return res;
        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
        }
        return false;
    }


    public static bool checkFileChecksum(string filepath, string recvdhash)
    {
        string generatedHash = String.Empty;
        using (FileStream stream = File.OpenRead(filepath))
        {
            var sha = new SHA256Managed();
            byte[] checksum = sha.ComputeHash(stream);
            generatedHash = BitConverter.ToString(checksum).Replace("-", String.Empty).ToLower();
            //generatedHash = string.Concat(checksum.Select(x => x.ToString("X1")));

            if (generatedHash.Equals(recvdhash))
            {
                return true;
            }
        }

        return false;
    }

    public static bool checkDigitalSignature(byte[] textFileBytes, byte[] sigFileBytes)
    {
        try
        {
            X509Certificate2 certificate = new X509Certificate2(sigFileBytes);
            ContentInfo contentInfo;
            SignedCms signedCMS;
            contentInfo = new ContentInfo(textFileBytes);
            signedCMS = new SignedCms(contentInfo, false);
            signedCMS.Decode(sigFileBytes);

            signedCMS.CheckSignature(true);
            //if (certificate.SerialNumber.ToString().Equals(getserialNumber(sigFileBytes)))
            //{
            //    return true;
            //}


            return true;
        }
        catch (Exception ex)
        {

            return false;
            throw ex;
        }

    }

    public static bool isRecordExits(string tablename, string fieldname, string fieldval)
    {
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder("select "+fieldname+" from "+tablename+ " where "+fieldname+" =@fieldval");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@fieldval", fieldval);
        DataTable dtrec = data.GetDataTable(SelectCmd, "nfs");

        if (dtrec.Rows.Count > 0)
        {
            return true;
        }

        return false;

    }


    public static bool VerifySignature(String originalTextToSign, String signedDataInText)
    {
        bool success = false;
        var encoder = new UTF8Encoding();

        ContentInfo contentInfo2 = new ContentInfo(Encoding.UTF8.GetBytes(originalTextToSign));

        SignedCms signedCms2 = new SignedCms(contentInfo2, true);

        //take signed string representation and convert to byte array to perform decode
        byte[] encodedMessageFromSender = Convert.FromBase64String(signedDataInText);

        signedCms2.Decode(encodedMessageFromSender);

        //Check the original message against the encrypted hash
        //If something is wrong this line will cause an exception
        try
        {

            signedCms2.CheckSignature(true);
            X509Certificate2 certificate = new X509Certificate2();
            //certificate.Import(HttpContext.Current.Server.MapPath(@"~/key/GSTN_public.cer"));
            certificate.Import(System.IO.Path.GetFullPath(Constants.Keys_Path + "GSTN_public.cer"));

            //if (certificate.SerialNumber.ToString().Equals(getserialNumber(encodedMessageFromSender)))
            //{
            //    return true;
            //}

            success = true;

        }
        catch (Exception ex)
        {
            success = false;
        }

        return success;
    }
}