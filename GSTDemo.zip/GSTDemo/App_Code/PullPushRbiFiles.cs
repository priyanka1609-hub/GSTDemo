﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WinSCP;

/// <summary>
/// Summary description for PullPushRbiFiles
/// </summary>
public class PullPushRbiFiles
{
    string HostName, UserName, Password, SshHostKeyFingerprint;

    public PullPushRbiFiles()
    {
        HostName = "";
        UserName = "";
        Password = "";
        SshHostKeyFingerprint = "";
    }

    public int pushFiles(string from, string to)
    {
        try
        {
            // Setup session options
            SessionOptions sessionOptions = new SessionOptions
            {
                Protocol = Protocol.Sftp,
                HostName = Constants.RBI_SFTP_HOST_NAME,
                UserName = Constants.RBI_SFTP_USER_NAME,
                Password = Constants.RBI_SFTP_PWD,
                SshHostKeyFingerprint = Constants.RBI_SFTP_KEY
            };

            using (Session session = new Session())
            {
                // Connect
                session.Open(sessionOptions);

                // Upload files
                TransferOptions transferOptions = new TransferOptions();
                transferOptions.TransferMode = TransferMode.Binary;

                TransferOperationResult transferResult;
                transferResult = session.PutFiles(from, to+"/", false, transferOptions);

                // Throw on any error
                transferResult.Check();

                // Print results
                foreach (TransferEventArgs transfer in transferResult.Transfers)
                {
                    Console.WriteLine("Upload of {0} succeeded", transfer.FileName);
                }
            }

            return 1;
        }
        catch (Exception e)
        {
            ExceptionLogging.logException(e);
            //Console.WriteLine("Error: {0}", e);
            return 0;
        }
    }
}