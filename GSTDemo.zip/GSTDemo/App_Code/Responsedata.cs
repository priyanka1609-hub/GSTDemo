﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Responsedata
/// </summary>
public class Responsedata
{
	public Responsedata()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public string data { get; set; }
    public string sign { get; set; }
}