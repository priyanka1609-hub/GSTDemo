﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Pkcs;
using System.IO;
using System.Text;
using Npgsql;
using GstDelhi.PostgresData;

/// <summary>
/// Summary description for Utility
/// </summary>
public static class Utility
{
    public static DateTime converttodate_from_DDMMYYYY(string pickDate)
    {
        int yr = 0;
        int month = 0;
        int day = 0;
        DateTime dt;

        if (pickDate.Contains("/"))
        {
            yr = Convert.ToInt32(pickDate.Substring(6, 4));
            month = Convert.ToInt32(pickDate.Substring(3, 2));
            day = Convert.ToInt32(pickDate.Substring(0, 2));

        }
        else if (pickDate.Contains("-"))
        {
            yr = Convert.ToInt32(pickDate.Substring(6, 4));
            month = Convert.ToInt32(pickDate.Substring(3, 2));
            day = Convert.ToInt32(pickDate.Substring(0, 2));
        }
        else
        {
            yr = Convert.ToInt32(pickDate.Substring(0, 4));
            month = Convert.ToInt32(pickDate.Substring(4, 2));
            day = Convert.ToInt32(pickDate.Substring(6, 2));

        }
        dt = new DateTime(yr, month, day);
        return dt;
    }


    public static string getFileToSavePath(string fileType, string subfiletype, string subfiletype2, string date)
    {
        try
        {
            string path = string.Empty;
            string[] splitdate = date.Split('/');
            if (String.IsNullOrEmpty(subfiletype))
            {
                path = Constants.SAVED_FILE_PATH + fileType + "\\" + splitdate[2] + "\\" + splitdate[1] + "\\" + splitdate[0] + "\\";
            }
            else if (String.IsNullOrEmpty(subfiletype2))
            {
                path = Constants.SAVED_FILE_PATH + fileType + "\\" + splitdate[2] + "\\" + splitdate[1] + "\\" + splitdate[0] + "\\" + subfiletype + "\\";
            }
            else
            {
                path = Constants.SAVED_FILE_PATH + fileType + "\\" + splitdate[2] + "\\" + splitdate[1] + "\\" + splitdate[0] + "\\" + subfiletype + "\\" + subfiletype2 + "\\";
            }
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
            return path;
        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
            return null;
        }
    }

    public static string getFinancialYear()
    {
        string finyear = string.Empty;

        if (DateTime.Now.Month < Constants.FINANCIAL_YEAR_START_MONTH)
        {
            finyear = (DateTime.Now.Year - 1) + "-" + DateTime.Now.Year;
        }
        else
        {
            finyear = DateTime.Now.Year + "-" + (DateTime.Now.Year + 1);
        }

        return finyear;
    }


    public static DateTime converttodate_from_YYYYMMDD_T_HHMMSS(string pickDate)
    {
        string[] sepratedatetime = pickDate.Split('T');
        int yr = 0;
        int month = 0;
        int day = 0;
        int hh = 0;
        int mm = 0;
        int ss = 0;
        DateTime dt;

        yr = Convert.ToInt32(sepratedatetime[0].Substring(0, 4));
        month = Convert.ToInt32(sepratedatetime[0].Substring(5, 2));
        day = Convert.ToInt32(sepratedatetime[0].Substring(8, 2));

        hh = Convert.ToInt32(sepratedatetime[1].Substring(0, 2));
        mm = Convert.ToInt32(sepratedatetime[1].Substring(3, 2));
        ss = Convert.ToInt32(sepratedatetime[1].Substring(6, 2));

        dt = new DateTime(yr, month, day, hh, mm, ss);
        return dt;
    }

    public static DateTime? converttodatetime_from_DDMMYY_HHMMSS(string pickDate)
    {
        if (!string.IsNullOrEmpty(pickDate))
        {

            int yr = 0;
            int month = 0;
            int day = 0;
            int hh = 0;
            int mm = 0;
            int ss = 0;
            DateTime dt;

            yr = Convert.ToInt32(pickDate.Substring(6, 4));
            month = Convert.ToInt32(pickDate.Substring(3, 2));
            day = Convert.ToInt32(pickDate.Substring(0, 2));

            hh = Convert.ToInt32(pickDate.Substring(10, 2));
            mm = Convert.ToInt32(pickDate.Substring(13, 2));
            ss = Convert.ToInt32(pickDate.Substring(16, 2));

            dt = new DateTime(yr, month, day, hh, mm, ss);
            return dt;
        }
        else
        {
            return null;
        }
    }

    public static string pgsqlFromDateFormat(string frdate)
    {
        string FromDate = "";
        if (!string.IsNullOrEmpty(frdate))
        {
            char charattextdate = Convert.ToChar((frdate).Substring(2, 1));
            var arrydateofbirth = (frdate).Split(charattextdate);
            FromDate = arrydateofbirth[2] + "-" + arrydateofbirth[1] + "-" + arrydateofbirth[0];
            FromDate += " 00:00:00";
        }
        else
        {
            frdate = System.DateTime.Now.ToString("dd/MM/yyyy");
            char charattextdate = Convert.ToChar((frdate).Substring(2, 1));
            var arrydateofbirth = (frdate).Split(charattextdate);
            FromDate = arrydateofbirth[2] + "-" + arrydateofbirth[1] + "-" + arrydateofbirth[0];
            FromDate += " 00:00:00";
        }

        return FromDate;
    }

    public static string pgsqlToDateFormat(string todate)
    {
        string ToDate = "";
        if (!string.IsNullOrEmpty(todate))
        {
            char charattextdate = Convert.ToChar((todate).Substring(2, 1));
            var arrydateofbirth = (todate).Split(charattextdate);
            ToDate = arrydateofbirth[2] + "-" + arrydateofbirth[1] + "-" + arrydateofbirth[0];
            ToDate += " 23:59:59";
        }
        else
        {
            todate = System.DateTime.Now.ToString("dd/MM/yyyy");
            char charattextdate = Convert.ToChar((todate).Substring(2, 1));
            var arrydateofbirth = (todate).Split(charattextdate);
            ToDate = arrydateofbirth[2] + "-" + arrydateofbirth[1] + "-" + arrydateofbirth[0];
            ToDate += " 23:59:59";
        }

        return ToDate;
    }


    public static int updatestarttime(string orgtype, string filetype)
    {
        PostgresGetData data = new PostgresGetData();
        List<NpgsqlCommand> insertschd = new List<NpgsqlCommand>();
        StringBuilder insertschdqry = new StringBuilder(@"insert into scheduler_stats (orgtype,filetype,startdatetime) values (@orgtype,@filetype,now()); select lastval();");
        NpgsqlCommand insertschdcmd = new NpgsqlCommand(insertschdqry.ToString());
        insertschdcmd.Parameters.AddWithValue("@orgtype", orgtype);
        insertschdcmd.Parameters.AddWithValue("@filetype", filetype);
        int getrecordsinserted = data.UpdateScalarData(insertschdcmd, "nfs");
        return getrecordsinserted;
    }
    public static int updateEndtime(int id)
    {
        PostgresGetData data = new PostgresGetData();
        StringBuilder updateschdqry = new StringBuilder("update  scheduler_stats set enddatetime=now() where id=@maxid");
        NpgsqlCommand updateschdcmd = new NpgsqlCommand(updateschdqry.ToString());
        updateschdcmd.Parameters.AddWithValue("@maxid", id);
        int updateenddate = data.UpdateScalarData(updateschdcmd, "nfs");
        return updateenddate;
    }
}