﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for GstnResponse
/// </summary>
public class GstnResponse
{
    public string status_cd { get; set; }
    public string data { get; set; }
    public string rek { get; set; }
    public string hmac { get; set; }
    public Error error { get; set; }


    public class Error
    {
        public string message { get; set; }
        public string error_cd { get; set; }
    }
}