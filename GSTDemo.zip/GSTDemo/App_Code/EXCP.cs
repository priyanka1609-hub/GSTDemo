﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for EXCP
/// </summary>
public class EXCP
{
	public EXCP()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public string rep_tim { get; set; }
    public string message { get; set; }
    public string txnid { get; set; }
    public string error_cd { get; set; }
    public string cpin { get; set; }
    public string bank_cd { get; set; }
    public string rep_dt { get; set; }
}