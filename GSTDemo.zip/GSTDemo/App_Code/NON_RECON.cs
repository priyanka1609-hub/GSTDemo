﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for NON_RECON
/// </summary>
public class NON_RECON
{
	public NON_RECON()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    
    
    public string e_scroll_num { get; set; }
    public string cin { get; set; }
    public string cpin { get; set; }
    public string gstin { get; set; }
    public string sgst_total { get; set; }
    public string bank_ref_num { get; set; }
}