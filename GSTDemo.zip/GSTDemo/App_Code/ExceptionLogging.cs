﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Npgsql;
using GstDelhi.PostgresData;

/// <summary>
/// Summary description for ExceptionLogging
/// </summary>
public static class ExceptionLogging
{
    private static String exepurl;

    public static void logException(Exception exdb)
    {
        exepurl = HttpContext.Current.Request.Url.ToString(); 
        NpgsqlCommand insertExcp = new NpgsqlCommand("exceptionloggingtodatabase");
        insertExcp.CommandType = System.Data.CommandType.StoredProcedure;
        insertExcp.Parameters.AddWithValue("@ExceptionMsg", exdb.Message.ToString());
        insertExcp.Parameters.AddWithValue("@ExceptionType", exdb.GetType().Name.ToString());
        insertExcp.Parameters.AddWithValue("@ExceptionURL", exepurl);
        insertExcp.Parameters.AddWithValue("@ExceptionSource", exdb.StackTrace.ToString());

        PostgresGetData data = new PostgresGetData();
        data.UpdateData(insertExcp, "nfs");

    }  
}