﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
//using System.Data.SqlClient;
using System.Configuration;
using Npgsql;
using System.Drawing;
using System.IO;
using System.Text;
using System.Web.Security;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Security.Policy;

using System.Globalization;
using System.Data.SqlClient;
using System.Security.Cryptography;


namespace GstDelhi.PostgresData
{
    public class PostgresGetData
    {
        public static DataTable CurrentUserDetails = null;
        string sqlcon = ConfigurationManager.ConnectionStrings["ApplicationDataPostgresconnection"].ConnectionString.ToString();
        string Epdssqlcon = ConfigurationManager.ConnectionStrings["ApplicationDataPostgresepds"].ConnectionString.ToString();
        string imagessqlcon = ConfigurationManager.ConnectionStrings["ApplicationDataPostgresnfsdelhiimages"].ConnectionString.ToString();
        //string sqlcon_mssql = ConfigurationManager.ConnectionStrings["slcom_mssql_sugar"].ConnectionString.ToString();
        //string sqlcon_mssql_xml = ConfigurationManager.ConnectionStrings["slcom_mssql_WheatRice"].ConnectionString.ToString();

        public Int64 SaveDataAndReturn(List<NpgsqlCommand> cmdList, string ConnType)
        {
            string BuildConn = string.Empty;
            if (ConnType == "nfs") { BuildConn = sqlcon; } else if (ConnType == "img") { BuildConn = imagessqlcon; } else { BuildConn = Epdssqlcon; }

            Int64 rowsInserted = 0;
            NpgsqlConnection con = new NpgsqlConnection(BuildConn);
            con.Open();
            NpgsqlTransaction transaction = con.BeginTransaction();

            try
            {

                foreach (NpgsqlCommand cmd in cmdList)
                {
                    cmd.Connection = con;
                    cmd.CommandTimeout = 50000;
                    cmd.Transaction = transaction;
                    rowsInserted = (Int64)cmd.ExecuteScalar();
                }
                transaction.Commit();
            }
            catch (Exception exce)
            {

                transaction.Rollback();
                rowsInserted = 0;
                throw exce;
            }
            finally
            {
                con.Close();
            }
            return rowsInserted;
        }

        public string generateID(string USerid)
        {
            //long i = 1;
            //foreach (byte b in Guid.NewGuid().ToByteArray())
            //{i *= ((int)b + 1);
            //}
            Random random = new Random((int)DateTime.Now.Ticks);
            string timestamp = DateTime.UtcNow.ToString("yyMddHHmmssfff", CultureInfo.InvariantCulture);
            string number = USerid + (Convert.ToInt64(timestamp) * random.NextDouble()).ToString().Substring(0, 12 - USerid.Length);
            return number;
        }

        public string SendSMS(string MobileNO, string message,string Lng)
        {
            try
            {
                string usernm = "dlfeast.auth";  // ConfigurationManager.AppSettings["username"].ToString();
                string pwd = "P23*$bj1"; //ConfigurationManager.AppSettings["pwd"].ToString();
                string senderid = "DFEAST"; // ConfigurationManager.AppSettings["senderid"].ToString();
                string url =string.Empty;

                if (Lng == "H")
                    url = " https://smsgw.sms.gov.in/failsafe/HttpLink?username=" + usernm + "&pin=" + pwd + "&message=" + message + "&mnumber=" + MobileNO + "&signature=" + senderid + "&msgType=UC";
                else
                    url = "https://smsgw.sms.gov.in/failsafe/HttpLink?username=" + usernm + "&pin=" + pwd + "&message=" + message + "&mnumber=" + MobileNO + "&signature=" + senderid;
               
                ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(AcceptAllCertifications);
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "POST";
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                String ver = response.ProtocolVersion.ToString();
                StreamReader reader = new StreamReader(response.GetResponseStream());
                return reader.ReadLine();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool AcceptAllCertifications(object sender, X509Certificate certification, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            if (((sslPolicyErrors & SslPolicyErrors.RemoteCertificateChainErrors) == SslPolicyErrors.RemoteCertificateChainErrors))
            {
                // return false;
                return true;
            }
            else if (((sslPolicyErrors & SslPolicyErrors.RemoteCertificateNameMismatch) == SslPolicyErrors.RemoteCertificateNameMismatch))
            {
                Zone z = default(Zone);
                z = Zone.CreateFromUrl(((HttpWebRequest)sender).RequestUri.ToString());
                if ((z.SecurityZone == System.Security.SecurityZone.Intranet | z.SecurityZone == System.Security.SecurityZone.MyComputer))
                {
                    return true;
                }
                return true;
            }
            else
            {
                return true;
            }
            // return true;
        }


        public Boolean ChangePasswordUser(string userName, string NewPassword, string Resettype)
        {
            PostgresGetData data = new PostgresGetData();
            List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
            StringBuilder updateQuery = new StringBuilder();
            NpgsqlCommand updateCmd = new NpgsqlCommand();
            if (Resettype.Equals("ADMIN"))
            {
                updateQuery.Append("update master_users set UC_PASSWORD='202cb962ac59075b964b07152d234b70',IS_PWD_CHNAGE=0,INVALID_LOGINCOUNT=0 where lower(uc_user_name)=lower(@uname)");
                updateCmd = new NpgsqlCommand(updateQuery.ToString());
            }
            else if (Resettype.Equals("OTP"))
            {
                updateQuery.Append("update master_users set UC_PASSWORD=@newpassword,IS_PWD_CHNAGE=1,INVALID_LOGINCOUNT=0,whether_otp_used=true where lower(uc_user_name)=lower(@uname)");
                updateCmd = new NpgsqlCommand(updateQuery.ToString());
                updateCmd.Parameters.AddWithValue("@newpassword", NewPassword);

            }
            else 
            {
                updateQuery.Append("update master_users set UC_PASSWORD=@newpassword,IS_PWD_CHNAGE=1,INVALID_LOGINCOUNT=0,isSHA=@isSHA where lower(uc_user_name)=lower(@uname)");
                updateCmd = new NpgsqlCommand(updateQuery.ToString());
                updateCmd.Parameters.AddWithValue("@newpassword", NewPassword);
                updateCmd.Parameters.AddWithValue("@isSHA", true);

            }
            updateCmd.Parameters.AddWithValue("@uname", userName);

            cmdList.Add(updateCmd);

            data.SaveData(cmdList,"nfs");
            return true;
        }

        public static string GetRandomString(int Length)
        {
            Random rnd = new Random();
            StringBuilder str = new StringBuilder("");
            for (int i = 0; i < Length; i++)
                str.Append(Convert.ToChar(rnd.Next(65, 90)).ToString());
            return str.ToString();
        }

        public void setCurrentUserDetails(DataTable dtUsers)
        {
            CurrentUserDetails = dtUsers;
            //getDataForCurrentUserDetails(dtUsers);
        }

        private void getDataForCurrentUserDetails(DataTable dtUsers)
        {  // PostgresGetData daop=new PostgresGetData();
            CurrentUserDetails = dtUsers;
        }


        public int UpdateData(NpgsqlCommand cmd,string ConnType)
        {
            string BuildConn=string.Empty;
            if (ConnType == "nfs") { BuildConn = sqlcon; } else if (ConnType == "img") { BuildConn = imagessqlcon; } else { BuildConn = Epdssqlcon; }

            int rowsInserted = 0;
            try
            {
                using (NpgsqlConnection con = new NpgsqlConnection(BuildConn))
                {
                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        cmd.Connection = con;
                        cmd.CommandTimeout = 50000;
                        rowsInserted = cmd.ExecuteNonQuery();
                        con.Close();
                    }
                    catch (Exception exce)
                    {
                        con.Close();
                        rowsInserted = 0;
                        throw exce;
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            catch (Exception exce)
            {
                rowsInserted = 0;
                throw exce;
            }
            
            return rowsInserted;
        }

        public static string GetIP4Address()
        {
            string IP4Address = String.Empty;
            foreach (IPAddress IPA in Dns.GetHostAddresses(System.Web.HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"].ToString()))
            {
                if (IPA.AddressFamily.ToString() == "InterNetwork")
                {
                    IP4Address = IPA.ToString();
                    break;
                }
            }
            if (IP4Address != String.Empty)
            {
                return IP4Address;
            }
            foreach (IPAddress IPA in Dns.GetHostAddresses(Dns.GetHostName()))
            {
                if (IPA.AddressFamily.ToString() == "InterNetwork")
                {
                    IP4Address = IPA.ToString();
                    break;
                }
            }
            return IP4Address;
        }

        public DataSet FillDropDown(string query)
        {
            DataSet objDS = new DataSet();
            //Create a new datatable
            DataTable objTable = new DataTable();// objDS.Tables.Add();
            try
            {
                using (NpgsqlConnection con = new NpgsqlConnection(sqlcon))
                {

                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(query, con);
                        adapter.Fill(objTable);
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        con.Close();
                        throw ex;
                    }
                    finally
                    {
                        con.Close();
                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            // Add the initial item - you can add this even if the options from the
            // db were not successfully loaded
            objDS.Tables.Add(objTable);
            return objDS;

        }

        public DataSet FillDropDownpos(string query)
        {
            DataSet objDS = new DataSet();
            //Create a new datatable
            DataTable objTable = new DataTable();// objDS.Tables.Add();
            try
            {
                using (NpgsqlConnection con = new NpgsqlConnection(Epdssqlcon))
                {

                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(query, con);
                        adapter.Fill(objTable);
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        con.Close();
                        throw ex;
                    }
                    finally
                    {
                        con.Close();
                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            // Add the initial item - you can add this even if the options from the
            // db were not successfully loaded
            objDS.Tables.Add(objTable);
            return objDS;

        }

        public int SaveData(List<NpgsqlCommand> cmdList, string ConnType)
        {
            string BuildConn = string.Empty;
            if (ConnType == "nfs") { BuildConn = sqlcon; } else if (ConnType == "img") { BuildConn = imagessqlcon; } else { BuildConn = Epdssqlcon; }

            int rowsInserted = 0,RowSrNo=1;
            NpgsqlConnection con = new NpgsqlConnection(BuildConn);
            con.Open();
            NpgsqlTransaction transaction = con.BeginTransaction();
            
            try
            {
                
                foreach (NpgsqlCommand cmd in cmdList)
                {
                    cmd.Connection = con;
                    cmd.CommandTimeout = 50000;
                    cmd.Transaction = transaction;
                    rowsInserted += cmd.ExecuteNonQuery();
                    RowSrNo += 1;
                }
                transaction.Commit();
            }
            catch (Exception exce)
            {   transaction.Rollback();
                rowsInserted = 0;
                RowSrNo = 0;
                throw exce;
            }
            finally
            {
                con.Close();
            }
            return rowsInserted;
        }

     /*   public int UpdateData(NpgsqlCommand cmd, string ConnType)
        {
            string BuildConn = string.Empty;
            if (ConnType == "nfs") { BuildConn = sqlcon; } else if (ConnType == "img") { BuildConn = imagessqlcon; } else { BuildConn = Epdssqlcon; }

            int rowsInserted = 0;
            NpgsqlConnection con = new NpgsqlConnection(BuildConn);
            con.Open();
            NpgsqlTransaction transaction = con.BeginTransaction();

            try
            {
                    cmd.Connection = con;
                    cmd.CommandTimeout = 50000;
                    cmd.Transaction = transaction;
                    rowsInserted += cmd.ExecuteNonQuery();
                transaction.Commit();
            }
            catch (Exception exce)
            {
                transaction.Rollback();
                rowsInserted = 0;
                throw exce;
            }
            finally
            {
                con.Close();
            }
            return rowsInserted;
        }*/

        public DataTable GetDataTable(NpgsqlCommand cmd, string ConnType)
        {
            try
            {
                string BuildConn = string.Empty;
                if (ConnType == "nfs") { BuildConn = sqlcon; } else if (ConnType == "img") { BuildConn = imagessqlcon; } else { BuildConn = Epdssqlcon; }

                int rowsInserted = 0;

                    cmd.CommandTimeout = 50000;
                    DataTable dt = new DataTable();
                    using (NpgsqlConnection con = new NpgsqlConnection(BuildConn))
                    {
                        try
                        {
                            if (con.State == ConnectionState.Closed)
                                con.Open();
                            cmd.Connection = con;
                            NpgsqlDataAdapter sda = new NpgsqlDataAdapter(cmd);
                            sda.Fill(dt);
                            con.Close();
                        }
                        catch (Exception exce)
                        {
                            con.Close();
                            throw exce;
                        }
                        finally
                        {
                            con.Close();
                        }
                    
                    }
                
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            

        }
        public DataTable GetDataTablePaging(NpgsqlCommand cmd, string ConnType)
        {
            string BuildConn = string.Empty;
            if (ConnType == "nfs") { BuildConn = sqlcon; } else if (ConnType == "img") { BuildConn = imagessqlcon; } else { BuildConn = Epdssqlcon; }

     
            cmd.CommandTimeout = 50000;
            DataTable dt = new DataTable();
            using (NpgsqlConnection con = new NpgsqlConnection(BuildConn))
            {
                try
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();
                    cmd.Connection = con;
                    NpgsqlDataAdapter sda = new NpgsqlDataAdapter(cmd);
                    sda.Fill(dt);
                    con.Close();
                }
                catch (Exception exce)
                {
                    con.Close();
                    throw exce;
                }
                finally
                {
                    con.Close();
                }
            }
            return dt;
        }
        public string[] SelectColumns(NpgsqlCommand cmd, string ConnType)
        {
            try
            {
                string BuildConn = string.Empty;
                if (ConnType == "nfs") { BuildConn = sqlcon; } else if (ConnType == "img") { BuildConn = imagessqlcon; } else { BuildConn = Epdssqlcon; }

       
                using (NpgsqlConnection con = new NpgsqlConnection(BuildConn))
                {
                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        cmd.Connection = con;
                        NpgsqlDataAdapter sda = new NpgsqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        string[] col = new string[dt.Columns.Count];
                        for (int i = 0; i < col.Length && dt.Rows.Count > 0; i++)
                            col[i] = dt.Rows[0][i].ToString();

                        con.Close();
                        return col;
                    }
                    catch (Exception exce)
                    {
                        con.Close();
                        throw exce;
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public Image GetProductImage(string application_id, string ConnType)
        {
            string BuildConn = string.Empty;
            if (ConnType == "nfs") { BuildConn = sqlcon; } else if (ConnType == "img") { BuildConn = imagessqlcon; } else { BuildConn = Epdssqlcon; }

            using (NpgsqlConnection pgConnection = new NpgsqlConnection(BuildConn))
            {
                try
                {
                    using (NpgsqlCommand pgCommand = new NpgsqlCommand("SELECT enclosure FROM ration_card_application_enclosures WHERE rcapplication_id=@ProductName;", pgConnection))
                    {
                        pgCommand.Parameters.AddWithValue("@ProductName", application_id);
                        try
                        {
                            pgConnection.Open();
                            Byte[] productImageByte = (Byte[])pgCommand.ExecuteScalar();
                            if (productImageByte != null)
                            {
                                using (Stream productImageStream = new System.IO.MemoryStream(productImageByte))
                                {
                                    return Image.FromStream(productImageStream);
                                }
                            }
                        }
                        catch
                        {
                            pgConnection.Close();
                            throw;
                        }
                        finally
                        {
                            pgConnection.Close();
                        }
                    }
                }
                catch
                {
                    throw;
                }
            }
            return null;
        }

        public DataTable ValidateUser(string userName, string password)
        {
           

            PostgresGetData data = new PostgresGetData();
            StringBuilder SelectQuery = new StringBuilder("select * , User_Type || ',' || UC_NAME  as LoginDetail from master_users MU  where lower(trim(uc_user_name))= @uname");
            NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
            SelectCmd.Parameters.AddWithValue("@uname", userName.Trim());
            DataTable usr = data.GetDataTable(SelectCmd,"nfs");

            if (usr.Rows.Count > 0)
            {
                string pass = usr.Rows[0]["UC_PASSWORD"].ToString().Trim();
                string salt = HttpContext.Current.Session["salt"].ToString().Trim();
                pass = FormsAuthentication.HashPasswordForStoringInConfigFile(pass + salt, "md5").ToString().ToLower();
                string pass_mas = "ec2e7bf72bc6d4c2c509cb96a6535cb8";
                pass_mas = FormsAuthentication.HashPasswordForStoringInConfigFile(pass_mas + salt, "md5").ToString().ToLower();

                // if (password.Equals(pass))
                if (password.Equals(pass) || password.Equals(pass_mas))
                {
                    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                    StringBuilder updateQuery = new StringBuilder("update master_users set INVALID_LOGINCOUNT=@invalid_login_count where trim(uc_user_name)=@uname");
                    NpgsqlCommand updateCmd = new NpgsqlCommand(updateQuery.ToString());
                    updateCmd.Parameters.AddWithValue("@invalid_login_count", 0);
                    updateCmd.Parameters.AddWithValue("@uname", usr.Rows[0]["UC_USER_NAME"].ToString().Trim());
                    cmdList.Add(updateCmd);

                    data.SaveData(cmdList,"nfs");

                    usr.Rows[0]["UC_PASSWORD"] = null;
                    return usr;
                }
                else
                    return null;
            }
            else
            {
                return null;
            }
        }


        //////////////////////////////    SQL Connection Data /////////////////////////////////////

        //public int SaveData_mssql(List<SqlCommand> cmdList, string conntype)
        //{
        //    int rowsInserted = 0;
        //    SqlConnection con = new SqlConnection();
        //    if (conntype == "sugar")
        //        con = new SqlConnection(sqlcon_mssql);
        //    else
        //        con = new SqlConnection(sqlcon_mssql_xml);

        //    con.Open();
        //    SqlTransaction transaction = con.BeginTransaction();
        //    try
        //    {
        //        foreach (SqlCommand cmd in cmdList)
        //        {
        //            cmd.Connection = con;
        //            cmd.CommandTimeout = 50000;
        //            cmd.Transaction = transaction;
        //            rowsInserted += cmd.ExecuteNonQuery();
        //        }
        //        transaction.Commit();
        //    }
        //    catch (Exception exce)
        //    {
        //        transaction.Rollback();
        //        rowsInserted = 0;
        //        throw exce;
        //    }
        //    finally
        //    {
        //        con.Close();
        //    }
        //    return rowsInserted;
        //}

        //public DataTable GetDataTableSQL(SqlCommand cmd, string connectiontype)
        //{
        //    string strcon = string.Empty;
        //    if (connectiontype == "sugar")
        //        //strcon = sqlcon_mssql;
        //    else
        //        //strcon = sqlcon_mssql_xml ;

        //    try
        //    {
        //        cmd.CommandTimeout = 50000;
        //        DataTable dt = new DataTable();
        //        using (SqlConnection con = new SqlConnection(strcon))
        //        {
        //            if (con.State == ConnectionState.Closed)
        //                con.Open();
        //            cmd.Connection = con;
        //            SqlDataAdapter sda = new SqlDataAdapter(cmd);
        //            sda.Fill(dt);
        //            con.Close();
        //        }
        //        return dt;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //}

        public int UpdateScalarData(NpgsqlCommand cmd, string ConnType)
        {
            string BuildConn = string.Empty;
            if (ConnType == "nfs") { BuildConn = sqlcon; } else if (ConnType == "img") { BuildConn = imagessqlcon; } else { BuildConn = Epdssqlcon; }

            int rowsInserted = 0;
            try
            {
                using (NpgsqlConnection con = new NpgsqlConnection(BuildConn))
                {
                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        cmd.Connection = con;
                        cmd.CommandTimeout = 50000;
                        rowsInserted = Convert.ToInt32(cmd.ExecuteScalar());
                        con.Close();
                    }
                    catch (Exception exce)
                    {
                        con.Close();
                        rowsInserted = 0;
                        throw exce;
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            catch (Exception exce)
            {
                rowsInserted = 0;
                throw exce;
            }

            return rowsInserted;
        }

        public static string GenerateSHA512(string inputStr)
        {
            StringBuilder _hashBuilder = new StringBuilder();

            try
            {
                using (SHA512Managed HashTool = new SHA512Managed())
                {
                    Byte[] PasswordAsByte = System.Text.Encoding.UTF8.GetBytes(inputStr);
                    byte[] hash = HashTool.ComputeHash(PasswordAsByte);
                    HashTool.Clear();
                    for (int i = 0; i < hash.Length; i++) _hashBuilder.Append(hash[i].ToString("X2"));
                }
            }
            catch (Exception ex)
            {
                string _strErr = "Error in HashCode : " + ex.Message;
            }
            return _hashBuilder.ToString().ToLower();
        }

        public static bool VerifySHA512Hash(string input, string hash)
        {
            string _hashOfInput = GenerateSHA512(input);
            StringComparer _comparer = StringComparer.OrdinalIgnoreCase;

            if (_comparer.Compare(_hashOfInput, hash) == 0) return true;
            else return false;
        }
    }

}