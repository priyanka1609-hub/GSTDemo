﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Cpin
/// </summary>
public class Cpin
{
	public Cpin()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public string gstin { get; set; }
    public string tmpid { get; set; }
    public string cpin { get; set; }
    public string cpin_dt { get; set; }
    public string cpin_tim { get; set; }
    public string bank_cd { get; set; }
    //public string mode { get; set; }
    public string cgst_tax { get; set; }
    public string cgst_intr { get; set; }
    public string cgst_fee { get; set; }
    public string cgst_pnlty { get; set; }
    public string cgst_oth { get; set; }
    public string cgst_total { get; set; }
    public string igst_tax { get; set; }
    public string igst_intr { get; set; }
    public string igst_fee { get; set; }
    public string igst_pnlty { get; set; }
    public string igst_oth { get; set; }
    public string igst_total { get; set; }
    public string sgst_tax { get; set; }
    public string sgst_intr { get; set; }
    public string sgst_fee { get; set; }
    public string sgst_pnlty { get; set; }
    public string sgst_oth { get; set; }
    public string sgst_total { get; set; }
    public string cess_tax { get; set; }
    public string cess_intr { get; set; }
    public string cess_fee { get; set; }
    public string cess_pnlty { get; set; }
    public string cess_oth { get; set; }
    public string cess_total { get; set; }
    public string total_amt { get; set; }
}