﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using Npgsql;
using System.Data;
using GstDelhi.PostgresData;
using System.Security.Cryptography;
using System.IO;
using System.Security.Cryptography.Pkcs;
using System.Security.Cryptography.X509Certificates;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using Org.BouncyCastle.Bcpg.OpenPgp;
using ICSharpCode.SharpZipLib.Zip;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Crypto.Parameters;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.Xml.Schema;
using System.Xml.XPath;
using System.Globalization;

/// <summary>
/// Summary description for RbiValidations
/// </summary>
public static class RbiValidations
{

    public static string ExtractRbiZIP(string ZipName)
    {
        try
        {
            string foldername = Path.GetFileNameWithoutExtension(ZipName);
            //var targetDir = @"D:\RBI_SFTP_Download_Files\Extracted\" + foldername;
            var targetDir = Constants.RBI_EXTRACTED_PATH + foldername;
            FastZip fastZip = new FastZip();
            string fileFilter = null;
            // Will always overwrite if target filenames already exist
            fastZip.ExtractZip(ZipName, targetDir, fileFilter);
            return targetDir;
        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
            return null;
        }
    }
    public static string ExtractRbiZIPAS(string ZipName)
    {
        try
        {
            string foldername = Path.GetFileNameWithoutExtension(ZipName);
            //var targetDir = @"D:\RBI_Downloaded_AS\Extracted\" + foldername;
            var targetDir = Constants.RBI_EXTRACTED_PATH_AS;

            FastZip fastZip = new FastZip();
            string fileFilter = null;
            // Will always overwrite if target filenames already exist
            fastZip.ExtractZip(ZipName, targetDir, fileFilter);
            return targetDir;
        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
            return null;
        }
    }


    public static int checkXmlSigFilePresent(string filepath)
    {
        int res = 0;

        try
        {
            if (File.Exists(filepath + ".XML"))
            {
                if (File.Exists(filepath + ".SIG"))
                {
                    res = 3;
                }
                else
                {
                    // Signature file is missing
                    res = 2;
                }
            }
            else
            {
                // XML file is missing
                res = 2;
                res = 1;
            }

        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
            res = 0;
        }

        return res;
    }


    public static bool verifySignAndCertificate(byte[] signature, byte[] data, X509Certificate2 certificate)
    {


        if (signature == null)
            throw new ArgumentNullException("signature");
        if (certificate == null)
            throw new ArgumentNullException("certificate");

        if (VerifySignature(data, signature))
        {
            if (certificate.SerialNumber.ToString().Equals(getserialNumber(signature)))
            {
                return true;
            }
        }

        return false;
    }

    public static bool VerifySignature(byte[] textFileBytes, byte[] sigFileBytes)
    {

        try
        {
            ContentInfo contentInfo;
            SignedCms signedCMS;
            contentInfo = new ContentInfo(textFileBytes);
            signedCMS = new SignedCms(contentInfo, true);
            signedCMS.Decode(sigFileBytes);

            signedCMS.CheckSignature(true);
            return true;
        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
            return false;
            throw ex;
        }

    }

    public static string getserialNumber(byte[] signfile)
    {
        X509Certificate2 certFromSign = new X509Certificate2();
        string CertSerialNumber = string.Empty;
        try
        {
            certFromSign.Import(signfile);
            CertSerialNumber = certFromSign.SerialNumber.ToString();

            //End of Impport DSC From Signature
        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
            CertSerialNumber = "NA";
            //CAName = "NA";
        }
        return CertSerialNumber;
    }

    public static bool XSDValidation(string xmlfilepath, string xsdfilepath)
    {
        try
        {
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.Schemas.Add(null, xsdfilepath);
            settings.ValidationType = ValidationType.Schema;

            XmlReader reader = XmlReader.Create(xmlfilepath, settings);
            XmlDocument document = new XmlDocument();
            document.Load(reader);

            ValidationEventHandler eventHandler = new ValidationEventHandler(XSDValidationEventHandler);

            // the following call to Validate succeeds.
            document.Validate(eventHandler);

            return true;
        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
            //Console.WriteLine(ex.Message);
            return false;
        }
    }

    static void XSDValidationEventHandler(object sender, ValidationEventArgs e)
    {
        switch (e.Severity)
        {
            case XmlSeverityType.Error:
                Console.WriteLine("Error: {0}", e.Message);
                break;
            case XmlSeverityType.Warning:
                Console.WriteLine("Warning {0}", e.Message);
                break;
        }

    }

    public static string createRbiAck(string filename, string eventcode)
    {
        try
        {
            string filetype = String.Empty;

            XmlDocument xmlDoc = new XmlDocument();
            XmlNode rootNode = xmlDoc.CreateElement("RequestPayload");
            xmlDoc.AppendChild(rootNode);

            XmlNode AppHdr = xmlDoc.CreateElement("AppHdr");
            rootNode.AppendChild(AppHdr);

            XmlNode Fr = xmlDoc.CreateElement("Fr");
            AppHdr.AppendChild(Fr);
            XmlNode OrgId = xmlDoc.CreateElement("OrgId");
            Fr.AppendChild(OrgId);
            XmlNode Id = xmlDoc.CreateElement("Id");
            OrgId.AppendChild(Id);
            XmlNode OrgId2 = xmlDoc.CreateElement("OrgId");
            Id.AppendChild(OrgId2);
            XmlNode Othr = xmlDoc.CreateElement("Othr");
            OrgId2.AppendChild(Othr);
            XmlNode Id2 = xmlDoc.CreateElement("Id");
            Id2.InnerText = "750";
            Othr.AppendChild(Id2);

            XmlNode To = xmlDoc.CreateElement("To");
            AppHdr.AppendChild(To);
            XmlNode FIId = xmlDoc.CreateElement("FIId");
            To.AppendChild(FIId);
            XmlNode FinInstnId = xmlDoc.CreateElement("FinInstnId");
            FIId.AppendChild(FinInstnId);
            XmlNode ClrSysMmbId = xmlDoc.CreateElement("ClrSysMmbId");
            FinInstnId.AppendChild(ClrSysMmbId);
            XmlNode MmbId = xmlDoc.CreateElement("MmbId");
            MmbId.InnerText = "RBI";
            ClrSysMmbId.AppendChild(MmbId);

            XmlNode BizMsgIdr = xmlDoc.CreateElement("BizMsgIdr");
            BizMsgIdr.InnerText = filename;
            AppHdr.AppendChild(BizMsgIdr);

            XmlNode MsgDefIdr = xmlDoc.CreateElement("MsgDefIdr");
            MsgDefIdr.InnerText = "admi.004.001.02";
            AppHdr.AppendChild(MsgDefIdr);

            XmlNode BizSvc = xmlDoc.CreateElement("BizSvc");
            BizSvc.InnerText = "SystemEventNotificationV02";
            AppHdr.AppendChild(BizSvc);

            XmlNode CreDt = xmlDoc.CreateElement("CreDt");
            CreDt.InnerText = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
            AppHdr.AppendChild(CreDt);


            XmlNode Document = xmlDoc.CreateElement("Document");
            rootNode.AppendChild(Document);

            XmlNode SysEvtNtfctn = xmlDoc.CreateElement("SysEvtNtfctn");
            Document.AppendChild(SysEvtNtfctn);

            XmlNode EvtInf = xmlDoc.CreateElement("EvtInf");
            SysEvtNtfctn.AppendChild(EvtInf);


            XmlNode EvtCd = xmlDoc.CreateElement("EvtCd");
            EvtCd.InnerText = eventcode;
            EvtInf.AppendChild(EvtCd);

            XmlNode EvtTm = xmlDoc.CreateElement("EvtTm");
            EvtTm.InnerText = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
            EvtInf.AppendChild(EvtTm);

            string xmlpath = HttpContext.Current.Server.MapPath(@"~/tempfiles/" + filename + ".xml");
            XmlDsigC14NTransform transform = new XmlDsigC14NTransform();
            transform.LoadInput(xmlDoc);
            MemoryStream outputStream = (MemoryStream)transform.GetOutput(typeof(Stream));
            File.WriteAllBytes(xmlpath, outputStream.ToArray());

            if (eventcode == "ACCP")
            {
                if (filename.Substring(3, 2) == "AS")
                {
                    filetype = "ASACK";
                }
                else
                {

                    filetype = "CNACK";
                }
            }

            else
            {
                filetype = "CNNCK";
            }

            int signedResult = signFileToSendRbi(xmlpath, filename, filetype, "");

            if (signedResult == 1)
            {
                return eventcode;
            }

        }
        catch (Exception e)
        {
            ExceptionLogging.logException(e);
        }
        return null;
    }


    public static int signFileToSendRbi(string xmlpath, string filename, string filetype, string subfiletype)
    {
        int result = 0;
        try
        {
            string path = System.IO.Path.GetFullPath(Constants.Keys_Path + "PAO_Delhi.pfx");
            X509Certificate2 cert = new X509Certificate2(path, "pao@123#");

            ContentInfo contentInfo = new ContentInfo(File.ReadAllBytes(xmlpath));
            SignedCms cms = new SignedCms(contentInfo, true);
            CmsSigner signer = new CmsSigner(cert);
            cms.ComputeSignature(signer);
            byte[] pkcs7 = cms.Encode();

            string sigfilepath = HttpContext.Current.Server.MapPath(@"~/tempfiles/" + filename + ".sig");
            File.WriteAllBytes(sigfilepath, pkcs7); // Requires System.IO


            List<string> files = new List<string>();

            files.Add(sigfilepath);
            files.Add(xmlpath);

            result = createZipAndSendFile(files, filename, filetype, subfiletype);
        }
        catch (Exception e)
        {
            ExceptionLogging.logException(e);
        }

        return result;
    }

    public static int createZipAndSendFile(List<string> zipFileList, string zipfilename, string filetype, string subfiletype)
    {
        int result = 0;
        try
        {
            string path = Utility.getFileToSavePath("RBI", filetype, subfiletype, DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture));
            string fullpath = path + zipfilename + ".zip";
            FileStream fos = new FileStream(fullpath, FileMode.Create);
            ZipOutputStream zipOutputStream = new ZipOutputStream(fos);
            zipOutputStream.SetLevel(3); //0-9, 9 being the highest level of compression
            byte[] buffer = new byte[4096];

            foreach (string fileName in zipFileList)
            {

                Stream fs = File.OpenRead(fileName);	// or any suitable inputstream

                ZipEntry entry = new ZipEntry(ZipEntry.CleanName(Path.GetFileName(fileName)));
                entry.Size = fs.Length;
                // Setting the Size provides WinXP built-in extractor compatibility,
                //  but if not available, you can set zipOutputStream.UseZip64 = UseZip64.Off instead.

                zipOutputStream.PutNextEntry(entry);

                int count = fs.Read(buffer, 0, buffer.Length);
                while (count > 0)
                {
                    zipOutputStream.Write(buffer, 0, count);
                    count = fs.Read(buffer, 0, buffer.Length);
                }

                fs.Close();   //  Close input Stream

                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }
            }

            //  Close outputs
            zipOutputStream.CloseEntry();
            zipOutputStream.Close();
            fos.Close();

            PullPushRbiFiles ppfiles = new PullPushRbiFiles();
            string toPath = string.Empty;
            //string toPath = filetype;

            if (filetype == "ASACK")
            {
                toPath = "/ACSTACK";
            }
            else if (filetype == "ASNCK")
            {
                toPath = "/ACSTNCK";
            }
            else
            {

                if (!string.IsNullOrEmpty(subfiletype))
                {
                    toPath = "ERGST/" + filetype + "/" + subfiletype;
                }
                else
                {
                    toPath = "ERGST/" + filetype;
                }
            }
            result = ppfiles.pushFiles(fullpath, toPath);

        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
        }

        return result;
    }

    public static string getMoeFileName(string moetype)
    {
        string filename = string.Empty;
        string ntype = string.Empty;
        try
        {
            if (moetype == "1")
            {
                ntype = "NR";
            }
            else
            {
                ntype = "UA";
            }

            PostgresGetData getdata = new PostgresGetData();

            StringBuilder selectQuery = new StringBuilder(@"select lpad((count(moefileid)+1)::text, 5, '0') seq from moe_files where to_char(generatedatetime, 'DD-MM-YYYY') = to_char(now(), 'DD-MM-YYYY')");
            NpgsqlCommand cmd = new NpgsqlCommand(selectQuery.ToString());
            DataTable dt = getdata.GetDataTable(cmd, "nfs");

            if (dt.Rows.Count > 0)
            {

                filename = ntype + Constants.PADDED_UDCH_CODE + Constants.TREASURY_ACCOUNT + DateTime.Now.ToString("yyyyMMdd") + dt.Rows[0]["seq"].ToString();
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
        }

        return filename;
    }

    public static string getMoeCaseId(string finacialyear)
    {
        string caseid = string.Empty;

        try
        {
            PostgresGetData getdata = new PostgresGetData();

            StringBuilder selectQuery = new StringBuilder(@"select lpad((count(id)+1)::text, 6, '0') seq from moe_cases where finyear = @finyear");
            NpgsqlCommand cmd = new NpgsqlCommand(selectQuery.ToString());
            cmd.Parameters.AddWithValue("@finyear", finacialyear);
            DataTable dt = getdata.GetDataTable(cmd, "nfs");

            if (dt.Rows.Count > 0)
            {

                caseid = Constants.STATE_CODE + Constants.UDCH_CODE + DateTime.Now.ToString("yyyyMMdd") + dt.Rows[0]["seq"].ToString();
            }
        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
        }

        return caseid;
    }

    public static bool isRecordExits(string tablename, string fieldname, string fieldval)
    {
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder("select " + fieldname + " from " + tablename + " where " + fieldname + " =@fieldval");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@fieldval", fieldval);
        DataTable dtrec = data.GetDataTable(SelectCmd, "nfs");

        if (dtrec.Rows.Count > 0)
        {
            return true;
        }

        return false;

    }
}