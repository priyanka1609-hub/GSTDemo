﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;

public partial class Moe_CinConsiderForMoe : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();

    protected void Page_Load(object sender, EventArgs e)
    {
        fillgrid();
    }

    private void fillgrid()
    {

        StringBuilder SelectQuery = new StringBuilder(@"select count(cin),description,mm.moetype from moe_compact mc
                                                        inner join master_moe mm on mm.moetype=mc.moetype
                                                        where status='M'group by mm.moetype");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        if (dt.Rows.Count > 0)
        {

            grdmoetxn.DataSource = dt;
            grdmoetxn.DataBind();
        }
        else
        {
            msg.Show("No Data Found");
        }

    }


    protected void grdmoetxn_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            string moetype = grdmoetxn.DataKeys[e.Row.RowIndex].Values["moetype"].ToString();
            HyperLink hylnkgenerate = (HyperLink)e.Row.FindControl("hylnkgenerate");

            if (moetype == "1")
            {
                hylnkgenerate.NavigateUrl = md5util.CreateTamperProofURL("GenerateNonReceiptMoe.aspx", null, "moetype=" + MD5Util.Encrypt(moetype, true));
            }
            else
            {
                hylnkgenerate.NavigateUrl = md5util.CreateTamperProofURL("GenerateUaMoe.aspx", null, "moetype=" + MD5Util.Encrypt(moetype, true));
            }


        }

    }
}