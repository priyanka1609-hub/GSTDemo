﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;

public partial class Moe_GenerateUaMoe : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
        {

            if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
            StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
            {
                Response.Redirect("Login.aspx?id=0");
            }
        }
        if (Request.QueryString["moetype"] != null)
        {
            string moetype = MD5Util.Decrypt(Request.QueryString["moetype"].ToString(), true);
            generateMoe(moetype);
        }

    }

    protected void generateMoe(string moetype)
    {
        string filename = RbiValidations.getMoeFileName(moetype);
        int casesInserted = 0;

        if (!string.IsNullOrEmpty(filename))
        {
            string ipaddrs = PostgresGetData.GetIP4Address();

            StringBuilder insert_qry = new StringBuilder(@"INSERT INTO moe_files(notificcationtype, moetype, filename, generatedatetime, userid, ipaddress)
                                                        VALUES (@notificcationtype, @moetype, @filename, now(), @userid, @ipaddress); select lastval();");
            NpgsqlCommand insertCmd = new NpgsqlCommand(insert_qry.ToString());
            insertCmd.Parameters.AddWithValue("@notificcationtype", filename.Substring(0, 2));
            insertCmd.Parameters.AddWithValue("@moetype", moetype);
            insertCmd.Parameters.AddWithValue("@filename", filename);
            insertCmd.Parameters.AddWithValue("@userid", Session["USER_ID"].ToString());
            insertCmd.Parameters.AddWithValue("@ipaddress", ipaddrs);

            int recordInsereted = data.UpdateScalarData(insertCmd, "nfs");

            if (recordInsereted > 0)
            {
                StringBuilder SelectQuery = new StringBuilder(@"select moe.cin,rbi.msgid,rbi.amt,ntry.valdt,mm.moecode,mm.addtlinfo from moe_compact moe
                                                                inner join rbi_response_txns_details rbi on moe.cin=rbi.cin
                                                                inner join rbi_response_entries ntry on ntry.ntryref = rbi.ntryref
                                                                inner join master_moe mm on mm.moetype=moe.moetype
                                                                where moe.moetype=@moetype and moe.status='M' ");
                NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
                SelectCmd.Parameters.AddWithValue("@moetype", moetype);
                DataTable dt = data.GetDataTable(SelectCmd, "nfs");

                if (dt.Rows.Count > 0)
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    XmlNode rootNode = xmlDoc.CreateElement("RequestPayload");
                    xmlDoc.AppendChild(rootNode);

                    XmlNode AppHdr = xmlDoc.CreateElement("AppHdr");
                    rootNode.AppendChild(AppHdr);

                    XmlNode Fr = xmlDoc.CreateElement("Fr");
                    AppHdr.AppendChild(Fr);
                    XmlNode OrgId = xmlDoc.CreateElement("OrgId");
                    Fr.AppendChild(OrgId);
                    XmlNode Id = xmlDoc.CreateElement("Id");
                    OrgId.AppendChild(Id);
                    XmlNode OrgId2 = xmlDoc.CreateElement("OrgId");
                    Id.AppendChild(OrgId2);
                    XmlNode Othr = xmlDoc.CreateElement("Othr");
                    OrgId2.AppendChild(Othr);
                    XmlNode Id2 = xmlDoc.CreateElement("Id");
                    Id2.InnerText = Constants.UDCH_CODE;
                    Othr.AppendChild(Id2);

                    XmlNode To = xmlDoc.CreateElement("To");
                    AppHdr.AppendChild(To);
                    XmlNode FIId = xmlDoc.CreateElement("FIId");
                    To.AppendChild(FIId);
                    XmlNode FinInstnId = xmlDoc.CreateElement("FinInstnId");
                    FIId.AppendChild(FinInstnId);
                    XmlNode ClrSysMmbId = xmlDoc.CreateElement("ClrSysMmbId");
                    FinInstnId.AppendChild(ClrSysMmbId);
                    XmlNode MmbId = xmlDoc.CreateElement("MmbId");
                    MmbId.InnerText = "RBI";
                    ClrSysMmbId.AppendChild(MmbId);

                    XmlNode BizMsgIdr = xmlDoc.CreateElement("BizMsgIdr");
                    BizMsgIdr.InnerText = filename;
                    AppHdr.AppendChild(BizMsgIdr);

                    XmlNode MsgDefIdr = xmlDoc.CreateElement("MsgDefIdr");
                    MsgDefIdr.InnerText = Constants.MOE_FORMAT_UA;
                    AppHdr.AppendChild(MsgDefIdr);

                    XmlNode BizSvc = xmlDoc.CreateElement("BizSvc");
                    BizSvc.InnerText = Constants.MOE_SERVICE_UA;
                    AppHdr.AppendChild(BizSvc);

                    XmlNode CreDt = xmlDoc.CreateElement("CreDt");
                    CreDt.InnerText = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
                    AppHdr.AppendChild(CreDt);


                    XmlNode Document = xmlDoc.CreateElement("Document");
                    rootNode.AppendChild(Document);

                    XmlNode ClmNonRct = xmlDoc.CreateElement("UblToApply");
                    Document.AppendChild(ClmNonRct);

                    XmlNode Assgnmt = xmlDoc.CreateElement("Assgnmt");
                    ClmNonRct.AppendChild(Assgnmt);

                    XmlNode Assgnmt_Id = xmlDoc.CreateElement("Id");
                    Assgnmt_Id.InnerText = filename;
                    Assgnmt.AppendChild(Assgnmt_Id);

                    XmlNode Assgnr = xmlDoc.CreateElement("Assgnr");
                    Assgnmt.AppendChild(Assgnr);

                    XmlNode Pty = xmlDoc.CreateElement("Pty");
                    Assgnr.AppendChild(Pty);

                    XmlNode Assgnr_Id = xmlDoc.CreateElement("Id");
                    Pty.AppendChild(Assgnr_Id);

                    XmlNode Assgnr_OrgId = xmlDoc.CreateElement("OrgId");
                    Assgnr_Id.AppendChild(Assgnr_OrgId);

                    XmlNode Assgnr_Othr = xmlDoc.CreateElement("Othr");
                    Assgnr_OrgId.AppendChild(Assgnr_Othr);

                    XmlNode Assgnr_Id2 = xmlDoc.CreateElement("Id");
                    Assgnr_Id2.InnerText = Constants.UDCH_CODE;
                    Assgnr_Othr.AppendChild(Assgnr_Id2);

                    XmlNode Assgne = xmlDoc.CreateElement("Assgne");
                    Assgnmt.AppendChild(Assgne);

                    XmlNode Assgne_Pty = xmlDoc.CreateElement("Pty");
                    Assgne.AppendChild(Assgne_Pty);

                    XmlNode Assgne_Id = xmlDoc.CreateElement("Id");
                    Assgne_Pty.AppendChild(Assgne_Id);

                    XmlNode Assgne_OrgId = xmlDoc.CreateElement("OrgId");
                    Assgne_Id.AppendChild(Assgne_OrgId);

                    XmlNode Assgne_Othr = xmlDoc.CreateElement("Othr");
                    Assgne_OrgId.AppendChild(Assgne_Othr);

                    XmlNode Assgne_Id2 = xmlDoc.CreateElement("Id");
                    Assgne_Id2.InnerText = "RBI";
                    Assgne_Othr.AppendChild(Assgne_Id2);

                    XmlNode Assgnmt_CreDtTm = xmlDoc.CreateElement("CreDtTm");
                    Assgnmt_CreDtTm.InnerText = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
                    Assgnmt.AppendChild(Assgnmt_CreDtTm);

                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        XmlNode Case = xmlDoc.CreateElement("Case");
                        ClmNonRct.AppendChild(Case);

                        XmlNode Case_Id = xmlDoc.CreateElement("Id");
                        string caseid = RbiValidations.getMoeCaseId(Utility.getFinancialYear());
                        Case_Id.InnerText = caseid;
                        Case.AppendChild(Case_Id);

                        XmlNode Cretr = xmlDoc.CreateElement("Cretr");
                        Case.AppendChild(Cretr);

                        XmlNode Cretr_Pty = xmlDoc.CreateElement("Pty");
                        Cretr.AppendChild(Cretr_Pty);

                        XmlNode Cretr_Id = xmlDoc.CreateElement("Id");
                        Cretr_Pty.AppendChild(Cretr_Id);

                        XmlNode Cretr_OrgId = xmlDoc.CreateElement("OrgId");
                        Cretr_Id.AppendChild(Cretr_OrgId);

                        XmlNode Cretr_Othr = xmlDoc.CreateElement("Othr");
                        Cretr_OrgId.AppendChild(Cretr_Othr);

                        XmlNode SchmeNm = xmlDoc.CreateElement("SchmeNm");
                        Cretr_Othr.AppendChild(SchmeNm);

                        XmlNode Prtry = xmlDoc.CreateElement("Prtry");
                        Prtry.InnerText = "SGST";
                        SchmeNm.AppendChild(Prtry);

                        XmlNode Undrlyg = xmlDoc.CreateElement("Undrlyg");
                        Case.AppendChild(Undrlyg);

                        XmlNode Initn = xmlDoc.CreateElement("Initn");
                        Undrlyg.AppendChild(Initn);

                        XmlNode OrgnlGrpInf = xmlDoc.CreateElement("OrgnlGrpInf");
                        Initn.AppendChild(OrgnlGrpInf);

                        XmlNode OrgnlMsgId = xmlDoc.CreateElement("OrgnlMsgId");
                        OrgnlMsgId.InnerText = dt.Rows[i]["msgid"].ToString();
                        OrgnlGrpInf.AppendChild(OrgnlMsgId);

                        XmlNode OrgnlEndToEndId = xmlDoc.CreateElement("OrgnlEndToEndId");
                        OrgnlEndToEndId.InnerText = dt.Rows[i]["cin"].ToString();
                        Initn.AppendChild(OrgnlEndToEndId);

                        XmlNode OrgnlInstdAmt = xmlDoc.CreateElement("OrgnlInstdAmt");
                        XmlAttribute Ccy = xmlDoc.CreateAttribute("Ccy");
                        Ccy.Value = "INR";
                        OrgnlInstdAmt.Attributes.SetNamedItem(Ccy);
                        OrgnlInstdAmt.InnerText = dt.Rows[i]["amt"].ToString();
                        Initn.AppendChild(OrgnlInstdAmt);

                        XmlNode ReqdExctnDt = xmlDoc.CreateElement("ReqdExctnDt");
                        ReqdExctnDt.InnerText = dt.Rows[i]["valdt"].ToString();
                        Initn.AppendChild(ReqdExctnDt);

                        XmlNode Justfn = xmlDoc.CreateElement("Justfn");
                        Case.AppendChild(Justfn);

                        XmlNode MssngOrIncrrctInf = xmlDoc.CreateElement("MssngOrIncrrctInf");
                        Justfn.AppendChild(MssngOrIncrrctInf);

                        XmlNode IncrrctInf = xmlDoc.CreateElement("IncrrctInf");
                        IncrrctInf.InnerText = dt.Rows[i]["moecode"].ToString();
                        MssngOrIncrrctInf.AppendChild(IncrrctInf);

                        XmlNode SplmtryData = xmlDoc.CreateElement("SplmtryData");
                        Case.AppendChild(SplmtryData);

                        XmlNode Envlp = xmlDoc.CreateElement("Envlp");
                        SplmtryData.AppendChild(Envlp);

                        XmlNode AddtlTxInf = xmlDoc.CreateElement("AddtlTxInf");
                        AddtlTxInf.InnerText = dt.Rows[i]["addtlinfo"].ToString();
                        Envlp.AppendChild(AddtlTxInf);

                        StringBuilder insert_cases = new StringBuilder(@"INSERT INTO moe_cases(moefileid, moetype, caseid, taxid, cin, originalamt, extrainfo, insertdatetime, finyear, originalmsgid, valdate, moecode )
                        VALUES (@moefileid, @moetype, @caseid, @taxid, @cin, @originalamt, @extrainfo, now(), @finyear, @originalmsgid, @valdate, @moecode);");
                        NpgsqlCommand insertcasesCmd = new NpgsqlCommand(insert_cases.ToString());
                        insertcasesCmd.Parameters.AddWithValue("@moefileid", recordInsereted);
                        insertcasesCmd.Parameters.AddWithValue("@moetype", moetype);
                        insertcasesCmd.Parameters.AddWithValue("@caseid", caseid);
                        insertcasesCmd.Parameters.AddWithValue("@taxid", "SGST");
                        insertcasesCmd.Parameters.AddWithValue("@cin", dt.Rows[i]["cin"].ToString());
                        insertcasesCmd.Parameters.AddWithValue("@originalamt", dt.Rows[i]["amt"].ToString());
                        insertcasesCmd.Parameters.AddWithValue("@extrainfo", dt.Rows[i]["addtlinfo"].ToString());
                        insertcasesCmd.Parameters.AddWithValue("@finyear", Utility.getFinancialYear());
                        insertcasesCmd.Parameters.AddWithValue("@originalmsgid", dt.Rows[i]["msgid"].ToString());
                        insertcasesCmd.Parameters.AddWithValue("@valdate", dt.Rows[i]["valdt"].ToString());
                        insertcasesCmd.Parameters.AddWithValue("@moecode", dt.Rows[i]["moecode"].ToString());

                        casesInserted = casesInserted + data.UpdateData(insertcasesCmd, "nfs");

                        if (casesInserted > i)
                        {
                            StringBuilder update_status = new StringBuilder(@"Update moe_compact set status=@status, updatedatetime=now() where cin=@cin");
                            NpgsqlCommand update_statusCmd = new NpgsqlCommand(update_status.ToString());
                            update_statusCmd.Parameters.AddWithValue("@status", "MG");
                            update_statusCmd.Parameters.AddWithValue("@cin", dt.Rows[i]["cin"].ToString());

                            int updated = data.UpdateData(update_statusCmd, "nfs");
                        }


                    }

                    if (casesInserted > 0)
                    {
                        StringBuilder insert_cases = new StringBuilder(@"Update moe_files set totalcases=@totalcases where moefileid=@moefileid");
                        NpgsqlCommand insertcasesCmd = new NpgsqlCommand(insert_cases.ToString());
                        insertcasesCmd.Parameters.AddWithValue("@moefileid", recordInsereted);
                        insertcasesCmd.Parameters.AddWithValue("@totalcases", casesInserted);

                        int totalcase = data.UpdateScalarData(insertcasesCmd, "nfs");
                    }

                    string xmlpath = HttpContext.Current.Server.MapPath(@"~/tempfiles/" + filename + ".XML");

                    XmlDsigC14NTransform transform = new XmlDsigC14NTransform();
                    transform.LoadInput(xmlDoc);
                    MemoryStream outputStream = (MemoryStream)transform.GetOutput(typeof(Stream));
                    File.WriteAllBytes(xmlpath, outputStream.ToArray());

                    //RbiValidations.signFileToSendRbi(xmlpath, filename, "MOE", "CASE");
                }
            }
        }

    }
}