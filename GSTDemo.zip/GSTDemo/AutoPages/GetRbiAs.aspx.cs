﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using Npgsql;
using System.Data;
using GstDelhi.PostgresData;
using System.Security.Cryptography;
using System.IO;
using System.Security.Cryptography.Pkcs;
using System.Security.Cryptography.X509Certificates;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using Org.BouncyCastle.Bcpg.OpenPgp;
using ICSharpCode.SharpZipLib.Zip;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Crypto.Parameters;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.Xml.Schema;
using System.Xml.XPath;
using System.Globalization;
using System.Xml.Serialization;
using Rbiaccstat;
using System.Web.UI;

public partial class AutoPages_GetRbiAs : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    protected void Page_Load(object sender, EventArgs e)
    {
        int insertstartdate = Utility.updatestarttime("RBI", "AS");

        string certpath = System.IO.Path.GetFullPath(Constants.Keys_Path + "CBS_BIG0202240226.cer");
        string xsdfilepath = HttpContext.Current.Server.MapPath(@"~/xsd/camt.053.001.06v0.1.xsd");
        string[] zipFiles = System.IO.Directory.GetFiles(Constants.RBI_FILE_AS_DOWNLOAD_PATH, "*.ZIP", System.IO.SearchOption.AllDirectories);
        int filesCount = zipFiles.Length;

        // Load the certificate into an X509Certificate object.
        X509Certificate2 cert = new X509Certificate2();
        cert.Import(certpath);

        if (filesCount > 0)
        {
            System.IO.DirectoryInfo di = new DirectoryInfo(Constants.RBI_EXTRACTED_PATH_AS);
            foreach (DirectoryInfo dir in di.GetDirectories())
            {
                dir.Delete(true);
            }

            for (int fc = 0; fc < filesCount; fc++)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                string Extractedpath = RbiValidations.ExtractRbiZIPAS(zipFiles[fc]);
                string filename = Path.GetFileNameWithoutExtension(zipFiles[fc]);
                string filenamewithextn = Path.GetFileName(zipFiles[fc]);
                string completePath = Extractedpath + "\\" + filename;

                int isAllFilesPresent = RbiValidations.checkXmlSigFilePresent(completePath);

                if (isAllFilesPresent == 3)
                {
                    byte[] signbyte = System.IO.File.ReadAllBytes(completePath + ".SIG");
                    byte[] xmlfilebyte = System.IO.File.ReadAllBytes(completePath + ".XML");

                    if (RbiValidations.verifySignAndCertificate(signbyte, xmlfilebyte, cert))
                    {
                        var xml = System.IO.File.ReadAllText(completePath + ".XML");

                        if (RbiValidations.XSDValidation(completePath + ".XML", xsdfilepath))
                        {
                            System.IO.File.WriteAllText(Constants.SAVED_FILE_PATH + "RBI\\RAWDATA\\" + filename + ".XML", completePath);

                            List<NpgsqlCommand> cmdListInner = new List<NpgsqlCommand>();
                            using (MemoryStream stream = new MemoryStream(Encoding.UTF8.GetBytes(xml)))
                            {
                                XmlSerializer serializer = new XmlSerializer(typeof(RequestPayload));
                                RequestPayload resdata = (RequestPayload)serializer.Deserialize(stream);




                                StringBuilder insert_qryInner = new StringBuilder(@"INSERT INTO rbi_as_header(
                      fromloc, toloc, bigmsgidr, msgdefidr, bizsvc, crtdatetime, grphdrmsgid, grphdrcrtdt, insertdatetime)
            VALUES (@from, @to, @bizmsgidr, @msgdefidr, @bizsvc, @crtdatetime, @grphdrmsgid, @grphdrcrtdt, now());");
                                NpgsqlCommand insertCmdInner = new NpgsqlCommand(insert_qryInner.ToString());
                                insertCmdInner.Parameters.AddWithValue("@from", resdata.AppHdr.Fr.FIId.FinInstnId.ClrSysMmbId.MmbId);
                                insertCmdInner.Parameters.AddWithValue("@to", resdata.AppHdr.To.OrgId.Id.OrgId.Othr.Id);
                                insertCmdInner.Parameters.AddWithValue("@bizmsgidr", resdata.AppHdr.BizMsgIdr);
                                insertCmdInner.Parameters.AddWithValue("@msgdefidr", resdata.AppHdr.MsgDefIdr);
                                insertCmdInner.Parameters.AddWithValue("@bizsvc", resdata.AppHdr.BizSvc);
                                insertCmdInner.Parameters.AddWithValue("@crtdatetime", Utility.converttodate_from_YYYYMMDD_T_HHMMSS(resdata.AppHdr.CreDt));
                                insertCmdInner.Parameters.AddWithValue("@grphdrmsgid", resdata.Document.BkToCstmrStmt.GrpHdr.MsgId);
                                insertCmdInner.Parameters.AddWithValue("@grphdrcrtdt", Utility.converttodate_from_YYYYMMDD_T_HHMMSS(resdata.Document.BkToCstmrStmt.GrpHdr.CreDtTm));

                                //insertCmdInner.Parameters.AddWithValue("@scrolldate", Utility.converttodate_from_DDMMYYYY(resdata.AppHdr.BizMsgIdr.Substring(20, 8)));

                                cmdListInner.Add(insertCmdInner);

                                insert_qryInner = new StringBuilder(@"INSERT INTO rbi_as_statement(
                                                stmtid, pageno, lastpage, credatetime, fromdatetime, todatetime, account, insertdatetime,bigmsgidr,totcdntries,totcdamt,totdbntries,totdbamt)
                                        VALUES (@stmtid, @pageno, @lastpage, @credatetime, @fromdatetime, @todatetime, @account, now(),@bigmsgidr,@totcdntries,@totcdamt,@totdbntries,@totdbamt);");
                                insertCmdInner = new NpgsqlCommand(insert_qryInner.ToString());
                                insertCmdInner.Parameters.AddWithValue("@stmtid", resdata.Document.BkToCstmrStmt.Stmt.Id);
                                insertCmdInner.Parameters.AddWithValue("@pageno", resdata.Document.BkToCstmrStmt.Stmt.StmtPgntn.PgNb);
                                insertCmdInner.Parameters.AddWithValue("@lastpage", resdata.Document.BkToCstmrStmt.Stmt.StmtPgntn.LastPgInd);
                                insertCmdInner.Parameters.AddWithValue("@credatetime", Utility.converttodate_from_YYYYMMDD_T_HHMMSS(resdata.Document.BkToCstmrStmt.Stmt.CreDtTm));
                                insertCmdInner.Parameters.AddWithValue("@fromdatetime", Utility.converttodate_from_YYYYMMDD_T_HHMMSS(resdata.Document.BkToCstmrStmt.Stmt.FrToDt.FrDtTm));
                                insertCmdInner.Parameters.AddWithValue("@todatetime", Utility.converttodate_from_YYYYMMDD_T_HHMMSS(resdata.Document.BkToCstmrStmt.Stmt.FrToDt.ToDtTm));
                                insertCmdInner.Parameters.AddWithValue("@account", resdata.Document.BkToCstmrStmt.Stmt.Acct.Id.Othr.Id);
                                insertCmdInner.Parameters.AddWithValue("@bigmsgidr", resdata.AppHdr.BizMsgIdr);
                                insertCmdInner.Parameters.AddWithValue("@totcdntries", resdata.Document.BkToCstmrStmt.Stmt.TxsSummry.TtlCdtNtries.NbOfNtries);
                                insertCmdInner.Parameters.AddWithValue("@totcdamt", resdata.Document.BkToCstmrStmt.Stmt.TxsSummry.TtlCdtNtries.Sum);
                                insertCmdInner.Parameters.AddWithValue("@totdbntries", resdata.Document.BkToCstmrStmt.Stmt.TxsSummry.TtlDbtNtries.NbOfNtries);
                                insertCmdInner.Parameters.AddWithValue("@totdbamt", resdata.Document.BkToCstmrStmt.Stmt.TxsSummry.TtlDbtNtries.Sum);
                                cmdListInner.Add(insertCmdInner);

                                int totalEntries = resdata.Document.BkToCstmrStmt.Stmt.Ntry.Count;

                                foreach (var bal in resdata.Document.BkToCstmrStmt.Stmt.Bal)
                                {
                                    insert_qryInner = new StringBuilder(@"INSERT INTO rbi_as_balance(baltype, amt, cdordb, exedatetime, stmtid, insertdatetime)
                                                                                                   VALUES (@baltype, @amt, @cdordb, @exedatetime, @stmtid, now());");
                                    insertCmdInner = new NpgsqlCommand(insert_qryInner.ToString());

                                    insertCmdInner.Parameters.AddWithValue("@baltype", bal.Tp.CdOrPrtry.Cd);
                                    insertCmdInner.Parameters.AddWithValue("@amt", bal.Amt.Text);
                                    insertCmdInner.Parameters.AddWithValue("@exedatetime", Utility.converttodate_from_YYYYMMDD_T_HHMMSS(bal.Dt.DtTm));
                                    insertCmdInner.Parameters.AddWithValue("@cdordb", bal.CdtDbtInd);
                                    insertCmdInner.Parameters.AddWithValue("@stmtid", resdata.Document.BkToCstmrStmt.Stmt.Id);
                                    cmdListInner.Add(insertCmdInner);


                                }

                                foreach (var entry in resdata.Document.BkToCstmrStmt.Stmt.Ntry)
                                {
                                    //int totaltxns = resdata.Document.BkToCstmrDbtCdtNtfctn.Ntfctn.Ntry.NtryDtls.TxDtls.Count;

                                    insert_qryInner = new StringBuilder(@"INSERT INTO rbi_as_entries(
                                                                  ntryref, amt, cdordb, rvslind, status,bookingdate,valdate,mode,insertdatetime,stmtid) 
                                                       VALUES (@ntryref, @amt, @cdordb, @rvslind,@status, @bookingdate,@valdate,@mode,now(),@stmtid);");
                                    insertCmdInner = new NpgsqlCommand(insert_qryInner.ToString());
                                    insertCmdInner.Parameters.AddWithValue("@ntryref", entry.NtryRef);
                                    insertCmdInner.Parameters.AddWithValue("@amt", entry.Amt.Text);
                                    insertCmdInner.Parameters.AddWithValue("@cdordb", entry.CdtDbtInd);
                                    insertCmdInner.Parameters.AddWithValue("@rvslind", entry.RvslInd);
                                    insertCmdInner.Parameters.AddWithValue("@status", entry.Sts);
                                    insertCmdInner.Parameters.AddWithValue("@bookingdate", entry.BookgDt.Dt);
                                    insertCmdInner.Parameters.AddWithValue("@valdate", entry.ValDt.Dt);
                                    insertCmdInner.Parameters.AddWithValue("@mode", entry.BkTxCd.Prtry.Cd);
                                    insertCmdInner.Parameters.AddWithValue("@stmtid", resdata.Document.BkToCstmrStmt.Stmt.Id);
                                    cmdListInner.Add(insertCmdInner);

                                }




                                int getRecordInseretedInner = data.SaveData(cmdListInner, "nfs");
                                if (getRecordInseretedInner > 0)
                                {
                                    sendAck("ACK", filename, "ACCP", zipFiles[fc], filenamewithextn);
                                    //string ack = RbiValidations.createRbiAck("ACK" + resdata.AppHdr.BizMsgIdr, "ACCP");
                                    //updateAckStatus(filename, ack);
                                    //string path = Utility.getFileToSavePath("RBI", "DownloadedFiles", "AS", DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture)) + filenamewithextn;
                                    //System.IO.File.Move(zipFiles[fc], path);

                                }

                            }
                        }
                        else
                        {
                            //if xsd validation fails
                            sendAck("NCK", filename, "EX0903", zipFiles[fc], filenamewithextn);
                        }

                    }
                    else
                    {
                        //if digial signature fails
                        sendAck("NCK", filename, "EX0010", zipFiles[fc], filenamewithextn);
                    }



                }
                else if (isAllFilesPresent == 2)
                {
                    // Signature file is missing
                    sendAck("NCK", filename, "EX0006", zipFiles[fc], filenamewithextn);
                }
                else if (isAllFilesPresent == 1)
                {
                    // XML file is missing
                    sendAck("NCK", filename, "EX0005", zipFiles[fc], filenamewithextn);
                }


            }
            int insertenddatetime = Utility.updateEndtime(insertstartdate);

        }
        ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "", "closeBrowser()", true);
    }


    private void updateAckStatus(string filename, string ack)
    {
        try
        {
            StringBuilder updateqry = new StringBuilder(@"update rbi_as_header set acksent=@acksent, acksentdate = now() where bigmsgidr=@bizmsgidr ;");
            NpgsqlCommand Upcmd = new NpgsqlCommand(updateqry.ToString());
            Upcmd.Parameters.AddWithValue("@bizmsgidr", filename);
            Upcmd.Parameters.AddWithValue("@acksent", ack);

            int res = data.UpdateData(Upcmd, "nfs");

        }
        catch (Exception e)
        {
            ExceptionLogging.logException(e);
        }
    }

    private void sendAck(string acktype, string filename, string ackcode, string zipfilepath, string filenamewithextn)
    {
        string ack = RbiValidations.createRbiAck(acktype + filename, ackcode);
        updateAckStatus(filename, ack);
        string path = Utility.getFileToSavePath("RBI", "DownloadedFiles", "AS", DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture)) + filenamewithextn;
        System.IO.File.Move(zipfilepath, path);
    }
}

