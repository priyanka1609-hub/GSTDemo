﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using Npgsql;
using System.Data;
using GstDelhi.PostgresData;
using System.Security.Cryptography;
using System.IO;
using System.Security.Cryptography.Pkcs;
using System.Security.Cryptography.X509Certificates;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using Org.BouncyCastle.Bcpg.OpenPgp;
using ICSharpCode.SharpZipLib.Zip;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Crypto.Parameters;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.Xml.Schema;
using System.Xml.XPath;
using System.Globalization;
using System.Xml.Serialization;
using RbiCreditResponse;
using System.Web.UI;

public partial class Auto_GetRbiCN : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();


    protected void Page_Load(object sender, EventArgs e)
    {
        int insertstartdate = Utility.updatestarttime("RBI", "CN");

        string certpath = System.IO.Path.GetFullPath(Constants.Keys_Path + "CBS_BIG0202240226.cer");


        string xsdfilepath = HttpContext.Current.Server.MapPath(@"~/xsd/camt.054.001.06v0.1.xsd");
        string[] zipFiles = System.IO.Directory.GetFiles(Constants.RBI_FILE_CN_DOWNLOAD_PATH, "*.ZIP", System.IO.SearchOption.AllDirectories);
        int filesCount = zipFiles.Length;

        // Load the certificate into an X509Certificate object.
        X509Certificate2 cert = new X509Certificate2();
        cert.Import(certpath);

        if (filesCount > 0)
        {
            System.IO.DirectoryInfo di = new DirectoryInfo(Constants.RBI_EXTRACTED_PATH);
            foreach (DirectoryInfo dir in di.GetDirectories())
            {
                dir.Delete(true);
            }
            for (int fc = 0; fc < filesCount; fc++)
            {
                List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();

                string Extractedpath = RbiValidations.ExtractRbiZIP(zipFiles[fc]);
                string filename = Path.GetFileNameWithoutExtension(zipFiles[fc]);
                string filenamewithextn = Path.GetFileName(zipFiles[fc]);
                string completePath = Extractedpath + "\\" + filename;

                int isAllFilesPresent = RbiValidations.checkXmlSigFilePresent(completePath);

                if (isAllFilesPresent == 3)
                {
                    byte[] signbyte = System.IO.File.ReadAllBytes(completePath + ".SIG");
                    byte[] xmlfilebyte = System.IO.File.ReadAllBytes(completePath + ".XML");

                    if (RbiValidations.verifySignAndCertificate(signbyte, xmlfilebyte, cert))
                    {
                        var xml = System.IO.File.ReadAllText(completePath + ".XML");

                        if (RbiValidations.XSDValidation(completePath + ".XML", xsdfilepath))
                        {
                            System.IO.File.WriteAllText(Constants.SAVED_FILE_PATH + "RBI\\RAWDATA\\" + filename + ".XML", completePath);

                            List<NpgsqlCommand> cmdListInner = new List<NpgsqlCommand>();
                            using (MemoryStream stream = new MemoryStream(Encoding.UTF8.GetBytes(xml)))
                            {
                                XmlSerializer serializer = new XmlSerializer(typeof(RequestPayload));
                                RequestPayload resdata = (RequestPayload)serializer.Deserialize(stream);


                                StringBuilder insert_qryInner = new StringBuilder(@"INSERT INTO rbi_response_header(
            fromsource, todestination, bizmsgidr, msgdefidr, bizsvc, credt, grphdrmsgid, grphdrcredt, edate, scrolldate)
            VALUES (@fromsource, @todestination, @bizmsgidr, @msgdefidr, @bizsvc, @credt, @grphdrmsgid, @grphdrcredt, now(), @scrolldate);");
                                NpgsqlCommand insertCmdInner = new NpgsqlCommand(insert_qryInner.ToString());
                                insertCmdInner.Parameters.AddWithValue("@fromsource", resdata.AppHdr.Fr.FIId.FinInstnId.ClrSysMmbId.MmbId);
                                insertCmdInner.Parameters.AddWithValue("@todestination", resdata.AppHdr.To.OrgId.Id.OrgId.Othr.Id);
                                insertCmdInner.Parameters.AddWithValue("@bizmsgidr", resdata.AppHdr.BizMsgIdr);
                                insertCmdInner.Parameters.AddWithValue("@msgdefidr", resdata.AppHdr.MsgDefIdr);
                                insertCmdInner.Parameters.AddWithValue("@bizsvc", resdata.AppHdr.BizSvc);
                                insertCmdInner.Parameters.AddWithValue("@credt", resdata.AppHdr.CreDt);
                                insertCmdInner.Parameters.AddWithValue("@grphdrmsgid", resdata.Document.BkToCstmrDbtCdtNtfctn.GrpHdr.MsgId);
                                insertCmdInner.Parameters.AddWithValue("@grphdrcredt", resdata.Document.BkToCstmrDbtCdtNtfctn.GrpHdr.CreDtTm);
                                insertCmdInner.Parameters.AddWithValue("@scrolldate", Utility.converttodate_from_DDMMYYYY(resdata.AppHdr.BizMsgIdr.Substring(20, 8)));

                                cmdListInner.Add(insertCmdInner);



                                insert_qryInner = new StringBuilder(@"INSERT INTO rbi_response_notifications(
            id, pgnb, lastpgind, credttm, accid, nbofntries, sum, edate,filename,scrolldate)
            VALUES (@id, @pgnb, @lastpgind, @credttm, @accid, @nbofntries, @sum, now(),@filename,@scrolldate);");
                                insertCmdInner = new NpgsqlCommand(insert_qryInner.ToString());
                                insertCmdInner.Parameters.AddWithValue("@id", resdata.Document.BkToCstmrDbtCdtNtfctn.Ntfctn.Id);
                                insertCmdInner.Parameters.AddWithValue("@pgnb", resdata.Document.BkToCstmrDbtCdtNtfctn.Ntfctn.NtfctnPgntn.PgNb);
                                insertCmdInner.Parameters.AddWithValue("@lastpgind", resdata.Document.BkToCstmrDbtCdtNtfctn.Ntfctn.NtfctnPgntn.LastPgInd);
                                insertCmdInner.Parameters.AddWithValue("@credttm", resdata.Document.BkToCstmrDbtCdtNtfctn.Ntfctn.CreDtTm);
                                insertCmdInner.Parameters.AddWithValue("@accid", resdata.Document.BkToCstmrDbtCdtNtfctn.Ntfctn.Acct.Id.Othr.Id);
                                insertCmdInner.Parameters.AddWithValue("@nbofntries", resdata.Document.BkToCstmrDbtCdtNtfctn.Ntfctn.TxsSummry.TtlCdtNtries.NbOfNtries);
                                insertCmdInner.Parameters.AddWithValue("@sum", resdata.Document.BkToCstmrDbtCdtNtfctn.Ntfctn.TxsSummry.TtlCdtNtries.Sum);
                                insertCmdInner.Parameters.AddWithValue("@filename", resdata.AppHdr.BizMsgIdr);
                                insertCmdInner.Parameters.AddWithValue("@scrolldate", Utility.converttodate_from_DDMMYYYY(resdata.AppHdr.BizMsgIdr.Substring(20, 8)));

                                cmdListInner.Add(insertCmdInner);




                                int totalEntries = resdata.Document.BkToCstmrDbtCdtNtfctn.Ntfctn.Ntry.Count;


                                foreach (var entry in resdata.Document.BkToCstmrDbtCdtNtfctn.Ntfctn.Ntry)
                                {
                                    //int totaltxns = resdata.Document.BkToCstmrDbtCdtNtfctn.Ntfctn.Ntry.NtryDtls.TxDtls.Count;

                                    insert_qryInner = new StringBuilder(@"INSERT INTO rbi_response_entries(
            ntryref, amt, valdt, nboftxs, edate,notifyid) VALUES (@ntryref, @amt, @valdt, @nboftxs, now(),@notifyid);");
                                    insertCmdInner = new NpgsqlCommand(insert_qryInner.ToString());
                                    insertCmdInner.Parameters.AddWithValue("@ntryref", entry.NtryRef);
                                    insertCmdInner.Parameters.AddWithValue("@amt", entry.Amt);
                                    insertCmdInner.Parameters.AddWithValue("@valdt", entry.ValDt.Dt);
                                    insertCmdInner.Parameters.AddWithValue("@nboftxs", entry.NtryDtls.Btch.NbOfTxs);
                                    insertCmdInner.Parameters.AddWithValue("@notifyid", resdata.Document.BkToCstmrDbtCdtNtfctn.Ntfctn.Id);
                                    cmdListInner.Add(insertCmdInner);

                                    int totaltxns = entry.NtryDtls.TxDtls.Count;

                                    foreach (var txn in entry.NtryDtls.TxDtls)
                                    {
                                        string tabletoinsert = String.Empty;

                                        if (RbiValidations.isRecordExits("rbi_response_txns_details", "cin", txn.Refs.EndToEndId))
                                        {
                                            tabletoinsert = "duplicate_rbi_response_txns_details";
                                        }
                                        else
                                        {
                                            tabletoinsert = "rbi_response_txns_details";
                                        }

                                        insert_qryInner = new StringBuilder("INSERT INTO "+ tabletoinsert +" (msgid, rbirefno, cpin, cin, utrno, brn, chqno, amt, senderifsc, micrbranchcode, majorhead, statecode, totaltxnamt, accptncdttm, txndttm, mode, edate,ntryref,paymentdatetime) VALUES (@msgid, @rbirefno, @cpin, @cin, @utrno, @brn, @chqno, @amt, @senderifsc, @micrbranchcode, @majorhead, @statecode, @totaltxnamt, @accptncdttm, @txndttm, @mode, now(),@ntryref, @paymentdatetime);");
                                        insertCmdInner = new NpgsqlCommand(insert_qryInner.ToString());

                                        insertCmdInner.Parameters.AddWithValue("@msgid", txn.Refs.MsgId);
                                        insertCmdInner.Parameters.AddWithValue("@rbirefno", txn.Refs.AcctSvcrRef);
                                        insertCmdInner.Parameters.AddWithValue("@cpin", txn.Refs.InstrId);
                                        insertCmdInner.Parameters.AddWithValue("@cin", txn.Refs.EndToEndId);
                                        insertCmdInner.Parameters.AddWithValue("@utrno", txn.Refs.TxId);
                                        insertCmdInner.Parameters.AddWithValue("@brn", txn.Refs.ClrSysRef);
                                        insertCmdInner.Parameters.AddWithValue("@chqno", txn.Refs.ChqNb);
                                        insertCmdInner.Parameters.AddWithValue("@amt", txn.Amt);
                                        insertCmdInner.Parameters.AddWithValue("@senderifsc", txn.RltdAgts.DbtrAgt.FinInstnId.ClrSysMmbId.MmbId);
                                        if (txn.RltdAgts.DbtrAgt.BrnchId != null)
                                        {
                                            insertCmdInner.Parameters.AddWithValue("@micrbranchcode", txn.RltdAgts.DbtrAgt.BrnchId.Id);
                                        }
                                        else
                                        {
                                            insertCmdInner.Parameters.AddWithValue("@micrbranchcode", System.DBNull.Value);
                                        }
                                        insertCmdInner.Parameters.AddWithValue("@majorhead", txn.RmtInf.Strd.TaxRmt.Cdtr.TaxId);
                                        insertCmdInner.Parameters.AddWithValue("@statecode", txn.RmtInf.Strd.TaxRmt.AdmstnZone);
                                        insertCmdInner.Parameters.AddWithValue("@totaltxnamt", txn.RmtInf.Strd.TaxRmt.TtlTaxAmt);
                                        insertCmdInner.Parameters.AddWithValue("@accptncdttm", Utility.converttodate_from_YYYYMMDD_T_HHMMSS(txn.RltdDts.AccptncDtTm));
                                        insertCmdInner.Parameters.AddWithValue("@txndttm", txn.RltdDts.TxDtTm);
                                        insertCmdInner.Parameters.AddWithValue("@mode", txn.AddtlTxInf);
                                        insertCmdInner.Parameters.AddWithValue("@ntryref", entry.NtryRef);
                                        insertCmdInner.Parameters.AddWithValue("@paymentdatetime", Utility.converttodate_from_YYYYMMDD_T_HHMMSS(txn.RltdDts.TxDtTm));

                                        cmdListInner.Add(insertCmdInner);


                                    }
                                }

                                int getRecordInseretedInner = data.SaveData(cmdListInner, "nfs");
                                if (getRecordInseretedInner > 0)
                                {

                                    //string ack = RbiValidations.createRbiAck("ACK" + resdata.AppHdr.BizMsgIdr, "ACCP");
                                    //updateAckStatus(filename, ack);
                                    //string path = Utility.getFileToSavePath("RBI", "DownloadedFiles", "CN", DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture)) + filenamewithextn;
                                    //System.IO.File.Move(zipFiles[fc], path);

                                    sendAck("ACK", filename, "ACCP", zipFiles[fc], filenamewithextn);

                                }

                            }
                        }
                        else
                        {
                            //if xsd validation fails
                            sendAck("NCK", filename, "EX0903", zipFiles[fc], filenamewithextn);
                        }

                    }
                    else
                    {
                        //if digial signature fails
                        sendAck("NCK", filename, "EX0010", zipFiles[fc], filenamewithextn);
                    }



                }
                else if (isAllFilesPresent == 2)
                {
                    // Signature file is missing
                    sendAck("NCK", filename, "EX0006", zipFiles[fc], filenamewithextn);
                }
                else if (isAllFilesPresent == 1)
                {
                    // XML file is missing
                    sendAck("NCK", filename, "EX0005", zipFiles[fc], filenamewithextn);
                }


            }
            int insertenddatetime = Utility.updateEndtime(insertstartdate);

        }

        ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "", "closeBrowser()", true);

        
    }


    private void sendAck(string acktype, string filename, string ackcode, string zipfilepath, string filenamewithextn)
    {
        string ack = RbiValidations.createRbiAck(acktype + filename, ackcode);
        updateAckStatus(filename, ack);
        string path = Utility.getFileToSavePath("RBI", "DownloadedFiles", "CN", DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture)) + filenamewithextn;
        System.IO.File.Move(zipfilepath, path);
    }


    private void updateAckStatus(string filename, string ack)
    {
        try
        {
            StringBuilder updateqry = new StringBuilder(@"update rbi_response_header set acksent=@acksent, acksentdate = now() where bizmsgidr=@bizmsgidr ;");
            NpgsqlCommand Upcmd = new NpgsqlCommand(updateqry.ToString());
            Upcmd.Parameters.AddWithValue("@bizmsgidr", filename);
            Upcmd.Parameters.AddWithValue("@acksent", ack);

            int res = data.UpdateData(Upcmd, "nfs");

        }
        catch (Exception e)
        {
            ExceptionLogging.logException(e);
        }
    }

}
