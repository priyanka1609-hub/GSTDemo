﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WinSCP;
using Npgsql;
using System.Text;
using GstDelhi.PostgresData;

public partial class Auto_PullRbiCnFiles : System.Web.UI.Page
{
    public int insertstartdate;
    protected void Page_Load(object sender, EventArgs e)
    {
        insertstartdate = Utility.updatestarttime("RBI", "PULLCN");
        int i = getFilestoLocalDirectory();
        if (i == 1)
        {
            int insertenddatetime = Utility.updateEndtime(insertstartdate);
        }

        ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "", "closeBrowser()", true);
        
    }

    private int getFilestoLocalDirectory()
    {
        try
        {
            // Setup session options
            // Set up session options
            SessionOptions sessionOptions = new SessionOptions
            {
                Protocol = Protocol.Sftp,
                HostName = Constants.RBI_SFTP_HOST_NAME,
                UserName = Constants.RBI_SFTP_USER_NAME,
                Password = Constants.RBI_SFTP_PWD,
                SshHostKeyFingerprint = Constants.RBI_SFTP_KEY,
            };


            using (Session session = new Session())
            {
                // Connect
                session.Open(sessionOptions);

                // Download files
                TransferOptions transferOptions = new TransferOptions();
                transferOptions.TransferMode = TransferMode.Binary;

                TransferOperationResult transferResult;
                transferResult = session.GetFiles("/ERGST/CN/*.ZIP", "E:\\RBI_SFTP_Download_Files\\", false, transferOptions);

                // Throw on any error
                transferResult.Check();

                // Print results
                foreach (TransferEventArgs transfer in transferResult.Transfers)
                {
                    Console.WriteLine("Download of {0} succeeded", transfer.FileName);
                    session.MoveFile(transfer.FileName, "/ERGST/CN/Done/");
                }
            }

            return 1;
        }
        catch (Exception e)
        {
            //Console.WriteLine("Error: {0}", e);
            ExceptionLogging.logException(e);
            return 0;
        }
    }

    
}