﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using Newtonsoft.Json;
using System.Globalization;

public partial class Auto_GetCpin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["filetype"] = "CPIN";
    }
    protected void btn_getData_Click(object sender, EventArgs e)
    {
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder("select * from master_gstn_api");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        DataTable dtApiData = data.GetDataTable(SelectCmd, "nfs");


        if (dtApiData.Rows.Count > 0)
        {
            GSTN objgstn = new GSTN();

            string username = dtApiData.Rows[0]["username"].ToString();
            string pwd = dtApiData.Rows[0]["password"].ToString();
            string clientid = dtApiData.Rows[0]["clientid"].ToString();
            string clientsecret = dtApiData.Rows[0]["clientsecret"].ToString();
            string statecode = dtApiData.Rows[0]["statecode"].ToString();
            string urlauth = dtApiData.Rows[0]["urlauth"].ToString();
            string urlpay = dtApiData.Rows[0]["urlpay"].ToString();

            if (objgstn.apiAuthentication(username, pwd, clientid, clientsecret, statecode, urlauth))
            {

                string fileCountResult = objgstn.getFilesCount(ddldate.SelectedValue, "CPIN", urlpay, username, clientid, clientsecret, statecode);

                if (!string.IsNullOrEmpty(fileCountResult))
                {
                    GstnFileCount values = JsonConvert.DeserializeObject<GstnFileCount>(fileCountResult);
                    if (Convert.ToInt32(values.num_files) > 0)
                    {
                        for (Int32 i = 0; i < Convert.ToInt32(values.num_files); i++)
                        {
                            List<NpgsqlCommand> cmdListInner = new List<NpgsqlCommand>();

                            string fileDetails = objgstn.GetFileDetail(Convert.ToString(i + 1), "CPIN", ddldate.SelectedValue, urlpay, clientid, clientsecret, statecode, username);
                            if (!string.IsNullOrEmpty(fileDetails))
                            {
                                Dictionary<string, string> fileDownloadedData_sign = JsonConvert.DeserializeObject<Dictionary<string, string>>(fileDetails);
                                string downloaded_sign_data = fileDownloadedData_sign["data"];
                                string downloaded_signature = fileDownloadedData_sign["sign"];

                                //if (GstnValidations.checkDigitalSignature(Convert.FromBase64String(downloaded_sign_data), Convert.FromBase64String(downloaded_signature)))
                                //{
                                    string result = Encoding.UTF8.GetString(Convert.FromBase64String(downloaded_sign_data));

                                    System.IO.File.WriteAllText(Constants.SAVED_FILE_PATH + "GSTN\\RAWDATA\\" + Session["frcid"].ToString() + ".txt", result);

                                    int fileno = i + 1;

                                    var jsonresult = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(result);
                                    Dictionary<string, object> json_jsonresult = JsonConvert.DeserializeObject<Dictionary<string, object>>(Convert.ToString(jsonresult));

                                    for (int cc = 0; cc < json_jsonresult.Count; cc++)
                                    {
                                        if (cc == 0)
                                        {
                                            Dictionary<string, object> json_jsonresult1 = JsonConvert.DeserializeObject<Dictionary<string, object>>(Convert.ToString(json_jsonresult["cpin"])); //eodcin

                                            string kk_Data = string.Empty;

                                            for (int bb = 0; bb < json_jsonresult1.Count; bb++)
                                            {

                                                kk_Data = json_jsonresult1.Keys.ElementAt(bb);


                                                List<Cpin> listobj = JsonConvert.DeserializeObject<List<Cpin>>(Convert.ToString(json_jsonresult1[kk_Data]));
                                                for (int aa = 0; aa < listobj.Count; aa++)
                                                {
                                                    string tabletoinsert = String.Empty;

                                                    if (GstnValidations.isRecordExits("transactions_cpin", "cpin", listobj[aa].cpin))
                                                    {
                                                        tabletoinsert = "duplicate_cpin";
                                                    }
                                                    else
                                                    {
                                                        tabletoinsert = "transactions_cpin";
                                                    }

                                                    StringBuilder insert_qryInner = new StringBuilder("INSERT INTO "+tabletoinsert+ @"( gstin, tmpid, cpin, cpin_dt, cpin_tim, bank_cd, mode, cgst_tax, 
                                                                                            cgst_intr, cgst_fee, cgst_pnlty, cgst_oth, cgst_total, igst_tax, igst_intr, igst_fee, igst_pnlty, igst_oth, igst_total, sgst_tax, 
                                                                                            sgst_intr, sgst_fee, sgst_pnlty, sgst_oth, sgst_total, cess_tax, cess_intr, cess_fee, cess_pnlty, cess_oth, cess_total, tot_amt,frcid) 
                                                                                            VALUES (@gstin, @tmpid, @cpin, @cpin_dt, @cpin_tim, @bank_cd, @mode, @cgst_tax, @cgst_intr, @cgst_fee, @cgst_pnlty, @cgst_oth, @cgst_total, @igst_tax, @igst_intr, @igst_fee, @igst_pnlty, @igst_oth, @igst_total, @sgst_tax, 
                                                                                            @sgst_intr, @sgst_fee, @sgst_pnlty, @sgst_oth, @sgst_total, @cess_tax, @cess_intr, @cess_fee, @cess_pnlty, @cess_oth, @cess_total, @tot_amt,@frcid)");
                                                    NpgsqlCommand insertCmdInner = new NpgsqlCommand(insert_qryInner.ToString());
                                                    insertCmdInner.Parameters.AddWithValue("@gstin", listobj[aa].gstin);
                                                    insertCmdInner.Parameters.AddWithValue("@tmpid", listobj[aa].tmpid);
                                                    insertCmdInner.Parameters.AddWithValue("@cpin", listobj[aa].cpin);
                                                    insertCmdInner.Parameters.AddWithValue("@cpin_dt", listobj[aa].cpin_dt);
                                                    insertCmdInner.Parameters.AddWithValue("@cpin_tim", listobj[aa].cpin_tim);
                                                    insertCmdInner.Parameters.AddWithValue("@bank_cd", listobj[aa].bank_cd);
                                                    insertCmdInner.Parameters.AddWithValue("@mode", kk_Data);
                                                    insertCmdInner.Parameters.AddWithValue("@cgst_tax", listobj[aa].cgst_tax);
                                                    insertCmdInner.Parameters.AddWithValue("@cgst_intr", listobj[aa].cgst_intr);
                                                    insertCmdInner.Parameters.AddWithValue("@cgst_fee", listobj[aa].cgst_fee);
                                                    insertCmdInner.Parameters.AddWithValue("@cgst_pnlty", listobj[aa].cgst_pnlty);
                                                    insertCmdInner.Parameters.AddWithValue("@cgst_oth", listobj[aa].cgst_oth);
                                                    insertCmdInner.Parameters.AddWithValue("@cgst_total", listobj[aa].cgst_total);
                                                    insertCmdInner.Parameters.AddWithValue("@igst_tax", listobj[aa].igst_tax);
                                                    insertCmdInner.Parameters.AddWithValue("@igst_intr", listobj[aa].igst_intr);
                                                    insertCmdInner.Parameters.AddWithValue("@igst_fee", listobj[aa].igst_fee);
                                                    insertCmdInner.Parameters.AddWithValue("@igst_pnlty", listobj[aa].igst_pnlty);
                                                    insertCmdInner.Parameters.AddWithValue("@igst_oth", listobj[aa].igst_oth);
                                                    insertCmdInner.Parameters.AddWithValue("@igst_total", listobj[aa].igst_total);
                                                    insertCmdInner.Parameters.AddWithValue("@sgst_tax", listobj[aa].sgst_tax);
                                                    insertCmdInner.Parameters.AddWithValue("@sgst_intr", listobj[aa].sgst_intr);
                                                    insertCmdInner.Parameters.AddWithValue("@sgst_fee", listobj[aa].sgst_fee);
                                                    insertCmdInner.Parameters.AddWithValue("@sgst_pnlty", listobj[aa].sgst_pnlty);
                                                    insertCmdInner.Parameters.AddWithValue("@sgst_oth", listobj[aa].sgst_oth);
                                                    insertCmdInner.Parameters.AddWithValue("@sgst_total", listobj[aa].sgst_total);
                                                    insertCmdInner.Parameters.AddWithValue("@cess_tax", listobj[aa].cess_tax);
                                                    insertCmdInner.Parameters.AddWithValue("@cess_intr", listobj[aa].cess_intr);
                                                    insertCmdInner.Parameters.AddWithValue("@cess_fee", listobj[aa].cess_fee);
                                                    insertCmdInner.Parameters.AddWithValue("@cess_pnlty", listobj[aa].cess_pnlty);
                                                    insertCmdInner.Parameters.AddWithValue("@cess_oth", listobj[aa].cess_oth);
                                                    insertCmdInner.Parameters.AddWithValue("@cess_total", listobj[aa].cess_total);
                                                    insertCmdInner.Parameters.AddWithValue("@tot_amt", listobj[aa].total_amt);
                                                    insertCmdInner.Parameters.AddWithValue("@frcid", Session["frcid"].ToString());
                
                                                    cmdListInner.Add(insertCmdInner);
                                                }


                                            }
                                        }


                                    }
                                    //}
                                }
                                else
                                {
                                    // Digital signature verification fail
                                }


                            //}

                            if (cmdListInner.Count == Convert.ToInt32(Session["recordcount"].ToString()))
                            {
                                int getRecordInseretedInner = data.SaveData(cmdListInner, "nfs");
                            }
                            else
                            {
                                objgstn.updateDownloadedValidFileStatus(Session["frcid"].ToString(), "N", "File record count not matched");
                            }

                           

                        }

                    }
                }

            }

        }

    }
}