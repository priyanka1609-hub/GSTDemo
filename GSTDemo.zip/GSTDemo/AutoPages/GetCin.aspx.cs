﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using Newtonsoft.Json;

public partial class Auto_GetCin : System.Web.UI.Page
{
    public int count = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }

    protected int Processdata(string date)
    {
        int getRecordInseretedInner = 0;
        try
        {
        
        
         PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder("select * from master_gstn_api");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        DataTable dtApiData = data.GetDataTable(SelectCmd, "nfs");
        List<NpgsqlCommand> cmdListInner = new List<NpgsqlCommand>();
        Session["filetype"] = "CIN";

        if (dtApiData.Rows.Count > 0)
        {
            GSTN objgstn = new GSTN();

            string username = dtApiData.Rows[0]["username"].ToString();
            string pwd = dtApiData.Rows[0]["password"].ToString();
            string clientid = dtApiData.Rows[0]["clientid"].ToString();
            string clientsecret = dtApiData.Rows[0]["clientsecret"].ToString();
            string statecode = dtApiData.Rows[0]["statecode"].ToString();
            string urlauth = dtApiData.Rows[0]["urlauth"].ToString();
            string urlpay = dtApiData.Rows[0]["urlpay"].ToString();

            if (objgstn.apiAuthentication(username, pwd, clientid, clientsecret, statecode, urlauth))
            {

              string fileCountResult = objgstn.getFilesCount(date, "CIN", urlpay, username, clientid, clientsecret, statecode);

                if (!string.IsNullOrEmpty(fileCountResult))
                {
                    Dictionary<string, string> values = JsonConvert.DeserializeObject<Dictionary<string, string>>(fileCountResult);
                    if (Convert.ToInt32(values["num_files"]) > 0)
                    {
                        for (Int32 i = 0; i < Convert.ToInt32(values["num_files"]); i++)
                        {
                            cmdListInner.Clear();
                            string fileDetails = objgstn.GetFileDetail(Convert.ToString(i + 1), "CIN", date, urlpay, clientid, clientsecret, statecode, username);
                            if (string.IsNullOrEmpty(fileDetails))
                            {
                                string fiii=string.Empty;
                            }
                            //int fileno = i + 1;
                            //Dictionary<string, string> fileDownloadedData_sign = JsonConvert.DeserializeObject<Dictionary<string, string>>(fileDetails);
                            //string downloaded_sign_data = fileDownloadedData_sign["data"];

                            //string result = Encoding.UTF8.GetString(Convert.FromBase64String(downloaded_sign_data));

                            var jsonresult = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(fileDetails);
                            Dictionary<string, object> json_jsonresult = JsonConvert.DeserializeObject<Dictionary<string, object>>(Convert.ToString(jsonresult));
                            int sgstcnt = 0;
                           
                            for (int cc = 0; cc < json_jsonresult.Count; cc++)
                            {
                               
                                if (cc == 0)
                                {
                                    Dictionary<string, object> json_jsonresult1 = JsonConvert.DeserializeObject<Dictionary<string, object>>(Convert.ToString(json_jsonresult["cin"])); //eodcin

                                    string kk_Data = string.Empty;

                                    for (int bb = 0; bb < json_jsonresult1.Count; bb++)
                                    {
                                        //if (bb == 0)
                                        //    kk_Data = "ner";
                                        //else if (bb == 1)
                                        //    kk_Data = "otc";
                                        //else if (bb == 2)
                                        //    kk_Data = "epy";

                                        kk_Data = json_jsonresult1.Keys.ElementAt(bb);



                                        List<Responsedata> listobj = JsonConvert.DeserializeObject<List<Responsedata>>(Convert.ToString(json_jsonresult1[kk_Data]));
                                        
                                        string oldcin = string.Empty;
                                        if (listobj.Count > 0)
                                        {

                                            //if (GstnValidations.checkDigitalSignature(Convert.FromBase64String(listobj[0].data), Convert.FromBase64String(listobj[0].sign)))
                                            //{
                                            for (int d = 0; d < listobj.Count; d++)
                                            {

                                                string realdata = Encoding.UTF8.GetString(Convert.FromBase64String(Convert.ToString(listobj[d].data)));
                                                Cin datalist = JsonConvert.DeserializeObject<Cin>(realdata);

                                                string tabletoinsert = String.Empty;

                                                if (oldcin==datalist.cin)
                                                {
                                                    tabletoinsert = "duplicate_cin";
                                                }
                                                else
                                                {
                                                if (GstnValidations.isRecordExits("transactions_cin", "cin", datalist.cin))
                                                {
                                                    tabletoinsert = "duplicate_cin";
                                                }
                                                else
                                                {
                                                    tabletoinsert = "transactions_cin";
                                                }
                                                }



                                           


                                                double sgstamount = Convert.ToDouble(datalist.sgst_amt);
                                                if (sgstamount != 0.00)
                                                {
                                                    sgstcnt++;
                                                StringBuilder insert_qryInner = new StringBuilder("insert into " + tabletoinsert + @"(cin, txnid, utr_num, ack_num, bank_ref_num, status, igst_amt, 
                                                                                                sgst_amt, cgst_amt, total_amt, payment_dt, payment_tim, gstin, 
                                                                                                temp_id, cpin, instrument_ty, bank_cd, br_ifsc_cd, br_location, 
                                                                                                br_name, instrument_no, instrument_micr_cd, submission_dt, submission_tim,frcid)
                                                                                                VALUES (@cin, @txnid, @utr_num, @ack_num, @bank_ref_num, @status, @igst_amt, 
                                                                                                @sgst_amt, @cgst_amt, @total_amt, @payment_dt, @payment_tim, @gstin, 
                                                                                                @temp_id, @cpin, @instrument_ty, @bank_cd, @br_ifsc_cd, @br_location, 
                                                                                                @br_name, @instrument_no, @instrument_micr_cd, @submission_dt, @submission_tim,@frcid)");
                                                NpgsqlCommand insertCmdInner = new NpgsqlCommand(insert_qryInner.ToString());
                                                insertCmdInner.Parameters.AddWithValue("@cin", datalist.cin);
                                                insertCmdInner.Parameters.AddWithValue("@txnid", datalist.txnid);
                                                insertCmdInner.Parameters.AddWithValue("@utr_num", datalist.utr_num);
                                                insertCmdInner.Parameters.AddWithValue("@ack_num", datalist.ack_num);
                                                insertCmdInner.Parameters.AddWithValue("@bank_ref_num", datalist.bank_ref_num);
                                                insertCmdInner.Parameters.AddWithValue("@status", datalist.status);
                                                insertCmdInner.Parameters.AddWithValue("@igst_amt", datalist.igst_amt);
                                                insertCmdInner.Parameters.AddWithValue("@sgst_amt", datalist.sgst_amt);
                                                insertCmdInner.Parameters.AddWithValue("@cgst_amt", datalist.cgst_amt);
                                                insertCmdInner.Parameters.AddWithValue("@total_amt", datalist.total_amt);
                                                insertCmdInner.Parameters.AddWithValue("@payment_dt", datalist.payment_dt);
                                                insertCmdInner.Parameters.AddWithValue("@payment_tim", datalist.payment_tim);
                                                insertCmdInner.Parameters.AddWithValue("@gstin", datalist.gstin);
                                                insertCmdInner.Parameters.AddWithValue("@temp_id", datalist.temp_id);
                                                insertCmdInner.Parameters.AddWithValue("@cpin", datalist.cpin);
                                                insertCmdInner.Parameters.AddWithValue("@instrument_ty", datalist.instrument_ty);
                                                insertCmdInner.Parameters.AddWithValue("@bank_cd", datalist.bank_cd);
                                                insertCmdInner.Parameters.AddWithValue("@br_ifsc_cd", datalist.br_ifsc_cd);
                                                insertCmdInner.Parameters.AddWithValue("@br_location", datalist.br_location);
                                                insertCmdInner.Parameters.AddWithValue("@br_name", datalist.br_name);
                                                insertCmdInner.Parameters.AddWithValue("@instrument_no", datalist.instrument_no);
                                                insertCmdInner.Parameters.AddWithValue("@instrument_micr_cd", datalist.instrument_micr_cd);
                                                insertCmdInner.Parameters.AddWithValue("@submission_dt", datalist.submission_dt);
                                                insertCmdInner.Parameters.AddWithValue("@submission_tim", datalist.submission_tim);
                                                insertCmdInner.Parameters.AddWithValue("@frcid", Session["frcid"].ToString());


                                                cmdListInner.Add(insertCmdInner);
                                                }
                                                oldcin=datalist.cin;
                                            }
                                        }
                                        //}
                                        //else
                                        //{

                                        //}



                                    }
                                }
                            }



                            StringBuilder updatesgst_cnt = new StringBuilder("update  file_record_count_cin set sgstcnt=@sgstcnt, filename=@filename where frcid=@frcid");
                            NpgsqlCommand updatecnt = new NpgsqlCommand(updatesgst_cnt.ToString());
                            updatecnt.Parameters.AddWithValue("@frcid", Session["frcid"].ToString());
                            updatecnt.Parameters.AddWithValue("@sgstcnt", sgstcnt);
                            updatecnt.Parameters.AddWithValue("@filename", Session["filenamewithoutext"].ToString().Trim());
                            cmdListInner.Add(updatecnt);

                            getRecordInseretedInner = data.SaveData(cmdListInner, "nfs");

                        }
                       //  getRecordInseretedInner = data.SaveData(cmdListInner, "nfs");
                     
                    }
                }

            }

        }

        return getRecordInseretedInner;
        }
        catch(Exception ex)
        {
            ExceptionLogging.logException(ex);
            return getRecordInseretedInner;
        }


    }
    protected void btn_getData_Click(object sender, EventArgs e)
    {
        Processdata(ddldate.SelectedValue);

    }
    protected void btn_ButtonBulk_Click(object sender, EventArgs e)
    {
        ddldate.SelectedValue = "";
        var dates = new List<string>();

        DateTime start = new DateTime(2018, 01, 01);

        DateTime end = new DateTime(2018, 01,31 );


        for (var dt = start; dt <= end; dt = dt.AddDays(1))
        {

            dates.Add(dt.ToString("dd-MM-yyyy"));
        }

        for (int i = 0; i < dates.Count; i++)
        {
           int result= Processdata(dates[i]);
           if (result > 0)
           {
               count++;
           }
        }
        lbltext.Text = count.ToString();


    }
}