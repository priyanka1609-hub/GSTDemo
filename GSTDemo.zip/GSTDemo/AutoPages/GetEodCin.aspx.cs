﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using Npgsql;
using System.Data;
using GstDelhi.PostgresData;
using Newtonsoft.Json;
using System.Globalization;

public partial class Auto_GetEodCin : System.Web.UI.Page
{
    public int insertstartdate;
    GSTN objgstn = new GSTN();
    PostgresGetData data = new PostgresGetData();
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["filetype"] = "EODCIN";
        {
            //getData(DateTime.Now.ToString("dd-MM-yyyy").ToString());

            if (Request.QueryString["date"] != null)
            {
                //getData(Request.QueryString["date"].ToString());
                //msg.Show(Request.QueryString["date"].ToString());
                insertstartdate = Utility.updatestarttime("GSTN", "EODCIN");
                

            }


        }

    }
    protected void btn_getData_Click(object sender, EventArgs e)
    {
        getData(txtfromdate.Text);
    }
    protected void getData(string dateSelected)
    {


        StringBuilder SelectQuery = new StringBuilder("select * from master_gstn_api");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        DataTable dtApiData = data.GetDataTable(SelectCmd, "nfs");


        if (dtApiData.Rows.Count > 0)
        {


            string username = dtApiData.Rows[0]["username"].ToString();
            string pwd = dtApiData.Rows[0]["password"].ToString();
            string clientid = dtApiData.Rows[0]["clientid"].ToString();
            string clientsecret = dtApiData.Rows[0]["clientsecret"].ToString();
            string statecode = dtApiData.Rows[0]["statecode"].ToString();
            string urlauth = dtApiData.Rows[0]["urlauth"].ToString();
            string urlpay = dtApiData.Rows[0]["urlpay"].ToString();

            if (objgstn.apiAuthentication(username, pwd, clientid, clientsecret, statecode, urlauth))
            {
                SelectQuery = new StringBuilder("select fcountid from files_count where to_char(filedate,'DD-MM-YYYY')=@date and status='1' and fcountid in (select filecntid from file_record_count )");
                NpgsqlCommand selectcmd1 = new NpgsqlCommand(SelectQuery.ToString());
                selectcmd1.Parameters.AddWithValue("@date", dateSelected);
                DataTable dtfilecntid = data.GetDataTable(selectcmd1, "nfs");

                string fileCountResult = string.Empty;

                if (dtfilecntid.Rows.Count > 0)
                {
                    HttpContext.Current.Session.Add("filecntid", dtfilecntid.Rows[0]["fcountid"].ToString());

                    if (!string.IsNullOrEmpty(txtfilenumber.Text))
                    {
                        getFile(txtfilenumber.Text, dateSelected, urlpay, clientid, clientsecret, statecode, username);
                    }

                }
                else
                {
                    fileCountResult = objgstn.getFilesCount(dateSelected, "EODCIN", urlpay, username, clientid, clientsecret, statecode);

                    if (!string.IsNullOrEmpty(fileCountResult))
                    {
                        GstnFileCount values = JsonConvert.DeserializeObject<GstnFileCount>(fileCountResult);
                        if (Convert.ToInt32(values.num_files) > 0)
                        {

                            for (Int32 i = 0; i < Convert.ToInt32(values.num_files); i++)
                            {
                                getFile(Convert.ToString(i + 1), dateSelected, urlpay, clientid, clientsecret, statecode, username);
                            }

                        }

                    }

                }



            }
        }
        ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "", "closeBrowser()", true);
    }



    protected void getFile(string fileno, string dateSelected, string urlpay, string clientid, string clientsecret, string statecode, string username)
    {
        List<NpgsqlCommand> cmdListInner = new List<NpgsqlCommand>();

        string fileDetails = objgstn.GetFileDetail(fileno, "EODCIN", dateSelected, urlpay, clientid, clientsecret, statecode, username);
        if (!string.IsNullOrEmpty(fileDetails))
        {
            Dictionary<string, string> fileDownloadedData_sign = JsonConvert.DeserializeObject<Dictionary<string, string>>(fileDetails);
            string downloaded_sign_data = fileDownloadedData_sign["data"];
            string downloaded_signature = fileDownloadedData_sign["sign"];


            if (GstnValidations.VerifySignature(downloaded_sign_data, downloaded_signature))
            {

                string result = Encoding.UTF8.GetString(Convert.FromBase64String(downloaded_sign_data));

                //System.IO.File.WriteAllText(Constants.SAVED_FILE_PATH + "GSTN\\RAWDATA\\" + Session["frcid"].ToString() + ".txt", result);
                System.IO.File.WriteAllText(Constants.SAVED_FILE_PATH + "GSTN\\RAWDATA\\" + Session["filenamewithoutext"].ToString() + ".txt", result);

                var jsonresult = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(result);

                Dictionary<string, object> json_jsonresult = JsonConvert.DeserializeObject<Dictionary<string, object>>(Convert.ToString(jsonresult));

                int totalsgsttxns = 0;

                for (int cc = 0; cc < json_jsonresult.Count; cc++)
                {
                    if (cc == 0)
                    {
                        Dictionary<string, object> json_jsonresult1 = JsonConvert.DeserializeObject<Dictionary<string, object>>(Convert.ToString(json_jsonresult["cin"])); //eodcin

                        string kk_Data = string.Empty;

                        for (int bb = 0; bb < json_jsonresult1.Count; bb++)
                        {

                            kk_Data = json_jsonresult1.Keys.ElementAt(bb);

                            List<Eodcin> listobj = JsonConvert.DeserializeObject<List<Eodcin>>(Convert.ToString(json_jsonresult1[kk_Data]));
                            listobj.Sort((x, y) => x.cin.CompareTo(y.cin));
                            for (int aa = 0; aa < listobj.Count; aa++)
                            {
                                string tabletoinsert = String.Empty;

                                if (aa == 0)
                                {
                                    if (GstnValidations.isRecordExits("transactions_eod_cin", "cin", listobj[aa].cin))
                                    {
                                        tabletoinsert = "duplicate_eod_cin";
                                    }
                                    else
                                    {
                                        tabletoinsert = "transactions_eod_cin";
                                    }
                                }
                                else
                                {
                                    if (listobj[aa - 1].cin == listobj[aa].cin)
                                    {
                                        tabletoinsert = "duplicate_eod_cin";
                                    }
                                    else
                                    {
                                        if (GstnValidations.isRecordExits("transactions_eod_cin", "cin", listobj[aa].cin))
                                        {
                                            tabletoinsert = "duplicate_eod_cin";
                                        }
                                        else
                                        {
                                            tabletoinsert = "transactions_eod_cin";
                                        }
                                    }
                                }



                                double totalofminorheads = Convert.ToDouble(listobj[aa].sgst_tax) + Convert.ToDouble(listobj[aa].sgst_intr) + Convert.ToDouble(listobj[aa].sgst_fee) + Convert.ToDouble(listobj[aa].sgst_pnlty) + Convert.ToDouble(listobj[aa].sgst_oth);
                                double sgsttotal = Convert.ToDouble(listobj[aa].sgst_total);

                                if (sgsttotal != 0.00 && totalofminorheads != 0.00)
                                {
                                    totalsgsttxns++;
                                    bool isToReject = false;
                                    if (totalofminorheads != sgsttotal)
                                    {
                                        tabletoinsert = "reject_transactions_eod_cin";
                                        isToReject = true;
                                    }


                                    StringBuilder insert_qryInner = new StringBuilder("INSERT INTO " + tabletoinsert + @"(gstin, temp_id, cpin, mode,sgst_tax, 
                                                                                                sgst_intr, sgst_fee, sgst_pnlty, sgst_oth, sgst_total,cin, txnid, 
                                                                                                utr_num, ack_num, bank_ref_num, status, total_amt,
                                                                                                instrument_ty, bank_cd, br_ifsc_cd, br_location, 
                                                                                                br_name, instrument_no, instrument_micr_cd, 
                                                                                                frcid,paymentdatetime,cpindatetime,pymntackdatetime,reportingdatetime ");

                                    if (isToReject)
                                    {
                                        insert_qryInner.Append(" ,rejectcode ");
                                    }
                                    insert_qryInner.Append(" )");
                                    insert_qryInner.Append(@" VALUES (@gstin, @temp_id, @cpin, @mode, @sgst_tax, 
                                                                                                @sgst_intr, @sgst_fee, @sgst_pnlty, @sgst_oth, @sgst_total,@cin, @txnid, 
                                                                                                @utr_num, @ack_num, @bank_ref_num, @status, @total_amt,
                                                                                                @instrument_ty, @bank_cd, @br_ifsc_cd, @br_location, 
                                                                                                @br_name, @instrument_no, @instrument_micr_cd,
                                                                                                @frcid,@paymentdatetime,@cpindatetime,@pymntackdatetime,@reportingdatetime");
                                    if (isToReject)
                                    {
                                        insert_qryInner.Append(" ,@rejectcode ");
                                    }
                                    insert_qryInner.Append(" )");

                                    NpgsqlCommand insertCmdInner = new NpgsqlCommand(insert_qryInner.ToString());
                                    insertCmdInner.Parameters.AddWithValue("@gstin", listobj[aa].gstin);
                                    insertCmdInner.Parameters.AddWithValue("@temp_id", listobj[aa].temp_id);
                                    insertCmdInner.Parameters.AddWithValue("@cpin", listobj[aa].cpin);
                                    insertCmdInner.Parameters.AddWithValue("@mode", kk_Data);
                                    insertCmdInner.Parameters.AddWithValue("@sgst_tax", listobj[aa].sgst_tax);
                                    insertCmdInner.Parameters.AddWithValue("@sgst_intr", listobj[aa].sgst_intr);
                                    insertCmdInner.Parameters.AddWithValue("@sgst_fee", listobj[aa].sgst_fee);
                                    insertCmdInner.Parameters.AddWithValue("@sgst_pnlty", listobj[aa].sgst_pnlty);
                                    insertCmdInner.Parameters.AddWithValue("@sgst_oth", listobj[aa].sgst_oth);
                                    insertCmdInner.Parameters.AddWithValue("@sgst_total", listobj[aa].sgst_total);
                                    insertCmdInner.Parameters.AddWithValue("@cin", listobj[aa].cin);
                                    insertCmdInner.Parameters.AddWithValue("@txnid", listobj[aa].txnid);
                                    insertCmdInner.Parameters.AddWithValue("@utr_num", listobj[aa].utr_num);
                                    insertCmdInner.Parameters.AddWithValue("@ack_num", listobj[aa].ack_num);
                                    insertCmdInner.Parameters.AddWithValue("@bank_ref_num", listobj[aa].bank_ref_num);
                                    insertCmdInner.Parameters.AddWithValue("@status", listobj[aa].status);
                                    insertCmdInner.Parameters.AddWithValue("@total_amt", listobj[aa].total_amt);
                                    insertCmdInner.Parameters.AddWithValue("@instrument_ty", listobj[aa].instrument_ty);
                                    insertCmdInner.Parameters.AddWithValue("@bank_cd", listobj[aa].bank_cd);
                                    insertCmdInner.Parameters.AddWithValue("@br_ifsc_cd", listobj[aa].br_ifsc_cd);
                                    insertCmdInner.Parameters.AddWithValue("@br_location", listobj[aa].br_location);
                                    insertCmdInner.Parameters.AddWithValue("@br_name", listobj[aa].br_name);
                                    insertCmdInner.Parameters.AddWithValue("@instrument_no", listobj[aa].instrument_no);
                                    insertCmdInner.Parameters.AddWithValue("@instrument_micr_cd", listobj[aa].instrument_micr_cd);
                                    insertCmdInner.Parameters.AddWithValue("@frcid", Session["frcid"].ToString());
                                    insertCmdInner.Parameters.AddWithValue("@paymentdatetime", Utility.converttodatetime_from_DDMMYY_HHMMSS(listobj[aa].payment_dt + listobj[aa].payment_tim));
                                    insertCmdInner.Parameters.AddWithValue("@cpindatetime", Utility.converttodatetime_from_DDMMYY_HHMMSS(listobj[aa].cpin_dt + listobj[aa].cpin_tim));
                                    if (listobj[aa].pymnt_ack_dt == null || (string.IsNullOrEmpty(listobj[aa].pymnt_ack_dt.ToString()) && string.IsNullOrEmpty(listobj[aa].pymnt_ack_tim.ToString())))
                                    {
                                        insertCmdInner.Parameters.AddWithValue("@pymntackdatetime", DBNull.Value);
                                    }
                                    else
                                    {
                                        insertCmdInner.Parameters.AddWithValue("@pymntackdatetime", Utility.converttodatetime_from_DDMMYY_HHMMSS(listobj[aa].pymnt_ack_dt + listobj[aa].pymnt_ack_tim));
                                    }
                                    insertCmdInner.Parameters.AddWithValue("@reportingdatetime", Utility.converttodatetime_from_DDMMYY_HHMMSS(listobj[aa].reporting_dt + listobj[aa].reporting_tim));
                                    insertCmdInner.Parameters.AddWithValue("@rejectcode", "1");


                                    cmdListInner.Add(insertCmdInner);



                                }
                                else
                                {
                                    StringBuilder insert_qryInner = new StringBuilder(@"INSERT INTO other_taxes_transactions_eod_cin (gstin, temp_id, cpin, mode, cgst_tax, 
                                                                                                cgst_intr, cgst_fee, cgst_pnlty, cgst_oth, cgst_total, igst_tax, 
                                                                                                igst_intr, igst_fee, igst_pnlty, igst_oth, igst_total, sgst_tax, 
                                                                                                sgst_intr, sgst_fee, sgst_pnlty, sgst_oth, sgst_total, cess_tax, 
                                                                                                cess_intr, cess_fee, cess_pnlty, cess_oth, cess_total, cin, txnid, 
                                                                                                utr_num, ack_num, bank_ref_num, status, total_amt,
                                                                                                instrument_ty, bank_cd, br_ifsc_cd, br_location, 
                                                                                                br_name, instrument_no, instrument_micr_cd, 
                                                                                                frcid,paymentdatetime,cpindatetime,pymntackdatetime,reportingdatetime) VALUES
                                                                                                (@gstin, @temp_id, @cpin, @mode, @cgst_tax, 
                                                                                                @cgst_intr, @cgst_fee, @cgst_pnlty, @cgst_oth, @cgst_total, @igst_tax, 
                                                                                                @igst_intr, @igst_fee, @igst_pnlty, @igst_oth, @igst_total, @sgst_tax, 
                                                                                                @sgst_intr, @sgst_fee, @sgst_pnlty, @sgst_oth, @sgst_total, @cess_tax, 
                                                                                                @cess_intr, @cess_fee, @cess_pnlty, @cess_oth, @cess_total, @cin, @txnid, 
                                                                                                @utr_num, @ack_num, @bank_ref_num, @status, @total_amt,
                                                                                                @instrument_ty, @bank_cd, @br_ifsc_cd, @br_location, 
                                                                                                @br_name, @instrument_no, @instrument_micr_cd,
                                                                                                @frcid,@paymentdatetime,@cpindatetime,@pymntackdatetime,@reportingdatetime)");

                                    NpgsqlCommand insertCmdInner = new NpgsqlCommand(insert_qryInner.ToString());
                                    insertCmdInner.Parameters.AddWithValue("@gstin", listobj[aa].gstin);
                                    insertCmdInner.Parameters.AddWithValue("@temp_id", listobj[aa].temp_id);
                                    insertCmdInner.Parameters.AddWithValue("@cpin", listobj[aa].cpin);
                                    insertCmdInner.Parameters.AddWithValue("@mode", kk_Data);
                                    insertCmdInner.Parameters.AddWithValue("@cgst_tax", listobj[aa].cgst_tax);
                                    insertCmdInner.Parameters.AddWithValue("@cgst_intr", listobj[aa].cgst_intr);
                                    insertCmdInner.Parameters.AddWithValue("@cgst_fee", listobj[aa].cgst_fee);
                                    insertCmdInner.Parameters.AddWithValue("@cgst_pnlty", listobj[aa].cgst_pnlty);
                                    insertCmdInner.Parameters.AddWithValue("@cgst_oth", listobj[aa].cgst_oth);
                                    insertCmdInner.Parameters.AddWithValue("@cgst_total", listobj[aa].cgst_total);
                                    insertCmdInner.Parameters.AddWithValue("@igst_tax", listobj[aa].igst_tax);
                                    insertCmdInner.Parameters.AddWithValue("@igst_intr", listobj[aa].igst_intr);
                                    insertCmdInner.Parameters.AddWithValue("@igst_fee", listobj[aa].igst_fee);
                                    insertCmdInner.Parameters.AddWithValue("@igst_pnlty", listobj[aa].igst_pnlty);
                                    insertCmdInner.Parameters.AddWithValue("@igst_oth", listobj[aa].igst_oth);
                                    insertCmdInner.Parameters.AddWithValue("@igst_total", listobj[aa].igst_total);
                                    insertCmdInner.Parameters.AddWithValue("@sgst_tax", listobj[aa].sgst_tax);
                                    insertCmdInner.Parameters.AddWithValue("@sgst_intr", listobj[aa].sgst_intr);
                                    insertCmdInner.Parameters.AddWithValue("@sgst_fee", listobj[aa].sgst_fee);
                                    insertCmdInner.Parameters.AddWithValue("@sgst_pnlty", listobj[aa].sgst_pnlty);
                                    insertCmdInner.Parameters.AddWithValue("@sgst_oth", listobj[aa].sgst_oth);
                                    insertCmdInner.Parameters.AddWithValue("@sgst_total", listobj[aa].sgst_total);
                                    insertCmdInner.Parameters.AddWithValue("@cess_tax", listobj[aa].cess_tax);
                                    insertCmdInner.Parameters.AddWithValue("@cess_intr", listobj[aa].cess_intr);
                                    insertCmdInner.Parameters.AddWithValue("@cess_fee", listobj[aa].cess_fee);
                                    insertCmdInner.Parameters.AddWithValue("@cess_pnlty", listobj[aa].cess_pnlty);
                                    insertCmdInner.Parameters.AddWithValue("@cess_oth", listobj[aa].cess_oth);
                                    insertCmdInner.Parameters.AddWithValue("@cess_total", listobj[aa].cess_total);
                                    insertCmdInner.Parameters.AddWithValue("@cin", listobj[aa].cin);
                                    insertCmdInner.Parameters.AddWithValue("@txnid", listobj[aa].txnid);
                                    insertCmdInner.Parameters.AddWithValue("@utr_num", listobj[aa].utr_num);
                                    insertCmdInner.Parameters.AddWithValue("@ack_num", listobj[aa].ack_num);
                                    insertCmdInner.Parameters.AddWithValue("@bank_ref_num", listobj[aa].bank_ref_num);
                                    insertCmdInner.Parameters.AddWithValue("@status", listobj[aa].status);
                                    insertCmdInner.Parameters.AddWithValue("@total_amt", listobj[aa].total_amt);
                                    insertCmdInner.Parameters.AddWithValue("@instrument_ty", listobj[aa].instrument_ty);
                                    insertCmdInner.Parameters.AddWithValue("@bank_cd", listobj[aa].bank_cd);
                                    insertCmdInner.Parameters.AddWithValue("@br_ifsc_cd", listobj[aa].br_ifsc_cd);
                                    insertCmdInner.Parameters.AddWithValue("@br_location", listobj[aa].br_location);
                                    insertCmdInner.Parameters.AddWithValue("@br_name", listobj[aa].br_name);
                                    insertCmdInner.Parameters.AddWithValue("@instrument_no", listobj[aa].instrument_no);
                                    insertCmdInner.Parameters.AddWithValue("@instrument_micr_cd", listobj[aa].instrument_micr_cd);
                                    insertCmdInner.Parameters.AddWithValue("@frcid", Session["frcid"].ToString());
                                    insertCmdInner.Parameters.AddWithValue("@paymentdatetime", Utility.converttodatetime_from_DDMMYY_HHMMSS(listobj[aa].payment_dt + listobj[aa].payment_tim));
                                    insertCmdInner.Parameters.AddWithValue("@cpindatetime", Utility.converttodatetime_from_DDMMYY_HHMMSS(listobj[aa].cpin_dt + listobj[aa].cpin_tim));
                                    if (listobj[aa].pymnt_ack_tim == null || (string.IsNullOrEmpty(listobj[aa].pymnt_ack_dt.ToString()) && string.IsNullOrEmpty(listobj[aa].pymnt_ack_tim.ToString())))
                                    {
                                        insertCmdInner.Parameters.AddWithValue("@pymntackdatetime", DBNull.Value);
                                    }
                                    else
                                    {
                                        insertCmdInner.Parameters.AddWithValue("@pymntackdatetime", Utility.converttodatetime_from_DDMMYY_HHMMSS(listobj[aa].pymnt_ack_dt + listobj[aa].pymnt_ack_tim));
                                    }
                                    insertCmdInner.Parameters.AddWithValue("@reportingdatetime", Utility.converttodatetime_from_DDMMYY_HHMMSS(listobj[aa].reporting_dt + listobj[aa].reporting_tim));
                                    cmdListInner.Add(insertCmdInner);

                                }


                            }
                        }
                    }
                }
                StringBuilder updatesgst_cnt = new StringBuilder("update  file_record_count set sgstcnt=@sgstcnt, filename=@filename where frcid=@frcid");
                NpgsqlCommand updatecnt = new NpgsqlCommand(updatesgst_cnt.ToString());
                updatecnt.Parameters.AddWithValue("@frcid", Session["frcid"].ToString());
                updatecnt.Parameters.AddWithValue("@sgstcnt", totalsgsttxns);
                updatecnt.Parameters.AddWithValue("@filename", Session["filenamewithoutext"].ToString().Trim());
                cmdListInner.Add(updatecnt);


                int getRecordInseretedInner = data.SaveData(cmdListInner, "nfs");
                if (getRecordInseretedInner > 0)
                {
                    if (Request.QueryString["date"] != null)
                    {
                        int insertenddatetime = Utility.updateEndtime(insertstartdate);
                    }
                }

            }
            else
            {
                objgstn.updateDownloadedValidFileStatus(Session["frcid"].ToString(), "N", "Digital Signature Validation Failed");
            }


        }
    }
}