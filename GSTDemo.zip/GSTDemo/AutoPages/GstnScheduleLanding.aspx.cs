﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;

public partial class AutoPages_GstnScheduleLanding : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString["filetype"] != null)
        {
            
            string date = DateTime.Now.ToString("dd-MM-yyyy", CultureInfo.InvariantCulture);

            string filetype = Request.QueryString["filetype"].ToString();

            if (filetype == "EODCIN")
            {
                Response.Redirect("../AutoPages/GetEodCin.aspx?date=" + date);
            }
            else if (filetype == "EXCP")
            {
                Response.Redirect("../AutoPages/GetExcp.aspx?date=" + date);
            }
            else if (filetype == "RECON")
            {
                Response.Redirect("../AutoPages/GetRecon.aspx?date=" + date);
            }
            else if (filetype == "NRECON")
            {
                Response.Redirect("../AutoPages/GetNRecon.aspx?date=" + date);
            }
            else if (filetype == "EODCPIN")
            {
                Response.Redirect("../AutoPages/GetNRecon.aspx?date=" + date);
            }
        }
    }
}