﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using Npgsql;
using System.Data;
using GstDelhi.PostgresData;
using Newtonsoft.Json;
using System.Globalization;

public partial class AutoPages_GetRecon : System.Web.UI.Page
{
    public int totalsgsttxns = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["filetype"] = "RECON";
        if (!IsPostBack)
        {
            //getData(DateTime.Now.ToString("dd-MM-yyyy").ToString());
        }

    }
    protected void btn_getData_Click(object sender, EventArgs e)
    {
        getData(ddldate.SelectedValue);
    }
    protected void getData(string dateSelected)
    {
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder("select * from master_gstn_api");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        DataTable dtApiData = data.GetDataTable(SelectCmd, "nfs");


        if (dtApiData.Rows.Count > 0)
        {
            GSTN objgstn = new GSTN();

            string username = dtApiData.Rows[0]["username"].ToString();
            string pwd = dtApiData.Rows[0]["password"].ToString();
            string clientid = dtApiData.Rows[0]["clientid"].ToString();
            string clientsecret = dtApiData.Rows[0]["clientsecret"].ToString();
            string statecode = dtApiData.Rows[0]["statecode"].ToString();
            string urlauth = dtApiData.Rows[0]["urlauth"].ToString();
            string urlpay = dtApiData.Rows[0]["urlpay"].ToString();

            if (objgstn.apiAuthentication(username, pwd, clientid, clientsecret, statecode, urlauth))
            {

                string fileCountResult = objgstn.getFilesCount(dateSelected, "RECON", urlpay, username, clientid, clientsecret, statecode);

                if (!string.IsNullOrEmpty(fileCountResult))
                {
                    GstnFileCount values = JsonConvert.DeserializeObject<GstnFileCount>(fileCountResult);
                    if (Convert.ToInt32(values.num_files) > 0)
                    {
                        for (Int32 i = 0; i < Convert.ToInt32(values.num_files); i++)
                        {
                            List<NpgsqlCommand> cmdListInner = new List<NpgsqlCommand>();

                            string fileDetails = objgstn.GetFileDetail(Convert.ToString(i + 1), "RECON", dateSelected, urlpay, clientid, clientsecret, statecode, username);
                            if (!string.IsNullOrEmpty(fileDetails))
                            {
                                Dictionary<string, string> fileDownloadedData_sign = JsonConvert.DeserializeObject<Dictionary<string, string>>(fileDetails);
                                string downloaded_sign_data = fileDownloadedData_sign["data"];
                                string downloaded_signature = fileDownloadedData_sign["sign"];


                                if (GstnValidations.VerifySignature(downloaded_sign_data, downloaded_signature))
                                {
                                    string result = Encoding.UTF8.GetString(Convert.FromBase64String(downloaded_sign_data));

                                    //System.IO.File.WriteAllText(Constants.SAVED_FILE_PATH + "GSTN\\RAWDATA\\" + Session["frcid"].ToString() + ".txt", result);
                                    System.IO.File.WriteAllText(Constants.SAVED_FILE_PATH + "GSTN\\RAWDATA\\" + Session["filenamewithoutext"].ToString() + ".txt", result);

                                    var jsonresult = Newtonsoft.Json.JsonConvert.DeserializeObject<dynamic>(result);

                                    Dictionary<string, object> json_jsonresult = JsonConvert.DeserializeObject<Dictionary<string, object>>(Convert.ToString(jsonresult));

                                     

                                    for (int cc = 0; cc < json_jsonresult.Count; cc++)
                                    {
                                        if (cc == 0)
                                        {
                                            Dictionary<string, object> json_jsonresult1 = JsonConvert.DeserializeObject<Dictionary<string, object>>(Convert.ToString(json_jsonresult["reconciliation"])); //eodcin

                                            string kk_Data = string.Empty;

                                            for (int bb = 0; bb < json_jsonresult1.Count; bb++)
                                            {

                                                kk_Data = json_jsonresult1.Keys.ElementAt(bb);

                                                List<RECON> listobj = JsonConvert.DeserializeObject<List<RECON>>(Convert.ToString(json_jsonresult1[kk_Data]));
                                                for (int aa = 0; aa < listobj.Count; aa++)
                                                {

                                                    totalsgsttxns++;
                                                   

                                                    StringBuilder insert_qryInner = new StringBuilder(@"INSERT INTO transactions_recon (recondt, othrecondt, escrollno, cin,mode,cpin, 
                                                                                                gstin,insertdatetime,frcid) VALUES
                                                                                                (@recondt, @othrecondt, @escrollno, @cin,@mode, @cpin, 
                                                                                                @gstin,now(),@frcid)");
                                                    NpgsqlCommand insertCmdInner = new NpgsqlCommand(insert_qryInner.ToString());
                                                    insertCmdInner.Parameters.AddWithValue("@recondt", Utility.converttodate_from_DDMMYYYY(json_jsonresult["ner_recon_dt"].ToString()));
                                                    insertCmdInner.Parameters.AddWithValue("@othrecondt", Utility.converttodate_from_DDMMYYYY(json_jsonresult["othr_recon_dt"].ToString()));
                                                    insertCmdInner.Parameters.AddWithValue("@escrollno", listobj[aa].e_scroll_num);
                                                    insertCmdInner.Parameters.AddWithValue("@cin", listobj[aa].cin);
                                                    insertCmdInner.Parameters.AddWithValue("@mode", kk_Data.ToString());
                                                    insertCmdInner.Parameters.AddWithValue("@cpin", listobj[aa].cpin);
                                                    insertCmdInner.Parameters.AddWithValue("@gstin", listobj[aa].gstin);
                                                    insertCmdInner.Parameters.AddWithValue("@frcid", Session["frcid"].ToString());





                                                    cmdListInner.Add(insertCmdInner);
                                                }
                                            }


                                        }
                                    }

                                }

                                StringBuilder updatesgst_cnt = new StringBuilder(@"update file_record_count set filename=@filename,sgstcnt=@sgstcnt where frcid=@frcid");
                                NpgsqlCommand updatecnt = new NpgsqlCommand(updatesgst_cnt.ToString());
                                updatecnt.Parameters.AddWithValue("@frcid", Session["frcid"].ToString());
                                updatecnt.Parameters.AddWithValue("@sgstcnt", totalsgsttxns);
                               
                                updatecnt.Parameters.AddWithValue("@filename", Session["filenamewithoutext"].ToString().Trim());

                                cmdListInner.Add(updatecnt);

                                int getRecordInseretedInner = data.SaveData(cmdListInner, "nfs");

                            }
                            else
                            {
                                objgstn.updateDownloadedValidFileStatus(Session["frcid"].ToString(), "N", "Digital Signature Validation Failed");
                            }

                            //if (cmdListInner.Count == Convert.ToInt32(Session["recordcount"].ToString()))
                            //{
                            //   // int getRecordInseretedInner = data.SaveData(cmdListInner, "nfs");
                            //}
                            //else
                            //{
                            //    objgstn.updateDownloadedValidFileStatus(Session["frcid"].ToString(), "N", "File record count not matched");
                            //}

                            //int getRecordInseretedInner = data.SaveData(cmdListInner, "nfs");

                        }
                    }

                }

            }

        }
    }
}