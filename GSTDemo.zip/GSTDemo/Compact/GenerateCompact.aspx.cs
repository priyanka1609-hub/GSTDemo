﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Threading;
using System.Globalization;

public partial class Compact_GenerateCompact : System.Web.UI.Page
{
    MD5Util md5util = new MD5Util();
    PostgresGetData data = new PostgresGetData();
    message msg = new message();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
        {

            if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
            StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
            {
                Response.Redirect("Logout.aspx");
            }
        }

        // showData();

        if (Request.QueryString["dt"] != null)
        {
            tbldate.Visible = true;
            lblpymtdate.Text = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true);

            filltiles(lblpymtdate.Text);
        }
        else
        {
            tblselectdate.Visible = true;
        }
        

        
    }


    protected void btnGenerate_Click(object sender, EventArgs e)
    {
        try
        {

            StringBuilder SelectQuery = new StringBuilder(@"select to_char(fc.filedate,'DD/MM/YYYY') filedate,tec.cin,rbi.amt,tec.cpin,sgst_tax,sgst_intr,sgst_pnlty,sgst_oth,sgst_fee  from files_count fc 
                                                                inner join file_record_count frc on frc.filecntid=fc.fcountid
                                                                inner join transactions_eod_cin tec on tec.frcid=frc.frcid
                                                                inner join rbi_response_txns_details rbi on rbi.cin=tec.cin
                                                                where totaltxnamt=sgst_total and to_char(rbi.paymentdatetime,'DD/MM/YYYY')=@paymentdate");
            NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
            SelectCmd.Parameters.AddWithValue("@paymentdate", lblpymtdate.Text);
            DataTable dt = data.GetDataTable(SelectCmd, "nfs");

            if (dt.Rows.Count > 0)
            {
                string ipaddrs = PostgresGetData.GetIP4Address();

                SelectQuery = new StringBuilder(@"select lpad((count(cfileid)+1)::text, 2, '0') seq from compact_files where to_char(insertdatetime,'DD/MM/YYYY')=@date");
                SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
                SelectCmd.Parameters.AddWithValue("@date", DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture));
                DataTable dtcount = data.GetDataTable(SelectCmd, "nfs");
                string filename = DateTime.Now.ToString("ddMMyyyy", CultureInfo.InvariantCulture) + dtcount.Rows[0]["seq"].ToString() + ".txt";

                string insrtQ = @"INSERT INTO compact_files(filename,insertdatetime, userid, ip)
                                    VALUES (@filename,now(),@userid,@ip); select lastval();";

                NpgsqlCommand cmdinsrtQ = new NpgsqlCommand(insrtQ);
                cmdinsrtQ.Parameters.AddWithValue("@filename", filename);
                cmdinsrtQ.Parameters.AddWithValue("@userid", Session["USER_ID"].ToString());
                cmdinsrtQ.Parameters.AddWithValue("@ip", ipaddrs);

                int insertedRec = data.UpdateScalarData(cmdinsrtQ, "nfs");

                if (insertedRec > 0)
                {

                    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                    string Qry = @"INSERT INTO public.moe_compact(cin, status, userid, ipaddress, insertdatetime,compactfileid)
                                    VALUES (@cin, @status, @userid, @ipaddress, now(), @compactfileid);";

                    string path = Utility.getFileToSavePath("PAO", "", "", DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture));
                    if (!string.IsNullOrEmpty(path))
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                            cmd.Parameters.AddWithValue("@cin", dt.Rows[i]["cin"].ToString());
                            cmd.Parameters.AddWithValue("@status", "C");
                            //cmd.Parameters.AddWithValue("@filedate", Utility.converttodate_from_DDMMYYYY(dt.Rows[i]["filedate"].ToString()));
                            cmd.Parameters.AddWithValue("@userid", Session["USER_ID"].ToString());
                            cmd.Parameters.AddWithValue("@ipaddress", ipaddrs);
                            cmd.Parameters.AddWithValue("@compactfileid", insertedRec);
                            cmdList.Add(cmd);

                            StringBuilder updateqry = new StringBuilder(@"update transactions_eod_cin set isprocessed=@isprocessed where cin=@cin ;");
                            NpgsqlCommand Up1cmd = new NpgsqlCommand(updateqry.ToString());
                            Up1cmd.Parameters.AddWithValue("@isprocessed", "Y");
                            Up1cmd.Parameters.AddWithValue("@cin", dt.Rows[i]["cin"].ToString());
                            cmdList.Add(Up1cmd);

                            updateqry = new StringBuilder(@"update rbi_response_txns_details set isprocessed=@isprocessed where cin=@cin ;");
                            Up1cmd = new NpgsqlCommand(updateqry.ToString());
                            Up1cmd.Parameters.AddWithValue("@isprocessed", "Y");
                            Up1cmd.Parameters.AddWithValue("@cin", dt.Rows[i]["cin"].ToString());
                            cmdList.Add(Up1cmd);

                        }
                       
                    }

                    int savedrec = data.SaveData(cmdList, "nfs");

                    if (savedrec > 0)
                    {
                        SelectQuery = new StringBuilder(@"select sum(sgst_total),sum(sgst_tax) tax,sum(sgst_intr) intr,sum(sgst_pnlty) pnlty,sum(sgst_oth) oth,sum(sgst_fee) fee from transactions_eod_cin tec
                                                          inner join moe_compact mc on mc.cin = tec.cin  where to_char(paymentdatetime,'DD/MM/YYYY')=@date and mc.status='C'");
                        SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
                        SelectCmd.Parameters.AddWithValue("@date", lblpymtdate.Text);
                        DataTable dtminorheads = data.GetDataTable(SelectCmd, "nfs");

                        using (System.IO.StreamWriter file = new System.IO.StreamWriter(path + filename))
                        {
                            file.WriteLine("SGST-Tax 0006-00-101 " + dtminorheads.Rows[0]["tax"].ToString());
                            file.WriteLine("SGST-Interest 0006-00-102 " + dtminorheads.Rows[0]["intr"].ToString());
                            file.WriteLine("SGST-Penalty 0006-00-103 " + dtminorheads.Rows[0]["pnlty"].ToString());
                            file.WriteLine("SGST-Fee 0006-00-104 " + dtminorheads.Rows[0]["fee"].ToString());
                            file.WriteLine("SGST-Others 0006-00-800 " + dtminorheads.Rows[0]["oth"].ToString());
                           
                        }

                        StringBuilder updateqry = new StringBuilder(@"update compact_files set completed=@completed where cfileid=@cfileid ;");
                        NpgsqlCommand Up1cmd = new NpgsqlCommand(updateqry.ToString());
                        Up1cmd.Parameters.AddWithValue("@completed", "Y");
                        Up1cmd.Parameters.AddWithValue("@cfileid", insertedRec);
                        int updatedRec = data.UpdateData(Up1cmd, "nfs");

                        if (updatedRec > 0)
                        {
                            //System.IO.FileStream fs = null;
                            //fs = System.IO.File.Open(path + filename, System.IO.FileMode.Open);
                            //byte[] btFile = new byte[fs.Length];
                            //fs.Read(btFile, 0, Convert.ToInt32(fs.Length));
                            //fs.Close();
                            //Response.AddHeader("Content-disposition", "attachment; filename=" + filename);
                            //Response.ContentType = "application/octet-stream";
                            //Response.BinaryWrite(btFile);
                            //Response.End();

                            Response.Redirect("~/Reports/GeneratedCompactFile.aspx");
                        }
                    }
                }
            }
        }
        catch (ThreadAbortException ex1)
        {
            // do nothing
        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
        }


    }

    private void filltiles(string date)
    {

        StringBuilder SelectQuery = new StringBuilder(@"select sum(amt),count(rbi.cin) as txns from rbi_response_txns_details rbi
                                                        inner join transactions_eod_cin tec on tec.cin=rbi.cin
                                                        where  totaltxnamt=sgst_total and to_char(rbi.paymentdatetime,'DD/MM/YYYY')=@paymentdate");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdate", date);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        if (dt.Rows.Count > 0)
        {
            if (Convert.ToInt32(dt.Rows[0]["txns"].ToString()) != 0)
            {
                
                lbltotamt.Text = dt.Rows[0]["sum"].ToString();
                lbltxns.Text = dt.Rows[0]["txns"].ToString();
                hylnktxns.NavigateUrl = md5util.CreateTamperProofURL("~/Reports/MatchedTxns.aspx", null, "dt=" + MD5Util.Encrypt(date, true));
            }
            else
            {
                msg.Show("No transaction found for date : "+txtdate.Text);
            }
        }
    }

    protected void btnshowdata_Click(object sender, EventArgs e)
    {
        tbldate.Visible = true;
        lblpymtdate.Text = txtdate.Text;
        filltiles(txtdate.Text);
    }
}