﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Threading;

public partial class Reports_GstnFileRecCount : System.Web.UI.Page
{
    MD5Util md5util = new MD5Util();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
        {

            if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
            StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
            {
                Response.Redirect("Logout.aspx");
            }
        }

        fillgrid();
    }

    private void fillgrid()
    {

        string filecntid = MD5Util.Decrypt(Request.QueryString["id"].ToString(), true);

        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"SELECT frcid, filetype, to_char(filedate,'DD/MM/YYYY') filedate, file_num, sgstcnt,cnt, validfile,filename, reason FROM file_record_count where filecntid=@filecntid and validfile='Y'");

        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@filecntid", filecntid);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        grdgstfiles.DataSource = dt;
        grdgstfiles.DataBind();
    }


    protected void grdgstfiles_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            string id = grdgstfiles.DataKeys[e.Row.RowIndex].Values["frcid"].ToString();
            HyperLink hylnkhylnkhylnkincor = (HyperLink)e.Row.FindControl("hylnkincor");
            hylnkhylnkhylnkincor.NavigateUrl = md5util.CreateTamperProofURL("~/Reports/GstnEodcinDetails.aspx", null, "id=" + MD5Util.Encrypt(id, true));


        }

    }

    protected void grdgstfiles_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "download")
        {
            LinkButton lnkView = (LinkButton)e.CommandSource;
            GridViewRow myRow = (GridViewRow)lnkView.Parent.Parent;  // the row
            GridView myGrid = (GridView)sender;
            string filename = myGrid.DataKeys[myRow.RowIndex].Values["filename"].ToString();

            try
            {
                 filename = filename + ".txt";
                string path = Constants.SAVED_FILE_PATH + "GSTN\\RAWDATA\\" + filename ;
                System.IO.FileStream fs = null;
                fs = System.IO.File.Open(path, System.IO.FileMode.Open);
                byte[] btFile = new byte[fs.Length];
                fs.Read(btFile, 0, Convert.ToInt32(fs.Length));
                fs.Close();
                Response.AddHeader("Content-disposition", "attachment; filename=" + filename);
                Response.ContentType = "application/octet-stream";
                Response.BinaryWrite(btFile);
                Response.End();
            }
            catch (ThreadAbortException ex1)
            {
                // do nothing
            }
            catch (Exception ex)
            {
                ExceptionLogging.logException(ex);
            }
        }
    }
}