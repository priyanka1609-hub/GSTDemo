﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;
using System.Globalization;

public partial class Reports_CinEligibleforMoE : System.Web.UI.Page
{

    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    protected DataTable dtforgrid;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string todatecurrent = DateTime.Now.ToString("dd/MM/yyyy");
            string fromdatecurrent = "01/" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.ToString("yyyy");
            txtfromdate.Text = fromdatecurrent.Replace("-", "/");
            txttodate.Text = todatecurrent.Replace("-", "/");
            fillgrid(fromdatecurrent, todatecurrent);
        }
    }
    protected void fillgrid(string from, string to)
    {
        
       string fromdate=string.Empty;
       StringBuilder SelectQuery = new StringBuilder(@" select count(cin) notrns,payment_dt,sum(sgst_total) amount from (select cin,to_char(paymentdatetime,'DD/MM/YYYY') payment_dt,paymentdatetime,sgst_total from (
                                                        select cin,paymentdatetime,sgst_total from transactions_eod_cin tec
                                                        where cin not in (select cin from rbi_response_txns_details) and sgst_total <> 0.00
                                                        union
                                                        select tec.cin ,tec.paymentdatetime,sgst_total from transactions_eod_cin tec
                                                        inner join rbi_response_txns_details rbi on rbi.cin = tec.cin
                                                        where sgst_total > totaltxnamt) t  where paymentdatetime >= @from and paymentdatetime <= @to and cin not in (select cin from moe_compact)
                                                        union
                                                        select cin,to_char(paymentdatetime,'DD/MM/YYYY') payment_dt,paymentdatetime,totaltxnamt from (
                                                        select cin,paymentdatetime,totaltxnamt from rbi_response_txns_details rbi
                                                        where cin not in (select cin from transactions_eod_cin )
                                                        union
                                                        select rbi.cin ,rbi.paymentdatetime,totaltxnamt from rbi_response_txns_details  rbi
                                                        inner join transactions_eod_cin tec on rbi.cin = tec.cin
                                                        where sgst_total < totaltxnamt and sgst_total <> 0.00) s  where paymentdatetime >= @from and paymentdatetime <= @to and  cin not in (select cin from moe_compact)) u group by payment_dt
                                                        order by to_timestamp(payment_dt, 'DD-MM-YYYY hh24:mi:ss')::timestamp without time zone");

        // SelectQuery.Append(" order by to_timestamp(payment_dt, 'DD-MM-YYYY hh24:mi:ss')::timestamp without time zone");
         fromdate = Utility.pgsqlFromDateFormat(from);
         NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
         SelectCmd.Parameters.AddWithValue("@from", fromdate);
         SelectCmd.Parameters.AddWithValue("@to", Utility.pgsqlToDateFormat(to));
         DataTable dt = data.GetDataTable(SelectCmd, "nfs");
         if (dt.Rows.Count > 0)
         {
             dtforgrid = new DataTable();
             dtforgrid.Clear();
             dtforgrid.Columns.Add("paymentdate");
             //dtforgrid.Columns.Add("neramt");
             dtforgrid.Columns.Add("notrns");
             dtforgrid.Columns.Add("totalamnt");
             for (int i = 0; i < dt.Rows.Count; i++)
             {

                 DataRow dr = dtforgrid.NewRow();
                 dr["paymentdate"] = dt.Rows[i]["payment_dt"];
                 //dr["neramt"] = amtner.ToString("F2");
                 dr["notrns"] = dt.Rows[i]["notrns"];
                 //dr["nertxns"] = nertxns.ToString();
                 dr["totalamnt"] = dt.Rows[i]["amount"];
                 dtforgrid.Rows.Add(dr);
             }
             
         }
    }
    protected void btnshowdata_Click(object sender, EventArgs e)
    {
        fillgrid(txtfromdate.Text, txttodate.Text);
    }
    protected string unmatchedxnDetails(string rowDate, string src)
    {

        return md5util.CreateTamperProofURL("../Reports/TxnsPendingForRecon.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true) + "&src=" + MD5Util.Encrypt(src, true));
    }
}