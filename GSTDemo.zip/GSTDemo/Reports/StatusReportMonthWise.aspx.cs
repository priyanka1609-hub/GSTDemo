﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;
public partial class Reports_StatusReportMonthWise : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    protected DataTable dtforgrid,dtmatch;

    protected void Page_Load(object sender, EventArgs e)
    {
        fillgrid();
    }
    protected void fillgrid()
    {
        Double amtner = 0.00d, amtepy = 0.00d;
        int nertxns = 0, epytxns = 0;
        StringBuilder SelectQuery = new StringBuilder(@"select count(*) as sgsttrns,sum(sgst_total) as totalsgst,to_char(paymentdatetime,'MM/YYYY') as paymentmonth from transactions_eod_cin where sgst_total != 0.00 group by to_char(paymentdatetime,'MM/YYYY') order by to_char(paymentdatetime,'MM/YYYY')");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        if (dt.Rows.Count > 0)
        {
            dtforgrid = new DataTable();
            dtforgrid.Clear();
            dtforgrid.Columns.Add("sgstMonth");
            dtforgrid.Columns.Add("notnsgstn");
            dtforgrid.Columns.Add("sgstamt");
            dtforgrid.Columns.Add("rbimonth");
            dtforgrid.Columns.Add("notnrbi");
            dtforgrid.Columns.Add("rbiamt");
            dtforgrid.Columns.Add("matchmonth");
            dtforgrid.Columns.Add("notnmatch");
            dtforgrid.Columns.Add("matchamt");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dr = dtforgrid.NewRow();
                dr["sgstMonth"] = dt.Rows[i]["paymentmonth"].ToString();
                dr["notnsgstn"] = dt.Rows[i]["sgsttrns"].ToString();
                dr["sgstamt"] = dt.Rows[i]["totalsgst"].ToString();
                dtforgrid.Rows.Add(dr);
            }
        }

        for (int j = 0; j < dtforgrid.Rows.Count; j++)
        {

            StringBuilder selectmatch = new StringBuilder(@"select Count(*) as noofmatch,sum(sgst_total) as matchedamnt , to_char(tec.paymentdatetime,'MM/YYYY') as matchedmonth from transactions_eod_cin tec inner join rbi_response_txns_details rbi on tec.cin=rbi.cin where tec.sgst_total=rbi.totaltxnamt and to_char(tec.paymentdatetime,'MM/YYYY')=@paymentmonth group by to_char(tec.paymentdatetime,'MM/YYYY') order by to_char(tec.paymentdatetime,'MM/YYYY')");
            NpgsqlCommand selectmatchcmd = new NpgsqlCommand(selectmatch.ToString());
            selectmatchcmd.Parameters.AddWithValue("@paymentmonth", dt.Rows[j]["paymentmonth"].ToString());
            DataTable dtmatch = data.GetDataTable(selectmatchcmd, "nfs");
            if (dtmatch.Rows.Count > 0)
            {
                dtforgrid.Rows[j]["notnmatch"] = dtmatch.Rows[0]["noofmatch"].ToString();
                dtforgrid.Rows[j]["matchamt"] = dtmatch.Rows[0]["matchedamnt"].ToString();
                    

            }
        }

       
    }
}