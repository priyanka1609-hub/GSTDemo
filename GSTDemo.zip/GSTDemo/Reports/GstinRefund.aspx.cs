﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;

public partial class Reports_GstinRefund : System.Web.UI.Page
{
    MD5Util md5util = new MD5Util();
    public DataTable dt = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
        }

    }
    protected void btn_getgstin_Click(object sender, EventArgs e)
    {
        fillgrid(txtgstin.Text);
    }

    public void fillgrid(string gstin)
    {

        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select tec.cpin,tec.gstin,sgst_tax,sgst_intr,sgst_fee,sgst_pnlty,sgst_oth,sgst_total,tec.cin,pm.modedesc,tec.txnid,bm.bankname,bank_ref_num,to_char(tec.paymentdatetime,'DD/MM/YYYY') as paymentdatetime,utr_num, ack_num,bank_ref_num,br_ifsc_cd, br_location, br_name, instrument_no, instrument_micr_cd, 
                                                        to_char(tec.cpindatetime,'DD/MM/YYYY') as cpindatetime, to_char(tec.pymntackdatetime,'DD/MM/YYYY') as pymntackdatetime, to_char(tec.reportingdatetime,'DD/MM/YYYY') as reportingdatetime,ra.refundedamount from transactions_eod_cin tec
                                                        inner join rbi_response_txns_details rbi on rbi.cin=tec.cin
                                                        inner join master_gstn_pay_mode pm on pm.mode=tec.mode
                                                        inner join master_gstn_banks bm on bm.bankcode=tec.bank_cd
                                                        left outer join refundedamount ra on tec.cin=ra.cin
                                                        where tec.gstin=@gstin");

         NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
         SelectCmd.Parameters.AddWithValue("@gstin", gstin);
         dt = data.GetDataTable(SelectCmd, "nfs");

         if (dt.Rows.Count > 0 && dt != null)
         {
             gstindetails.Visible = true;
         }
         else
         {
             gstindetails.Visible = false;
         }
    }

    protected string geturl(string cin,string gstin)
    {
        return md5util.CreateTamperProofURL("../Reports/Refundamountentry.aspx", null, "cin=" + MD5Util.Encrypt(cin, true) + "&gstin=" + MD5Util.Encrypt(gstin, true));
    }
}