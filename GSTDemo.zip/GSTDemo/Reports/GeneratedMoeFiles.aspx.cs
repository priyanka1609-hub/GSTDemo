﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Threading;

public partial class Reports_GeneratedMoeFiles : System.Web.UI.Page
{
    message msg = new message();
    MD5Util md5util = new MD5Util();
    protected void Page_Load(object sender, EventArgs e)
    {
        fillgrid();
    }

    protected void fillgrid()
    {
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select moefileid,mm.description,totalcases,to_char(generatedatetime,'DD/MM/YYYY HH24:MI:SS') gendateime,filename,mu.uc_name from moe_files mf
                                                        inner join master_moe mm on mm.moetype=mf.moetype
                                                        inner join master_users mu on mu.user_id=mf.userid
                                                        where totalcases is not null order by generatedatetime desc");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        if (dt.Rows.Count > 0)
        {
            grdmoe.DataSource = dt;
            grdmoe.DataBind();
        }
        else
        {
            msg.Show("No Data Found");
        }
    }

    protected void grdmoe_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                string fileid = grdmoe.DataKeys[e.Row.RowIndex].Values["moefileid"].ToString();
                HyperLink hylnkcase = (HyperLink)e.Row.FindControl("hylnktotalcases");
                hylnkcase.NavigateUrl = md5util.CreateTamperProofURL("~/Reports/MoeCasesList.aspx", null, "fileid=" + MD5Util.Encrypt(fileid, true));
                
            }
        }
        catch
        {

        }
    }
}