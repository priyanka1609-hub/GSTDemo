﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;

public partial class Reports_Mismatchbakrefnum : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    public string datechck, todatecurrent = string.Empty, fromdatecurrent=string.Empty;
    protected DataTable dt;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState

            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Logout.aspx");
                }
            }
            try { datechck = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true); }
            catch { datechck = string.Empty; }
            todatecurrent = DateTime.Now.ToString("dd/MM/yyyy");
            //string fromdatecurrent = DateTime.Now.AddDays(-30).ToString("dd/MM/yyyy");
            fromdatecurrent = "01/" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.ToString("yyyy");
            txtfromdate.Text = fromdatecurrent.Replace("-", "/");
            txttodate.Text = todatecurrent.Replace("-", "/");
        }
        
        fillgrid(fromdatecurrent, todatecurrent);
    }
    protected void fillgrid(string from, string to)
    {
        
        string fromdate = string.Empty;
        StringBuilder SelectQuery = new StringBuilder(@"select tec.cin,sgst_total,to_char(tec.paymentdatetime,'DD/MM/YYYY') payment_dt,tec.paymentdatetime ,banktype,bank_ref_num,brn
                            from transactions_eod_cin tec 
                            inner join rbi_response_txns_details rbi on rbi.cin = tec.cin
                            inner join master_gstn_banks mgb on mgb.bankcode=tec.bank_cd
                            where sgst_total != 0.00 and sgst_total=totaltxnamt and rbi.brn!=tec.bank_ref_num ");

     
            SelectQuery.Append(" and tec.paymentdatetime >= @from and tec.paymentdatetime <= @to ");
            fromdate = Utility.pgsqlFromDateFormat(from);
            //if (!(Convert.ToInt64(from.Substring(3, 2)) < 8) && (Convert.ToInt64(from.Substring(6, 4)) <= 2017))
            //{

            //    SelectQuery.Append(" and to_char(rbi.paymentdatetime,'DD/MM/YYYY')=to_char(tec.paymentdatetime,'DD/MM/YYYY')");
            //    //fromdate = Utility.pgsqlFromDateFormat(from);
            //}
        

        

        SelectQuery.Append(" order by paymentdatetime");

        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        //SelectCmd.Parameters.AddWithValue("@paymentdatetime", date);
        SelectCmd.Parameters.AddWithValue("@from", fromdate);
        SelectCmd.Parameters.AddWithValue("@to", Utility.pgsqlToDateFormat(to));
         dt = data.GetDataTable(SelectCmd, "nfs");

    }
    protected void btnshowdata_Click(object sender, EventArgs e)
    {
       
            fillgrid(txtfromdate.Text, txttodate.Text);
        
    }
    protected void imgbtndownload_Click(object sender, ImageClickEventArgs e)
    {
        fillgrid(txtfromdate.Text, txttodate.Text);
        Exportfile exp = new Exportfile();
        exp.exportprint(tblmisref,"MisMatch BANK Ref");
    }
}