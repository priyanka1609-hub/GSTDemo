﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Threading;
using System.Globalization;

public partial class Reports_RbiBalanceEntryReport : System.Web.UI.Page
{

    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    public string datechck;
    public string date;
    public decimal totalamount = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try { datechck = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true); }
            catch { datechck = string.Empty; }

            if (string.IsNullOrEmpty(datechck))
            {
                // showData();
                string todatecurrent = DateTime.Now.ToString("dd/MM/yyyy");
                string fromdatecurrent = "01/" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.ToString("yyyy");
                txtfromdate.Text = fromdatecurrent.Replace("-", "/");
                txttodate.Text = todatecurrent.Replace("-", "/");
                fillgrid(fromdatecurrent, todatecurrent);

            }
            else
            {
                fromtodate.Visible = false;
                fillgrid("", "");

            }



        }
    }
    private void fillgrid(string from, string to)
    {
        string fromdate = string.Empty;
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select mbt.baltype,amt,to_char(exedatetime,'DD/MM/YYYY') as exedatetime,stmtid from rbi_as_balance rab inner join master_bal_type mbt on mbt.balcode=rab.baltype    ");
        SelectQuery.Append(" where rab.exedatetime >= @from and rab.exedatetime <= @to");
        SelectQuery.Append(" order by to_char(exedatetime,'YYYY/MM/DD')");
        fromdate = Utility.pgsqlFromDateFormat(from);

        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@from", fromdate);
        SelectCmd.Parameters.AddWithValue("@to", Utility.pgsqlToDateFormat(to));

        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
        grdaccount.DataSource = dt;
        grdaccount.DataBind();

    }
    protected void btnshowdata_Click(object sender, EventArgs e)
    {


        fillgrid(txtfromdate.Text, txttodate.Text);
    }
    //protected void gvrbibal_rowdatabound(object sender, GridViewRowEventArgs e)
    //{
    //    if (e.Row.RowType == DataControlRowType.DataRow)
    //    {

    //        Label lblamount = (Label)e.Row.FindControl("lblamount");
    //        decimal amt = decimal.Parse(lblamount.Text);

    //        totalamount += amt;


    //    }

    //    if (e.Row.RowType == DataControlRowType.Footer)
    //    {
    //        Label lblamt = (Label)e.Row.FindControl("lblamt");


    //        lblamt.Text = totalamount.ToString();


    //    }
    //}
}