﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;

public partial class Reports_RbiTransactionsMismatch : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    public string datechck, fromdatecurrent = string.Empty, todatecurrent = string.Empty;

    protected DataTable dtforgrid;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            //ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState

            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Logout.aspx");
                }
            }



        }
        try { datechck = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true); }
        catch { datechck = string.Empty; }

        if (string.IsNullOrEmpty(datechck))
        {
            // showData();

            fillgrid(fromdatecurrent, todatecurrent);

        }
        else
        {
            //fromtodate.Visible = false;
            fillgrid("", "");

        }


    }

    protected void fillgrid(string from, string to)
    {
        string date = string.Empty; string fromdate = string.Empty;
        StringBuilder SelectQuery = new StringBuilder(@"select noti.filename,to_char(scrolldate,'DD/MM/YYYY') filedate,en.ntryref, nboftxs, en.amt, count(cin) as cntxns, sum(totaltxnamt) cnamt from rbi_response_entries en
                                                        inner join rbi_response_notifications noti on noti.id=en.notifyid
                                                        inner join rbi_response_txns_details tx on en.ntryref=tx.ntryref 
                                                        group by noti.filename,noti.scrolldate,en.ntryref
                                                        having count(cin) <> nboftxs order by filedate");

        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        dtforgrid = data.GetDataTable(SelectCmd, "nfs");

    }
}