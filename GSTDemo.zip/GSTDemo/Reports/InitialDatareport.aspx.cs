﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;


public partial class Reports_InitialDatareport : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();

    protected DataTable dtforgrid;

    protected void Page_Load(object sender, EventArgs e)
    {
        fillgrid();
    }

    protected void fillgrid()
    {
        Double amtpsb = 0.00d, amtpvt = 0.00d, amtner=0.00d;
        int nertxns = 0, psbtxns = 0, pvttxns = 0;
        StringBuilder SelectQuery = new StringBuilder(@"select cin,mode,sgst_total,to_char(paymentdatetime,'DD/MM/YYYY') payment_dt,paymentdatetime ,banktype
                                                        from transactions_eod_cin tec 
                                                        inner join master_gstn_banks mgb on mgb.bankcode=tec.bank_cd
                                                        where sgst_total != 0.00 order by paymentdatetime");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        if (dt.Rows.Count > 0)
        {
            dtforgrid = new DataTable();
            dtforgrid.Clear();
            dtforgrid.Columns.Add("date");
            dtforgrid.Columns.Add("psbtxns");
            dtforgrid.Columns.Add("psbamt");
            dtforgrid.Columns.Add("pvttxns");
            dtforgrid.Columns.Add("pvtamt");
            dtforgrid.Columns.Add("nertxns");
            dtforgrid.Columns.Add("neramt");
            dtforgrid.Columns.Add("rbitxns");
            dtforgrid.Columns.Add("rbiamt");

            dtforgrid.PrimaryKey = new DataColumn[] { dt.Columns["date"] };

            int i;
            int dtrowscount = dt.Rows.Count;
            for (i = 0; i < dtrowscount; i++)
            {
                if (i == 0)
                {
                    if (dt.Rows[0]["banktype"].ToString() == "R")
                    {
                        amtner = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                        nertxns++;
                    }
                    else if (dt.Rows[0]["banktype"].ToString() == "G")
                    {
                        amtpsb = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                        psbtxns++;

                    }
                    else if (dt.Rows[0]["banktype"].ToString() == "P")
                    {
                        amtpvt = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                        pvttxns++;

                    }

                }
                else
                {
                    if (dt.Rows[i]["payment_dt"].ToString() == dt.Rows[i - 1]["payment_dt"].ToString())
                    {
                        if (dt.Rows[i]["banktype"].ToString() == "R")
                        {
                            double newamtner = amtner + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtner = newamtner;
                            //amtner = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            nertxns++;
                        }
                        else if (dt.Rows[i]["banktype"].ToString() == "G")
                        {
                            double newamtpsb = amtpsb + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtpsb = newamtpsb;
                            //amtpsb = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            psbtxns++;

                        }
                        else if (dt.Rows[i]["banktype"].ToString() == "P")
                        {
                            double newamtpvt = amtpvt + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtpvt = newamtpvt;

                            //amtpvt = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            pvttxns++;

                        }
                    }
                    else
                    {
                        DataRow dr = dtforgrid.NewRow();
                        dr["date"] = dt.Rows[i - 1]["payment_dt"];
                        dr["psbtxns"] = psbtxns.ToString();
                        dr["psbamt"] = amtpsb.ToString("F2");
                        dr["pvttxns"] = pvttxns.ToString();
                        dr["pvtamt"] = amtpvt.ToString("F2");
                        dr["nertxns"] = nertxns.ToString();
                        dr["neramt"] = amtner.ToString("F2");
                        
                        
                        dtforgrid.Rows.Add(dr);

                        amtner = 0.00d;
                        amtpsb = 0.00d;
                        amtpvt = 0.00d;
                        nertxns = 0;
                        psbtxns = 0;
                        pvttxns = 0;

                        if (dt.Rows[i]["banktype"].ToString() == "R")
                        {
                            double newamtner = amtner + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtner = newamtner;
                            //amtner = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            nertxns++;
                        }
                        else if (dt.Rows[i]["banktype"].ToString() == "G")
                        {
                            double newamtpsb = amtpsb + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtpsb = newamtpsb;
                            //amtpsb = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            psbtxns++;

                        }
                        else if (dt.Rows[i]["banktype"].ToString() == "P")
                        {
                            double newamtpvt = amtpvt + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtpvt = newamtpvt;

                            //amtpvt = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            pvttxns++;

                        }

                    }
                }

            }

            DataRow droneorlast = dtforgrid.NewRow();
            droneorlast["date"] = dt.Rows[i - 1]["payment_dt"];
            droneorlast["psbtxns"] = psbtxns.ToString();
            droneorlast["psbamt"] = amtpsb.ToString("F2");
            droneorlast["pvttxns"] = pvttxns.ToString();
            droneorlast["pvtamt"] = amtpvt.ToString("F2");
            droneorlast["nertxns"] = nertxns.ToString();
            droneorlast["neramt"] = amtner.ToString("F2");
            dtforgrid.Rows.Add(droneorlast);

            SelectQuery = new StringBuilder(@"select count(cin), sum(totaltxnamt), to_char(paymentdatetime,'DD/MM/YYYY') payment_dt from rbi_response_txns_details group by to_char(paymentdatetime,'DD/MM/YYYY')");
            SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
            dt = data.GetDataTable(SelectCmd, "nfs");

            for (int j = 0; j < dt.Rows.Count; j++)
            {
                if (dtforgrid.Rows.Contains(dt.Rows[j]["payment_dt"].ToString()))
                {
                    int test = 0;
                }
                else
                {
                    int test1 = 0;

                }
                //if (dt.Rows[0]["sum"].ToString() == "0")
                //{
                //    dtforgrid.Rows[j]["rbiamt"] = "---";
                //}
                //else
                //{
                //    dtforgrid.Rows[j]["rbiamt"] = dt.Rows[0]["sum"].ToString();
                //    dtforgrid.Rows[j]["matchedamt"] = dt.Rows[0]["matchedsum"].ToString();
                //    dtforgrid.Rows[j]["suspense"] = Math.Abs((Convert.ToDecimal(dtforgrid.Rows[j]["epyamt"].ToString()) + Convert.ToDecimal(dtforgrid.Rows[j]["neramt"].ToString())) - Convert.ToDecimal(dt.Rows[0]["matchedsum"].ToString())).ToString();
                //    dtforgrid.Rows[j]["rat"] = Math.Abs(Convert.ToDecimal(dt.Rows[0]["sum"].ToString()) - Convert.ToDecimal(dt.Rows[0]["matchedsum"].ToString())).ToString();
                //    dtforgrid.Rows[j]["unmatchedamt"] = Math.Abs(Convert.ToDecimal(dtforgrid.Rows[j]["rat"].ToString()) + (Convert.ToDecimal(dtforgrid.Rows[j]["suspense"].ToString()))).ToString();

                //}

            }

        }

    }

    protected string ReturnURl(string rowDate)
    {

        return md5util.CreateTamperProofURL("../Reports/MinorHeadReport.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true));
    }


    protected string bankWiseURL(string rowDate)
    {

        return md5util.CreateTamperProofURL("../Reports/BankWiseReport.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true));
    }

    protected string matchedURL(string rowDate)
    {

        return md5util.CreateTamperProofURL("../Reports/MatchedTxns.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true));
    }

    protected string gstnTxnDetails(string rowDate, string mode)
    {

        return md5util.CreateTamperProofURL("../Reports/GstnEodcinDetails.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true) + "&mode=" + MD5Util.Encrypt(mode, true));
    }
    protected string rbiTxnDetails(string rowDate)
    {

        return md5util.CreateTamperProofURL("../Reports/RbiScrollDetails.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true));
    }
    protected string unmatchedxnDetails(string rowDate, string src)
    {

        return md5util.CreateTamperProofURL("../Reports/TxnsPendingForRecon.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true) + "&src=" + MD5Util.Encrypt(src, true));
    }
}