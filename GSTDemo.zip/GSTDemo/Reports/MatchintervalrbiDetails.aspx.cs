﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;

public partial class Reports_MatchintervalrbiDetails : System.Web.UI.Page
{

    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    public string matchtype=string.Empty, paymentmonth = string.Empty, todatecurrent = string.Empty;

    protected DataTable dtforgrid;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            //ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState

            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Logout.aspx");
                }
            }
        }
        try { paymentmonth = MD5Util.Decrypt(Request.QueryString["month"].ToString(), true); }
        catch { paymentmonth = string.Empty; }
        try { matchtype = MD5Util.Decrypt(Request.QueryString["matchtype"].ToString(), true); }
        catch { matchtype = string.Empty; }
        
        fillgrid(paymentmonth,matchtype);
    }


    public void fillgrid(string paymentmonth, string matchtype)
    {
        if (matchtype == "B")
        {
            lblheading.Text = "Matched Data";
            StringBuilder SelectQuery = new StringBuilder(@"select tc.cin,tc.payment_dt as gstnpaymentdate,to_char(rrtd.paymentdatetime,'DD/MM/YYYY') as rbipaymentdate,sgst_amt as gstnamount,totaltxnamt as rbiamount from  transactions_cin tc inner join  rbi_response_txns_details rrtd on tc.cin=rrtd.cin where substring(payment_dt from 4 for 7)=@month");
            NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
            SelectCmd.Parameters.AddWithValue("@month", paymentmonth);
            dtforgrid = data.GetDataTable(SelectCmd, "nfs");
        }
        else if (matchtype == "G")
        {
            lblheading.Text = "Suspense Data";
            StringBuilder SelectQuery = new StringBuilder(@"select  tc.cin,tc.payment_dt as gstnpaymentdate,sgst_amt as gstnamount from transactions_cin tc left outer join  rbi_response_txns_details rrtd on tc.cin=rrtd.cin  where substring(payment_dt from 4 for 7)=@month and rrtd.cin is null");
            NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
            SelectCmd.Parameters.AddWithValue("@month", paymentmonth);
            dtforgrid = data.GetDataTable(SelectCmd, "nfs");
        }
        else if (matchtype == "R")
        {
            lblheading.Text = "RAT Data";
            StringBuilder SelectQuery = new StringBuilder(@"select tc.cin,to_char(paymentdatetime,'DD/MM/YYYY') as rbipaymentdate,totaltxnamt as rbiamount from rbi_response_txns_details  tc left outer join  transactions_cin rrtd on tc.cin=rrtd.cin  where substring(to_char(paymentdatetime,'DD/MM/YYYY') from 4 for 7)=@month and  rrtd.cin is null ");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@month", paymentmonth);
        dtforgrid = data.GetDataTable(SelectCmd, "nfs");
        }
    }
    protected void imgbtnback_Click(object sender, ImageClickEventArgs e)
    {
        if (ViewState["PreviousPage"] != null)	//Check if the ViewState 
        //contains Previous page URL
        {
            Response.Redirect(ViewState["PreviousPage"].ToString());//Redirect to 
            //Previous page by retrieving the PreviousPage Url from ViewState.
        }
    }
    protected void imgbtndownload_Click(object sender, ImageClickEventArgs e)
    {

        fillgrid(paymentmonth, matchtype);
        Exportfile exp = new Exportfile();
        if (matchtype == "B")
        {
            exp.exportprint(tbldata, "Matched Data");
        }
        else if (matchtype == "G")
        {
             exp.exportprint(tbldata, "Suspense Data");
        }
        else if (matchtype == "R")
        {
             exp.exportprint(tbldata, "RAT Data");
        }
        
    }
}
