﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;


public partial class Reports_MinorHeadReport : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    protected DataTable dtforgrid;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            ViewState["PreviousPage"] =Request.UrlReferrer;//Saves the Previous page url in ViewState

            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Logout.aspx");
                }
            }

            // showData();

            if (Request.QueryString["dt"] != null)
            {
                lbldate.Text = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true);
                fillgrid(lbldate.Text);
            }
        }
    }

    protected void fillgrid(string date)
    {


        StringBuilder SelectQuery = new StringBuilder(@"select COALESCE(sum(sgst_tax),'0.00') tax, COALESCE(sum(sgst_intr),'0.00') intr, COALESCE(sum(sgst_pnlty),'0.00') pnlty, COALESCE(sum(sgst_fee),'0.00') fee, COALESCE(sum(sgst_oth),'0.00') oth, COALESCE(sum(sgst_total),'0.00') total from transactions_eod_cin where  to_char(paymentdatetime,'DD/MM/YYYY') =@paymentdatetime ;");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdatetime", date);
        DataTable dtgstn = data.GetDataTable(SelectCmd, "nfs");

        SelectQuery = new StringBuilder(@"select count(rbi.cin),COALESCE(sum(sgst_tax),'0.00') tax, COALESCE(sum(sgst_intr),'0.00') intr, COALESCE(sum(sgst_pnlty),'0.00') pnlty, COALESCE(sum(sgst_fee),'0.00') fee, COALESCE(sum(sgst_oth),'0.00') oth , COALESCE(sum(sgst_total),'0.00') total from transactions_eod_cin tec
                                        inner join rbi_response_txns_details rbi on rbi.cin=tec.cin
                                         where  to_char(tec.paymentdatetime,'DD/MM/YYYY') =@paymentdatetime and rbi.totaltxnamt=tec.sgst_total and rbi.cin in (select cin from moe_compact)");
        SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdatetime", date);
        DataTable dtmatched = data.GetDataTable(SelectCmd, "nfs");


        SelectQuery = new StringBuilder(@"select sum(totaltxnamt) total from rbi_response_txns_details where  to_char(paymentdatetime,'DD/MM/YYYY') =@paymentdatetime");
        SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdatetime", date);
        DataTable dtrbi = data.GetDataTable(SelectCmd, "nfs");

        dtforgrid = new DataTable();
        dtforgrid.Clear();
        dtforgrid.Columns.Add("desc");
        dtforgrid.Columns.Add("tax");
        dtforgrid.Columns.Add("intr");
        dtforgrid.Columns.Add("pnlty");
        dtforgrid.Columns.Add("fee");
        dtforgrid.Columns.Add("oth");
        dtforgrid.Columns.Add("total");

        DataRow dr = dtforgrid.NewRow();
        dr["desc"] = "Amount reported by GSTN";
        dr["tax"] = dtgstn.Rows[0]["tax"].ToString();
        dr["intr"] = dtgstn.Rows[0]["intr"].ToString();
        dr["pnlty"] = dtgstn.Rows[0]["pnlty"].ToString();
        dr["fee"] = dtgstn.Rows[0]["fee"].ToString();
        dr["oth"] = dtgstn.Rows[0]["oth"].ToString();
        dr["total"] = dtgstn.Rows[0]["total"].ToString();
        dtforgrid.Rows.Add(dr);

        dr = dtforgrid.NewRow();
        dr["desc"] = "Amount reported by RBI";
        dr["tax"] = "---";
        dr["intr"] = "---";
        dr["pnlty"] = "---";
        dr["fee"] = "---";
        dr["oth"] = "---";
        dr["total"] = dtrbi.Rows[0]["total"].ToString();
        dtforgrid.Rows.Add(dr);

        if (Convert.ToInt32(dtmatched.Rows[0]["count"].ToString()) != 0)
        {
            dr = dtforgrid.NewRow();
            dr["desc"] = "Amount reconcilied with rbi/GSTN";
            dr["tax"] = dtmatched.Rows[0]["tax"].ToString();
            dr["intr"] = dtmatched.Rows[0]["intr"].ToString();
            dr["pnlty"] = dtmatched.Rows[0]["pnlty"].ToString();
            dr["fee"] = dtmatched.Rows[0]["fee"].ToString();
            dr["oth"] = dtmatched.Rows[0]["oth"].ToString();
            dr["total"] = dtmatched.Rows[0]["total"].ToString();
            dtforgrid.Rows.Add(dr);


            dr = dtforgrid.NewRow();
            dr["desc"] = "Amount in RAT (Pending for Reconciliation)";
            dr["tax"] = "---";
            dr["intr"] = "---";
            dr["pnlty"] = "---";
            dr["fee"] = "---";
            dr["oth"] = "---";
            dr["total"] = Math.Abs(Convert.ToDecimal(dtrbi.Rows[0]["total"].ToString()) - Convert.ToDecimal(dtmatched.Rows[0]["total"].ToString()));
            dtforgrid.Rows.Add(dr);

            dr = dtforgrid.NewRow();
            dr["desc"] = "Amount in suspense (Pending for Reconciliation)";
            dr["tax"] = Math.Abs(Convert.ToDecimal(dtgstn.Rows[0]["tax"].ToString()) - Convert.ToDecimal(dtmatched.Rows[0]["tax"].ToString()));
            dr["intr"] = Math.Abs(Convert.ToDecimal(dtgstn.Rows[0]["intr"].ToString()) - Convert.ToDecimal(dtmatched.Rows[0]["intr"].ToString()));
            dr["pnlty"] = Math.Abs(Convert.ToDecimal(dtgstn.Rows[0]["pnlty"].ToString()) - Convert.ToDecimal(dtmatched.Rows[0]["pnlty"].ToString()));
            dr["fee"] = Math.Abs(Convert.ToDecimal(dtgstn.Rows[0]["fee"].ToString()) - Convert.ToDecimal(dtmatched.Rows[0]["fee"].ToString()));
            dr["oth"] = Math.Abs(Convert.ToDecimal(dtgstn.Rows[0]["oth"].ToString()) - Convert.ToDecimal(dtmatched.Rows[0]["oth"].ToString()));
            dr["total"] = Math.Abs(Convert.ToDecimal(dtgstn.Rows[0]["total"].ToString()) - Convert.ToDecimal(dtmatched.Rows[0]["total"].ToString()));
            dtforgrid.Rows.Add(dr);
        }

        //grdminorheadwise.DataSource = dtforgrid;
        //grdminorheadwise.DataBind();
    }


    protected void imgbtnback_Click(object sender, ImageClickEventArgs e)
    {
        if (ViewState["PreviousPage"] != null)	//Check if the ViewState 
        //contains Previous page URL
        {
            Response.Redirect(ViewState["PreviousPage"].ToString());//Redirect to 
            //Previous page by retrieving the PreviousPage Url from ViewState.
        }
    }
}