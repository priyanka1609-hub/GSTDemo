﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;

public partial class Reports_TxnsPendingForRecon : System.Web.UI.Page
{
    public string paymentdate = string.Empty;
    MD5Util md5util = new MD5Util();
    PostgresGetData data = new PostgresGetData();
    public string todate = string.Empty, fromdate = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState

            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Login.aspx?id=0");
                }
                else
                {
                    fillgrid();
                }
            }
        }


    }


    private void fillgrid()
    {

        string src = string.Empty, banktype = string.Empty, whethercondition = string.Empty;

        bool checkMoeCompct = false;

        if (Request.QueryString["src"] != null)
        {
            src = MD5Util.Decrypt(Request.QueryString["src"].ToString(), true);
        }
        if (Request.QueryString["dt"] != null)
        {
            paymentdate = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true);
        }
        if (Request.QueryString["banktype"] != null)
        {
            banktype = MD5Util.Decrypt(Request.QueryString["banktype"].ToString(), true);
        }
        if (Request.QueryString["todate"] != null)
        {
            todate = MD5Util.Decrypt(Request.QueryString["todate"].ToString(), true);
        }

        decimal rbitotamt = 0, gstntotamt = 0;

        DataTable dtforgrid = new DataTable();
        dtforgrid.Clear();
        dtforgrid.Columns.Add("moetype");
        dtforgrid.Columns.Add("date");
        dtforgrid.Columns.Add("cin");
        dtforgrid.Columns.Add("reportedby");
        dtforgrid.Columns.Add("gstnamt");
        dtforgrid.Columns.Add("rbiamt");
        dtforgrid.Columns.Add("status");

        if (src == "SUS" || src == "TOT")
        {
            if (src == "SUS")
            {
                whethercondition = " left outer join rbi_response_txns_details rbi on rbi.cin=tec.cin";
            }

            StringBuilder SelectQuery = new StringBuilder(@"select tec.cin,sgst_total,case COALESCE(mc.status,'0') when '0' then 'Not processed' else ms.statusdesc end as status,to_char(tec.paymentdatetime,'DD/MM/YYYY') as paymentdate from transactions_eod_cin tec 
                                                            inner join master_gstn_banks mgb on mgb.bankcode=tec.bank_cd
                                                            left outer join moe_compact mc on mc.cin=tec.cin
                                                            left outer join master_status ms on ms.statuscode=mc.status
                                                            " +whethercondition+@"
                                                            where");
                                                          

            if (!string.IsNullOrEmpty(todate))
            {
                SelectQuery.Append("       tec.paymentdatetime >= @from and tec.paymentdatetime <= @to and sgst_total <> 0.00 ");
                fromdate = Utility.pgsqlFromDateFormat(paymentdate);
            }
            else
            {
                SelectQuery.Append("  tec.cin not in  (select cin from rbi_response_txns_details where to_char(paymentdatetime,'DD/MM/YYYY')=@paymentdate)  and to_char(tec.paymentdatetime,'DD/MM/YYYY')=@paymentdate and sgst_total <> 0.00 ");
            }

            if (src == "SUS")
            {
                SelectQuery.Append("   and rbi.cin is null");
            }

            if (!string.IsNullOrEmpty(banktype))
            {
                SelectQuery.Append(" and banktype=@banktype");
            }
            NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());

            SelectCmd.Parameters.AddWithValue("@paymentdate", paymentdate);

            SelectCmd.Parameters.AddWithValue("@banktype", banktype);
            SelectCmd.Parameters.AddWithValue("@from", fromdate);
            if (!string.IsNullOrEmpty(todate))
            {
                SelectCmd.Parameters.AddWithValue("@to", Utility.pgsqlToDateFormat(todate));
            }
            DataTable dt = data.GetDataTable(SelectCmd, "nfs");

            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DataRow dr = dtforgrid.NewRow();
                    dr["moetype"] = "1";
                    dr["date"] = dt.Rows[i]["paymentdate"].ToString() ;
                    dr["cin"] = dt.Rows[i]["cin"];
                    dr["reportedby"] = "GSTN";
                    dr["gstnamt"] = dt.Rows[i]["sgst_total"].ToString();
                    dr["rbiamt"] = "---";
                    dr["status"] = dt.Rows[i]["status"].ToString();

                    if (dt.Rows[i]["status"].ToString() != "Not processed")
                    {
                        checkMoeCompct = true;
                    }
                    dtforgrid.Rows.Add(dr);

                    gstntotamt = gstntotamt + Convert.ToDecimal(dt.Rows[i]["sgst_total"].ToString());
                }
            }

            SelectQuery = new StringBuilder(@"select rbi.cin , sgst_total, totaltxnamt,to_char(rbi.paymentdatetime,'DD/MM/YYYY') as paymentdate, case COALESCE(mc.status,'0') when '0' then 'Not processed' else ms.statusdesc end as status from rbi_response_txns_details rbi
                                            inner join transactions_eod_cin eod on eod.cin=rbi.cin
                                            inner join master_gstn_banks mgb on mgb.bankcode=substring(rbi.cin from 1 for 4)
                                            left outer join moe_compact mc on mc.cin=rbi.cin
                                            left outer join master_status ms on ms.statuscode=mc.status
                                            where totaltxnamt<sgst_total  ");



            if (!string.IsNullOrEmpty(todate))
            {
                SelectQuery.Append("  and  rbi.paymentdatetime >= @from and rbi.paymentdatetime <= @to  ");
                fromdate = Utility.pgsqlFromDateFormat(paymentdate);
            }
            else
            {
                SelectQuery.Append("  and to_char(rbi.paymentdatetime,'DD/MM/YYYY')=@paymentdate ");
            }


            if (!string.IsNullOrEmpty(banktype))
            {
                SelectQuery.Append(" and banktype=@banktype");
            }

            SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
            SelectCmd.Parameters.AddWithValue("@paymentdate", paymentdate);
            SelectCmd.Parameters.AddWithValue("@banktype", banktype);
            SelectCmd.Parameters.AddWithValue("@from", fromdate);
            if (!string.IsNullOrEmpty(todate))
            {
                SelectCmd.Parameters.AddWithValue("@to", Utility.pgsqlToDateFormat(todate));
            }
            dt = data.GetDataTable(SelectCmd, "nfs");

            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DataRow dr = dtforgrid.NewRow();
                    dr["moetype"] = "4";
                    dr["date"] = dt.Rows[i]["paymentdate"].ToString(); 
                    dr["cin"] = dt.Rows[i]["cin"];
                    dr["reportedby"] = "BOTH";
                    dr["gstnamt"] = dt.Rows[i]["sgst_total"].ToString();
                    dr["rbiamt"] = dt.Rows[i]["totaltxnamt"].ToString();
                    dr["status"] = dt.Rows[i]["status"].ToString();
                    if (dt.Rows[i]["status"].ToString() != "Not processed")
                    {
                        checkMoeCompct = true;
                    }
                    dtforgrid.Rows.Add(dr);

                    gstntotamt = gstntotamt + Convert.ToDecimal(dt.Rows[i]["sgst_total"].ToString());
                    rbitotamt = rbitotamt + Convert.ToDecimal(dt.Rows[i]["totaltxnamt"].ToString());
                }
            }
        }

        if (src == "RAT" || src == "TOT")
        {

              if (src == "RAT")
            {
                whethercondition = " left outer join transactions_eod_cin tec on rbi.cin=tec.cin";
            }

              StringBuilder SelectQuery = new StringBuilder(@"select rbi.cin,totaltxnamt,to_char(rbi.paymentdatetime,'DD/MM/YYYY') as paymentdate,case COALESCE(mc.status,'0') when '0' then 'Not processed' else ms.statusdesc end as status from rbi_response_txns_details rbi 
                                                            inner join master_gstn_banks mgb on mgb.bankcode=substring(rbi.cin from 1 for 4)
                                                            left outer join moe_compact mc on mc.cin=rbi.cin
                                                            left outer join master_status ms on ms.statuscode=mc.status
                                                            " +whethercondition+@"
                                                            where  ");
            if (!string.IsNullOrEmpty(todate))
            {
                SelectQuery.Append("     rbi.paymentdatetime >= @from and rbi.paymentdatetime <= @to ");
                fromdate = Utility.pgsqlFromDateFormat(paymentdate);
            }
            else
            {
                SelectQuery.Append(" rbi.cin not in  (select cin from transactions_eod_cin where to_char(paymentdatetime,'DD/MM/YYYY')=@paymentdate) and to_char(rbi.paymentdatetime,'DD/MM/YYYY')=@paymentdate ");
            }
            


            if (src == "RAT")
            {
                SelectQuery.Append(" and tec.cin is null");
            }
            if (!string.IsNullOrEmpty(banktype))
            {
                SelectQuery.Append(" and banktype=@banktype");
            }


            NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
            SelectCmd.Parameters.AddWithValue("@paymentdate", paymentdate);
            SelectCmd.Parameters.AddWithValue("@banktype", banktype);
            SelectCmd.Parameters.AddWithValue("@from", fromdate);
            if (!string.IsNullOrEmpty(todate))
            {
                SelectCmd.Parameters.AddWithValue("@to", Utility.pgsqlToDateFormat(todate));
            }
            DataTable dt = data.GetDataTable(SelectCmd, "nfs");

            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DataRow dr = dtforgrid.NewRow();
                    dr["moetype"] = "2";
                    dr["date"] = dt.Rows[i]["paymentdate"].ToString(); 
                    dr["cin"] = dt.Rows[i]["cin"];
                    dr["reportedby"] = "RBI";
                    dr["gstnamt"] = "---";
                    dr["rbiamt"] = dt.Rows[i]["totaltxnamt"];
                    dr["status"] = dt.Rows[i]["status"].ToString();
                    if (dt.Rows[i]["status"].ToString() != "Not processed")
                    {
                        checkMoeCompct = true;
                    }
                    dtforgrid.Rows.Add(dr);

                    rbitotamt = rbitotamt + Convert.ToDecimal(dt.Rows[i]["totaltxnamt"].ToString());
                }
            }

            SelectQuery = new StringBuilder(@"select rbi.cin , sgst_total,to_char(rbi.paymentdatetime,'DD/MM/YYYY') as paymentdate, totaltxnamt,case  COALESCE(mc.status,'0') when '0' then 'Not processed' else ms.statusdesc end as status from rbi_response_txns_details  rbi
                                            inner join master_gstn_banks mgb on mgb.bankcode=substring(rbi.cin from 1 for 4)
                                            inner join transactions_eod_cin eod on eod.cin=rbi.cin 
                                            left outer join moe_compact mc on mc.cin=rbi.cin
                                            left outer join master_status ms on ms.statuscode=mc.status
                                            where rbi.isprocessed is null and totaltxnamt>sgst_total and to_char(rbi.paymentdatetime,'DD/MM/YYYY')=@paymentdate ");

            if (!string.IsNullOrEmpty(todate))
            {
                SelectQuery.Append("  and  rbi.paymentdatetime >= @from and rbi.paymentdatetime <= @to  ");
                fromdate = Utility.pgsqlFromDateFormat(paymentdate);
            }
            else
            {
                SelectQuery.Append("  and to_char(rbi.paymentdatetime,'DD/MM/YYYY')=@paymentdate ");
            }



            if (!string.IsNullOrEmpty(banktype))
            {
                SelectQuery.Append(" and banktype=@banktype");
            }

            SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
            SelectCmd.Parameters.AddWithValue("@paymentdate", paymentdate);
            SelectCmd.Parameters.AddWithValue("@banktype", banktype);
            SelectCmd.Parameters.AddWithValue("@from", fromdate);
            if (!string.IsNullOrEmpty(todate))
            {
                SelectCmd.Parameters.AddWithValue("@to", Utility.pgsqlToDateFormat(todate));
            }
            dt = data.GetDataTable(SelectCmd, "nfs");

            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DataRow dr = dtforgrid.NewRow();
                    dr["moetype"] = "3";
                    dr["date"] = dt.Rows[i]["paymentdate"].ToString(); 
                    dr["cin"] = dt.Rows[i]["cin"];
                    dr["reportedby"] = "BOTH";
                    dr["gstnamt"] = dt.Rows[i]["sgst_total"];
                    dr["rbiamt"] = dt.Rows[i]["totaltxnamt"];
                    dtforgrid.Rows.Add(dr);
                    dr["status"] = dt.Rows[i]["status"].ToString();
                    if (dt.Rows[i]["status"].ToString() != "Not processed")
                    {
                        checkMoeCompct = true;
                    }

                    gstntotamt = gstntotamt + Convert.ToDecimal(dt.Rows[i]["sgst_total"].ToString());
                    rbitotamt = rbitotamt + Convert.ToDecimal(dt.Rows[i]["totaltxnamt"].ToString());
                }
            }
        }

        if (dtforgrid.Rows.Count > 0)
        {
            imgbtndownload.Visible = true;
            dtforgrid.DefaultView.Sort = "[date] ASC";

            grdgstfiles.DataSource = dtforgrid;
            grdgstfiles.DataBind();

            grdgstfiles.FooterRow.Cells[3].Text = "Total";
            grdgstfiles.FooterRow.Cells[3].HorizontalAlign = HorizontalAlign.Right;
            grdgstfiles.FooterRow.Cells[3].Font.Bold = true;
            grdgstfiles.FooterRow.Cells[4].Text = gstntotamt.ToString("N2");
            grdgstfiles.FooterRow.Cells[4].HorizontalAlign = HorizontalAlign.Right;
            grdgstfiles.FooterRow.Cells[4].Font.Bold = true;
            grdgstfiles.FooterRow.Cells[5].Text = rbitotamt.ToString("N2");
            grdgstfiles.FooterRow.Cells[5].HorizontalAlign = HorizontalAlign.Right;
            grdgstfiles.FooterRow.Cells[5].Font.Bold = true;


            if (src == "TOT" && checkMoeCompct == false)
            {
                btnGenerate.Visible = true;
            }
        }
        else
        {
            imgbtndownload.Visible = false;
        }
        
    }
    protected void imgbtndownload_Click(object sender, ImageClickEventArgs e)
    {
        fillgrid();
        Exportfile exp = new Exportfile();
        exp.exportprintgrd(grdgstfiles, "UnmatchedRecords");
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
           server control at run time. */
    }
    protected void imgbtnback_Click(object sender, ImageClickEventArgs e)
    {
        if (ViewState["PreviousPage"] != null)	//Check if the ViewState 
        //contains Previous page URL
        {
            Response.Redirect(ViewState["PreviousPage"].ToString()+"?status="+MD5Util.Encrypt("S",true)+"");//Redirect to 
            //Previous page by retrieving the PreviousPage Url from ViewState.
            //Server.Transfer((ViewState["PreviousPage"].ToString()));//Redirect to 
        }

    }
    protected void btnGenerate_Click(object sender, EventArgs e)
    {
        List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
        string Qry = @"INSERT INTO moe_compact(cin, status, userid, ipaddress, insertdatetime,moetype)
                                    VALUES (@cin, @status, @userid, @ipaddress, now(), @moetype);";
        string ipaddrs = PostgresGetData.GetIP4Address();
        string moetype = string.Empty;
        foreach (GridViewRow row in grdgstfiles.Rows)
        {
            moetype = (string)grdgstfiles.DataKeys[row.RowIndex]["moetype"];
            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
            cmd.Parameters.AddWithValue("@cin", ((Label)row.FindControl("lblcin")).Text);
            cmd.Parameters.AddWithValue("@status", "M");
            //cmd.Parameters.AddWithValue("@filedate", Utility.converttodate_from_DDMMYYYY(dt.Rows[i]["filedate"].ToString()));
            cmd.Parameters.AddWithValue("@userid", Session["USER_ID"].ToString());
            cmd.Parameters.AddWithValue("@ipaddress", ipaddrs);
            cmd.Parameters.AddWithValue("@moetype", moetype);
            cmdList.Add(cmd);
        }

        int savedrec = data.SaveData(cmdList, "nfs");
        if (savedrec > 0)
        {
            //string script = "<script type='text/javascript'>alert('Action completed successfully.');window.location='../Moe/CinConsiderForMoe.aspx';</script>";
            //ClientScript.RegisterStartupScript(GetType(), "Message", script);

            Response.Redirect("../Moe/CinConsiderForMoe.aspx");
        }
    }


  

    

}