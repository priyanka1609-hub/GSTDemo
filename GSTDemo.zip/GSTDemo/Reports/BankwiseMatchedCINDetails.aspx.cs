﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;

public partial class Reports_BankwiseMatchedCINDetails : System.Web.UI.Page
{
    MD5Util md5util = new MD5Util();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) 
        {
            ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState
            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                
                    fillgrid();
                

                if (Request.QueryString["dtf"] != null)
                {
                    lblpymtdate.Text = MD5Util.Decrypt(Request.QueryString["dtf"].ToString(), true);
                }
                if (Request.QueryString["dtto"] != null)
                {
                    lblTodate.Text = MD5Util.Decrypt(Request.QueryString["dtto"].ToString(), true);
                }
            }
            
        }
    }




    private void fillgrid()
    {
        string frcid = string.Empty, banktype = string.Empty, paymentdate = string.Empty, paymentdate1 = string.Empty, paymentdate2 = string.Empty, BankCode = string.Empty;
        
        if (Request.QueryString["dtf"] != null)
        {
            paymentdate1 = MD5Util.Decrypt(Request.QueryString["dtf"].ToString(), true);
        }
        if (Request.QueryString["dtto"] != null)
        {
            paymentdate2 = MD5Util.Decrypt(Request.QueryString["dtto"].ToString(), true);
        }

        if (Request.QueryString["BankCode"] != null)
        {
            BankCode = MD5Util.Decrypt(Request.QueryString["BankCode"].ToString(), true);
        }
        

        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"SELECT eodcinid, gstin, temp_id, eod.cpin, to_char(cpindatetime,'DD/MM/YYYY HH:MI:SS') cpindatetime, pm.modedesc, sgst_tax, 
                                                       sgst_intr, sgst_fee, sgst_pnlty, sgst_oth, sgst_total, eod.cin, eod.txnid, 
                                                       utr_num, ack_num, bank_ref_num, eod.status, total_amt, to_char(eod.paymentdatetime,'DD/MM/YYYY HH:MI:SS') paymentdatetime,
                                                       it.desc as instdesc, mgb.bankname, br_ifsc_cd, br_location, 
                                                       br_name, instrument_no, instrument_micr_cd, to_char(pymntackdatetime,'DD/MM/YYYY HH:MI:SS') pymntackdatetime, 
                                                       to_char(reportingdatetime,'DD/MM/YYYY HH:MI:SS') reportingdatetime, frcid, ms.statusdesc as rconstatus
                                                         FROM transactions_eod_cin eod
                                                        inner join master_gstn_banks mgb on mgb.bankcode=eod.bank_cd
                                                        inner join master_gstn_pay_mode pm on pm.mode=eod.mode
	
							                            inner join rbi_response_txns_details rbi on rbi.cin = eod.cin
                                                        left outer join master_instrument_types it on it.code = eod.instrument_ty
                                                        left outer join moe_compact mc on mc.cin=eod.cin                                
                                                       left outer join master_status ms on ms.statuscode=mc.status
                                                        where 1=1 and sgst_total != 0.00 and sgst_total=totaltxnamt");

       

        if (!string.IsNullOrEmpty(paymentdate1))
        {
            SelectQuery.Append(" and rbi.paymentdatetime >= @paymentdate1");
        }
        if (!string.IsNullOrEmpty(paymentdate2))
        {
            SelectQuery.Append(" and rbi.paymentdatetime <= @paymentdate2");
        }
        if (!string.IsNullOrEmpty(BankCode))
        {
            SelectQuery.Append(" and bankcode=@BankCode");
        }

        SelectQuery.Append(" order by paymentdatetime");


        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        


        if (!string.IsNullOrEmpty(paymentdate1))
        {
            SelectCmd.Parameters.AddWithValue("@paymentdate1", Utility.pgsqlFromDateFormat(paymentdate1));
        }
        if (!string.IsNullOrEmpty(paymentdate2))
        {
            SelectCmd.Parameters.AddWithValue("@paymentdate2", Utility.pgsqlToDateFormat(paymentdate2));
        }
        if (!string.IsNullOrEmpty(BankCode))
        {
            SelectCmd.Parameters.AddWithValue("@BankCode", BankCode);
        }

        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
        imgbtndownload.Visible = true;
        //tbldate.Visible = true;
        grdgstfiles.DataSource = dt;
        grdgstfiles.DataBind();

    }
    protected void imgbtnback_Click(object sender, ImageClickEventArgs e)
    {
        if (ViewState["PreviousPage"] != null)	//Check if the ViewState 
        //contains Previous page URL
        {
            Response.Redirect(ViewState["PreviousPage"].ToString());//Redirect to 
            //Previous page by retrieving the PreviousPage Url from ViewState.
        }
    }
    protected void imgbtndownload_Click(object sender, ImageClickEventArgs e)
    {
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=Gstntxndetails.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        StringWriter sw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(sw);
        hw.AddStyleAttribute("horizontal-align", "center");
        hw.Write("GSTN Transaction Details <br/><br/>");
        grdgstfiles.RenderControl(hw);
        StringReader sr = new StringReader(sw.ToString());
        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        htmlparser.Parse(sr);
        pdfDoc.Close();
        Response.Write(pdfDoc);
        Response.End();

    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
           server control at run time. */
    }
}