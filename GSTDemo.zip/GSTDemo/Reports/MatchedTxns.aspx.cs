﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Threading;
using System.Globalization;
public partial class Reports_MatchedTxns : System.Web.UI.Page
{
    public decimal totalgstn = 0, totalrbi = 0;
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    public string date;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            ViewState["PreviousPage"] = Request.UrlReferrer;

            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Logout.aspx");
                }
            }
        }
        // showData();

        if (Request.QueryString["dt"] != null)
        {
            trselectdate.Visible = false;
            date = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true);
           

            if (Request.QueryString["tntype"] != null)
            {
                //btnGenerate.Visible = false;
                if (Session["USER_TYPE"].ToString() == "PAO")
                {
                    string tntype = MD5Util.Decrypt(Request.QueryString["tntype"].ToString(), true);
                    if (tntype.ToString() == "N")
                    {
                        StringBuilder SelectchcQuery = new StringBuilder(@"select cfileid from compact_files where to_char(paymentdate,'DD/MM/YYYY')=@date  ");
                        NpgsqlCommand SelectchckCmd = new NpgsqlCommand(SelectchcQuery.ToString());
                        SelectchckCmd.Parameters.AddWithValue("@date", date);
                        DataTable dtchck = data.GetDataTable(SelectchckCmd, "nfs");
                        if (dtchck.Rows.Count == 0)
                        {
                            btnGenerate.Visible = true;
                        }

                    }
                }
                fillgrid(date, "");
            }
            else if (Request.QueryString["banktype"] != null)
            {
                fillgrid(date, MD5Util.Decrypt(Request.QueryString["banktype"].ToString(), true));

            }
            else
            {
                fillgrid(date, "");
            }
        }

        

    }

    private void fillgrid(string srchdate, string banktype)
    {
        
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select rbi.cin,sgst_total,totaltxnamt,tec.cpin,to_char(tec.paymentdatetime,'DD/MM/YYYY') cindategstn,to_char(rbi.paymentdatetime,'DD/MM/YYYY') cindaterbi, to_char(reportingdatetime,'DD/MM/YYYY HH:MI:SS') gstnreportedtime, to_char(accptncdttm,'DD/MM/YYYY HH:MI:SS') as rbireportedtime,mgb.bankname from rbi_response_txns_details rbi
                                                        inner join transactions_eod_cin tec on tec.cin = rbi.cin 
                                                        inner join master_gstn_banks mgb on mgb.bankcode=tec.bank_cd
                                                        where to_char(rbi.paymentdatetime,'DD/MM/YYYY')=@date  ");

        //if (!String.IsNullOrEmpty(banktype) && banktype.ToString() != "N")
        //{

        //    if (banktype == "O" )
        //    {
        //        SelectQuery.Append(" and mgb.banktype in ('G','P')  ");
        //    }
        //    else
        //    {
        //        SelectQuery.Append(" and mgb.banktype=@banktype  ");
        //    }
        //}
        if (!String.IsNullOrEmpty(banktype))
        {
            SelectQuery.Append(" and mgb.banktype=@banktype ");
        }
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@date", srchdate);
        SelectCmd.Parameters.AddWithValue("@banktype", banktype);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        if (dt.Rows.Count > 0)
        {
            
            trdate.Visible = true;
            lblpymtdate.Text = srchdate;
            trgrid.Visible = true;
            grdmatchedtxns.DataSource = dt;
            grdmatchedtxns.DataBind();
        }
        else
        {
            
            trdate.Visible = false;
            trgrid.Visible = false;

            msg.Show("No Data found for this Date");

        }
    }
    protected void btnshowdata_Click(object sender, EventArgs e)
    {
        fillgrid(txtdate.Text,"");
    }


    protected void imgbtndownload_Click(object sender, ImageClickEventArgs e)
    {
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=MatchedTxns.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        StringWriter sw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(sw);
        hw.AddStyleAttribute("horizontal-align", "center");
        hw.Write("Matched Transactions for the Date : " + lblpymtdate.Text + "<br/><br/>");
        grdmatchedtxns.RenderControl(hw);
        StringReader sr = new StringReader(sw.ToString());
        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        htmlparser.Parse(sr);
        pdfDoc.Close();
        Response.Write(pdfDoc);
        Response.End();
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
           server control at run time. */
    }
    protected void btnGenerate_Click(object sender, EventArgs e)
    {
        //if (Request.QueryString["dt"] != null)
        //{
        //   string date = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true);
        //   string url = md5util.CreateTamperProofURL("../Compact/GenerateCompact.aspx", null, "dt=" + MD5Util.Encrypt(date, true));
        //    Response.Redirect(url);
        //}

        try
        {     
                string ipaddrs = PostgresGetData.GetIP4Address();

                //StringBuilder SelectQuery = new StringBuilder(@"select lpad((count(cfileid)+1)::text, 2, '0') seq from compact_files where to_char(insertdatetime,'DD/MM/YYYY')=@date");
                //NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
                //SelectCmd.Parameters.AddWithValue("@date", DateTime.Now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture));
                //DataTable dtcount = data.GetDataTable(SelectCmd, "nfs");
                //string filename = DateTime.Now.ToString("ddMMyyyy", CultureInfo.InvariantCulture) + dtcount.Rows[0]["seq"].ToString() + ".txt";

                string insrtQ = @"INSERT INTO compact_files(filename,insertdatetime, userid, ip,paymentdate)
                                    VALUES (@filename,now(),@userid,@ip,@paymentdate); select lastval();";

                NpgsqlCommand cmdinsrtQ = new NpgsqlCommand(insrtQ);
                cmdinsrtQ.Parameters.AddWithValue("@filename", "");
                cmdinsrtQ.Parameters.AddWithValue("@userid", Session["USER_ID"].ToString());
                cmdinsrtQ.Parameters.AddWithValue("@ip", ipaddrs);
                cmdinsrtQ.Parameters.AddWithValue("@paymentdate", Utility.converttodate_from_DDMMYYYY(lblpymtdate.Text));

                int insertedRec = data.UpdateScalarData(cmdinsrtQ, "nfs");

                if (insertedRec > 0)
                {

                    List<NpgsqlCommand> cmdList = new List<NpgsqlCommand>();
                    string Qry = @"INSERT INTO public.moe_compact(cin, status, userid, ipaddress, insertdatetime,compactfileid)
                                    VALUES (@cin, @status, @userid, @ipaddress, now(), @compactfileid);";
                    foreach (GridViewRow row in grdmatchedtxns.Rows)
                    {
                        Label lblcin = (Label)row.FindControl("lblcin");

                            NpgsqlCommand cmd = new NpgsqlCommand(Qry);
                            cmd.Parameters.AddWithValue("@cin", lblcin.Text);
                            cmd.Parameters.AddWithValue("@status", "C");
                            //cmd.Parameters.AddWithValue("@filedate", Utility.converttodate_from_DDMMYYYY(dt.Rows[i]["filedate"].ToString()));
                            cmd.Parameters.AddWithValue("@userid", Session["USER_ID"].ToString());
                            cmd.Parameters.AddWithValue("@ipaddress", ipaddrs);
                            cmd.Parameters.AddWithValue("@compactfileid", insertedRec);
                            cmdList.Add(cmd);

                            //StringBuilder updateqry = new StringBuilder(@"update transactions_eod_cin set isprocessed=@isprocessed where cin=@cin ;");
                            //NpgsqlCommand Up1cmd = new NpgsqlCommand(updateqry.ToString());
                            //Up1cmd.Parameters.AddWithValue("@isprocessed", "Y");
                            //Up1cmd.Parameters.AddWithValue("@cin", dt.Rows[i]["cin"].ToString());
                            //cmdList.Add(Up1cmd);

                            //updateqry = new StringBuilder(@"update rbi_response_txns_details set isprocessed=@isprocessed where cin=@cin ;");
                            //Up1cmd = new NpgsqlCommand(updateqry.ToString());
                            //Up1cmd.Parameters.AddWithValue("@isprocessed", "Y");
                            //Up1cmd.Parameters.AddWithValue("@cin", dt.Rows[i]["cin"].ToString());
                            //cmdList.Add(Up1cmd);

                        }

                    int savedrec = data.SaveData(cmdList, "nfs");

                    if (savedrec > 0)
                    {

                        StringBuilder updateqry = new StringBuilder(@"update compact_files set completed=@completed where cfileid=@cfileid ;");
                        NpgsqlCommand Up1cmd = new NpgsqlCommand(updateqry.ToString());
                        Up1cmd.Parameters.AddWithValue("@completed", "Y");
                        Up1cmd.Parameters.AddWithValue("@cfileid", insertedRec);
                        int updatedRec = data.UpdateData(Up1cmd, "nfs");

                        if (updatedRec > 0)
                        {
                            //System.IO.FileStream fs = null;
                            //fs = System.IO.File.Open(path + filename, System.IO.FileMode.Open);
                            //byte[] btFile = new byte[fs.Length];
                            //fs.Read(btFile, 0, Convert.ToInt32(fs.Length));
                            //fs.Close();
                            //Response.AddHeader("Content-disposition", "attachment; filename=" + filename);
                            //Response.ContentType = "application/octet-stream";
                            //Response.BinaryWrite(btFile);
                            //Response.End();

                            string url = md5util.CreateTamperProofURL("../Reports/AfterReconciliation.aspx", null, "dt=" + MD5Util.Encrypt(lblpymtdate.Text, true));
                            Response.Redirect(url);

                           // msg.Show("Data Updated");
                        }
                    }
                }
            
        }
        catch (ThreadAbortException ex1)
        {
            // do nothing
        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
        }


    }
    protected void gvpayday_rowdatabound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label lblgstnamt = (Label)e.Row.FindControl("lblgstnamount");
            Label lblrbiamt = (Label)e.Row.FindControl("lblrbiamount");
            decimal gstntotalamt = decimal.Parse(lblgstnamt.Text);
            decimal rbitotalamount = decimal.Parse(lblrbiamt.Text);
            totalrbi += rbitotalamount;
            totalgstn += gstntotalamt;

        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            Label lblgstn = (Label)e.Row.FindControl("lblgstn");
            Label lblrbi = (Label)e.Row.FindControl("lblrbi");

            lblgstn.Text = totalgstn.ToString();
            lblrbi.Text = totalrbi.ToString();

        }
    }
    protected void imgbtnback_Click(object sender, ImageClickEventArgs e)
    {
        if (ViewState["PreviousPage"] != null)	//Check if the ViewState 
        //contains Previous page URL
        {
            
            Response.Redirect(ViewState["PreviousPage"].ToString());//Redirect to 
            //Previous page by retrieving the PreviousPage Url from ViewState.
        }
    }
}