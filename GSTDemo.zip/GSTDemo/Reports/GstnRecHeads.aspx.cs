﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;

public partial class Reports_GstnRecHeads : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    public string datechck, fromdatecurrent = string.Empty, todatecurrent=string.Empty;

    protected DataTable dtforgrid;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            //ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState

            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Logout.aspx");
                }
            }
             todatecurrent = DateTime.Now.ToString("dd/MM/yyyy");
             fromdatecurrent = "01/" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.ToString("yyyy");
            txtfromdate.Text = fromdatecurrent.Replace("-", "/");
            txttodate.Text = todatecurrent.Replace("-", "/");


        }
        try { datechck = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true); }
        catch { datechck = string.Empty; }

        if (string.IsNullOrEmpty(datechck))
        {
            // showData();
          
            fillgrid(fromdatecurrent, todatecurrent);

        }
        else
        {
            fromtodate.Visible = false;
            fillgrid("", "");

        }


    }

    protected void fillgrid(string from, string to)
    {
        string date = string.Empty; string fromdate = string.Empty;

        Double amtpsb = 0.00d, amtpvt = 0.00d, amtner = 0.00d, tax = 0.00d, intr = 0.00d, fee = 0.00d, pnlty = 0.00d, oth = 0.00d;
        int nertxns = 0, psbtxns = 0, pvttxns = 0;
        StringBuilder SelectQuery = new StringBuilder(@"select cin,mode,sgst_total,to_char(paymentdatetime,'DD/MM/YYYY') payment_dt,paymentdatetime ,banktype,sgst_tax,sgst_intr,sgst_pnlty,sgst_fee,sgst_oth
                                                        from transactions_eod_cin tec 
                                                        inner join master_gstn_banks mgb on mgb.bankcode=tec.bank_cd
                                                        where sgst_total != 0.00 ");

        if (Request.QueryString["dt"] != null)
        {
            date = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true);

            SelectQuery.Append(" and to_char(tec.paymentdatetime,'DD/MM/YYYY')=@paymentdatetime ");
        }
        else
        {
            SelectQuery.Append(" and tec.paymentdatetime >= @from and tec.paymentdatetime <= @to");
            fromdate = Utility.pgsqlFromDateFormat(from);
        }

        SelectQuery.Append(" order by paymentdatetime");

        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdatetime", date);
        SelectCmd.Parameters.AddWithValue("@from", fromdate);
        SelectCmd.Parameters.AddWithValue("@to", Utility.pgsqlToDateFormat(to));
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        if (dt.Rows.Count > 0)
        {
            dtforgrid = new DataTable();
            dtforgrid.Clear();
            dtforgrid.Columns.Add("date");
            dtforgrid.Columns.Add("psbtxns");
            dtforgrid.Columns.Add("psbamt");
            dtforgrid.Columns.Add("pvttxns");
            dtforgrid.Columns.Add("psbpvtamt");
            dtforgrid.Columns.Add("psbpvttxns");
            dtforgrid.Columns.Add("pvtamt");
            dtforgrid.Columns.Add("nertxns");
            dtforgrid.Columns.Add("neramt");
            dtforgrid.Columns.Add("totamt");
            dtforgrid.Columns.Add("tottxns");
            dtforgrid.Columns.Add("tax");
            dtforgrid.Columns.Add("intr");
            dtforgrid.Columns.Add("fee");
            dtforgrid.Columns.Add("pnlty");
            dtforgrid.Columns.Add("oth");
            dtforgrid.Columns.Add("minortotamt");


            int i;
            int dtrowscount = dt.Rows.Count;
            for (i = 0; i < dtrowscount; i++)
            {
                if (i == 0)
                {
                    if (dt.Rows[0]["banktype"].ToString() == "R")
                    {
                        amtner = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                        nertxns++;
                    }
                    else if (dt.Rows[0]["banktype"].ToString() == "G")
                    {
                        amtpsb = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                        tax = Convert.ToDouble(dt.Rows[0]["sgst_tax"].ToString());
                        intr = Convert.ToDouble(dt.Rows[0]["sgst_intr"].ToString());
                        fee = Convert.ToDouble(dt.Rows[0]["sgst_fee"].ToString());
                        pnlty = Convert.ToDouble(dt.Rows[0]["sgst_pnlty"].ToString());
                        oth = Convert.ToDouble(dt.Rows[0]["sgst_oth"].ToString());
                        psbtxns++;

                    }
                    else if (dt.Rows[0]["banktype"].ToString() == "P")
                    {
                        amtpvt = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                        tax = Convert.ToDouble(dt.Rows[0]["sgst_tax"].ToString());
                        intr = Convert.ToDouble(dt.Rows[0]["sgst_intr"].ToString());
                        fee = Convert.ToDouble(dt.Rows[0]["sgst_fee"].ToString());
                        pnlty = Convert.ToDouble(dt.Rows[0]["sgst_pnlty"].ToString());
                        oth = Convert.ToDouble(dt.Rows[0]["sgst_oth"].ToString());
                        pvttxns++;

                    }

                }
                else
                {
                    if (dt.Rows[i]["payment_dt"].ToString() == dt.Rows[i - 1]["payment_dt"].ToString())
                    {
                        if (dt.Rows[i]["banktype"].ToString() == "R")
                        {
                            double newamtner = amtner + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtner = newamtner;
                            //amtner = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            nertxns++;
                        }
                        else if (dt.Rows[i]["banktype"].ToString() == "G")
                        {
                            double newamtpsb = amtpsb + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtpsb = newamtpsb;
                            //amtpsb = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            psbtxns++;

                            double newtax = tax + Convert.ToDouble(dt.Rows[i]["sgst_tax"].ToString());
                            tax = newtax;
                            double newintr = intr + Convert.ToDouble(dt.Rows[i]["sgst_intr"].ToString());
                            intr = newintr;
                            double newfee = fee + Convert.ToDouble(dt.Rows[i]["sgst_fee"].ToString());
                            fee = newfee;
                            double newpnlty = pnlty + Convert.ToDouble(dt.Rows[i]["sgst_pnlty"].ToString());
                            pnlty = newpnlty;
                            double newoth = oth + Convert.ToDouble(dt.Rows[i]["sgst_oth"].ToString());
                            oth = newoth;

                        }
                        else if (dt.Rows[i]["banktype"].ToString() == "P")
                        {
                            double newamtpvt = amtpvt + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtpvt = newamtpvt;

                            //amtpvt = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            pvttxns++;

                            double newtax = tax + Convert.ToDouble(dt.Rows[i]["sgst_tax"].ToString());
                            tax = newtax;
                            double newintr = intr + Convert.ToDouble(dt.Rows[i]["sgst_intr"].ToString());
                            intr = newintr;
                            double newfee = fee + Convert.ToDouble(dt.Rows[i]["sgst_fee"].ToString());
                            fee = newfee;
                            double newpnlty = pnlty + Convert.ToDouble(dt.Rows[i]["sgst_pnlty"].ToString());
                            pnlty = newpnlty;
                            double newoth = oth + Convert.ToDouble(dt.Rows[i]["sgst_oth"].ToString());
                            oth = newoth;

                        }
                    }
                    else
                    {
                        DataRow dr = dtforgrid.NewRow();
                        dr["date"] = dt.Rows[i - 1]["payment_dt"];
                        dr["psbtxns"] = psbtxns.ToString();
                        dr["psbamt"] = amtpsb.ToString("F2");
                        dr["pvttxns"] = pvttxns.ToString();
                        dr["pvtamt"] = amtpvt.ToString("F2");
                        dr["psbpvttxns"] = (psbtxns + pvttxns).ToString();
                        dr["psbpvtamt"] = (amtpsb + amtpvt).ToString("F2");
                        dr["nertxns"] = nertxns.ToString();
                        dr["neramt"] = amtner.ToString("F2");
                        dr["totamt"] = (amtpsb + amtpvt + amtner).ToString("F2");
                        dr["tottxns"] = (psbtxns + pvttxns + nertxns).ToString();
                        dr["tax"] = tax.ToString("F2");
                        dr["intr"] = intr.ToString("F2");
                        dr["fee"] = fee.ToString("F2");
                        dr["pnlty"] = pnlty.ToString("F2");
                        dr["oth"] = oth.ToString("F2");
                        dr["minortotamt"] = (tax + intr + fee + pnlty + oth).ToString("F2");


                        dtforgrid.Rows.Add(dr);

                        amtner = 0.00d;
                        amtpsb = 0.00d;
                        amtpvt = 0.00d;
                        tax = 0.00d;
                        intr = 0.00d;
                        fee = 0.00d;
                        pnlty = 0.00d;
                        oth = 0.00d;
                        nertxns = 0;
                        psbtxns = 0;
                        pvttxns = 0;

                        if (dt.Rows[i]["banktype"].ToString() == "R")
                        {
                            double newamtner = amtner + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtner = newamtner;
                            //amtner = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            nertxns++;
                        }
                        else if (dt.Rows[i]["banktype"].ToString() == "G")
                        {
                            double newamtpsb = amtpsb + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtpsb = newamtpsb;
                            //amtpsb = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            psbtxns++;

                            double newtax = tax + Convert.ToDouble(dt.Rows[i]["sgst_tax"].ToString());
                            tax = newtax;
                            double newintr = intr + Convert.ToDouble(dt.Rows[i]["sgst_intr"].ToString());
                            intr = newintr;
                            double newfee = fee + Convert.ToDouble(dt.Rows[i]["sgst_fee"].ToString());
                            fee = newfee;
                            double newpnlty = pnlty + Convert.ToDouble(dt.Rows[i]["sgst_pnlty"].ToString());
                            pnlty = newpnlty;
                            double newoth = oth + Convert.ToDouble(dt.Rows[i]["sgst_oth"].ToString());
                            oth = newoth;

                        }
                        else if (dt.Rows[i]["banktype"].ToString() == "P")
                        {
                            double newamtpvt = amtpvt + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtpvt = newamtpvt;

                            //amtpvt = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            pvttxns++;

                            double newtax = tax + Convert.ToDouble(dt.Rows[i]["sgst_tax"].ToString());
                            tax = newtax;
                            double newintr = intr + Convert.ToDouble(dt.Rows[i]["sgst_intr"].ToString());
                            intr = newintr;
                            double newfee = fee + Convert.ToDouble(dt.Rows[i]["sgst_fee"].ToString());
                            fee = newfee;
                            double newpnlty = pnlty + Convert.ToDouble(dt.Rows[i]["sgst_pnlty"].ToString());
                            pnlty = newpnlty;
                            double newoth = oth + Convert.ToDouble(dt.Rows[i]["sgst_oth"].ToString());
                            oth = newoth;

                        }

                    }
                }

            }


            DataRow droneorlast = dtforgrid.NewRow();
            droneorlast["date"] = dt.Rows[i - 1]["payment_dt"];
            droneorlast["psbtxns"] = psbtxns.ToString();
            droneorlast["psbamt"] = amtpsb.ToString("F2");
            droneorlast["pvttxns"] = pvttxns.ToString();
            droneorlast["pvtamt"] = amtpvt.ToString("F2");
            droneorlast["psbpvttxns"] = (psbtxns + pvttxns).ToString();
            droneorlast["psbpvtamt"] = (amtpsb + amtpvt).ToString("F2");
            droneorlast["nertxns"] = nertxns.ToString();
            droneorlast["neramt"] = amtner.ToString("F2");
            droneorlast["totamt"] = (amtpsb + amtpvt + amtner).ToString("F2");
            droneorlast["tottxns"] = (psbtxns + pvttxns + nertxns).ToString();
            droneorlast["tax"] = tax.ToString("F2");
            droneorlast["intr"] = intr.ToString("F2");
            droneorlast["fee"] = fee.ToString("F2");
            droneorlast["pnlty"] = pnlty.ToString("F2");
            droneorlast["oth"] = oth.ToString("F2");
            droneorlast["minortotamt"] = (tax + intr + fee + pnlty + oth).ToString("F2");
            dtforgrid.Rows.Add(droneorlast);
            ViewState["data"] = dtforgrid;


        }

    }

    protected string ReturnURl(string rowDate)
    {

        return md5util.CreateTamperProofURL("../Reports/MinorHeadReport.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true));
    }



    protected string gstnTxnDetails(string rowDate, string mode)
    {
        return md5util.CreateTamperProofURL("../Reports/GstnEodcinDetails.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true) + "&banktype=" + MD5Util.Encrypt(mode, true));
    }


    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
           server control at run time. */
    }
    protected void imgbtnback_Click(object sender, ImageClickEventArgs e)
    {
        //if (ViewState["PreviousPage"] != null)	//Check if the ViewState 
        ////contains Previous page URL
        //{
        //Response.Redirect("../Reports/HeadwiseReport.aspx");//Redirect to 
        Response.Redirect("../PAO/DefaultHome.aspx");//Redirect to 
        //Previous page by retrieving the PreviousPage Url from ViewState.
        //}
    }
    protected void imgbtndownload_Click(object sender, ImageClickEventArgs e)
    {
        //Response.ContentType = "application/pdf";

        //Response.AddHeader("content-disposition", "attachment;filename=Panel.pdf");

        //Response.Cache.SetCacheability(HttpCacheability.NoCache);

        //StringWriter sw = new StringWriter();

        //HtmlTextWriter hw = new HtmlTextWriter(sw);

        //tbldata.RenderControl(hw);

        //StringReader sr = new StringReader(sw.ToString());

        //Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 100f, 0f);

        //HTMLWorker htmlparser = new HTMLWorker(pdfDoc);

        //PdfWriter.GetInstance(pdfDoc, Response.OutputStream);

        //pdfDoc.Open();

        //htmlparser.Parse(sr);

        //pdfDoc.Close();

        //Response.Write(pdfDoc);

        //Response.End();
        fillgrid(txtfromdate.Text, txttodate.Text);
        Exportfile exp = new Exportfile();
        exp.exportprint(tbldata,"GSTN DATA");
    }
    protected void btnshowdata_Click(object sender, EventArgs e)
    {
        lblheading.Text = "From " + txtfromdate.Text + " TO " + txttodate.Text;
        gstndetails.Visible = true;
        fillgrid(txtfromdate.Text, txttodate.Text);
    }

}