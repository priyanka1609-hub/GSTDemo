﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;
using System.Threading;

public partial class Reports_RbiDownloadedFiles : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    public string datechck;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try { datechck = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true); }
            catch { datechck = string.Empty; }

            if (string.IsNullOrEmpty(datechck))
            {
                // showData();
                string todatecurrent = DateTime.Now.ToString("dd/MM/yyyy");
                string fromdatecurrent = "01/" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.ToString("yyyy");
                txtfromdate.Text = fromdatecurrent.Replace("-", "/");
                txttodate.Text = todatecurrent.Replace("-", "/");
                fillgrid(fromdatecurrent, todatecurrent);

            }
            else
            {
                fromtodate.Visible = false;
                fillgrid("", "");

            }
        }
    }

    private void fillgrid(string from, string to)
    {
        string fromdate = string.Empty;
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select count(headerid) filecount,to_char(scrolldate,'DD/MM/YYYY') filedate 
                                                        from rbi_response_header ");
        if (!string.IsNullOrEmpty(from))
        {
            SelectQuery.Append(" where scrolldate >= @from and scrolldate <= @to");
            fromdate = Utility.pgsqlFromDateFormat(from);
        }
        SelectQuery.Append("   group by  to_char(scrolldate,'DD/MM/YYYY') order by filedate desc");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@from", fromdate);
        SelectCmd.Parameters.AddWithValue("@to", Utility.pgsqlToDateFormat(to));
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        grdrbifiles.DataSource = dt;
        grdrbifiles.DataBind();
    }

    //protected void grdrbifiles_RowDataBound(object sender, GridViewRowEventArgs e)
    //{

    //    if (e.Row.RowType == DataControlRowType.DataRow)
    //    {

    //        string id = grdrbifiles.DataKeys[e.Row.RowIndex].Values["filedate"].ToString();
    //        HyperLink hylnktxns = (HyperLink)e.Row.FindControl("hylnktxns");
    //        hylnktxns.NavigateUrl = md5util.CreateTamperProofURL("~/Reports/RbiScrollDetails.aspx", null, "filedt=" + MD5Util.Encrypt(id, true));
    //    }

    //}
    protected void grdrbifiles_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            string id = grdrbifiles.DataKeys[e.Row.RowIndex].Values["filedate"].ToString();
            HyperLink hylnktxns = (HyperLink)e.Row.FindControl("hylnktxns");
            hylnktxns.NavigateUrl = md5util.CreateTamperProofURL("~/Reports/RbiFileDetails.aspx", null, "filedt=" + MD5Util.Encrypt(id, true));
        }

    }
    protected void btnshowdata_Click(object sender, EventArgs e)
    {
        fillgrid(txtfromdate.Text, txttodate.Text);
    }
    //protected void grdrbifiles_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    if (e.CommandName == "download")
    //    {
    //        LinkButton lnkView = (LinkButton)e.CommandSource;
    //        GridViewRow myRow = (GridViewRow)lnkView.Parent.Parent;  // the row
    //        GridView myGrid = (GridView)sender;
    //        string filedate = myGrid.DataKeys[myRow.RowIndex].Values["filedate"].ToString();

    //        try
    //        {
    //            string filename = "CNV6075001059950100320170703R050005.XML";
    //            string path = Constants.SAVED_FILE_PATH + "RBI\\RAWDATA\\03072017\\" + filename;
    //            System.IO.FileStream fs = null;
    //            fs = System.IO.File.Open(path, System.IO.FileMode.Open);
    //            byte[] btFile = new byte[fs.Length];
    //            fs.Read(btFile, 0, Convert.ToInt32(fs.Length));
    //            fs.Close();
    //            Response.AddHeader("Content-disposition", "attachment; filename=" + filename);
    //            Response.ContentType = "application/octet-stream";
    //            Response.BinaryWrite(btFile);
    //            Response.End();
    //        }
    //        catch (ThreadAbortException ex1)
    //        {
    //            // do nothing
    //        }
    //        catch (Exception ex)
    //        {
    //            ExceptionLogging.logException(ex);
    //        }
    //    }
    //}
}