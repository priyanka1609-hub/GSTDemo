﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Threading;
using System.Globalization;

public partial class Reports_RbiAccountStatement : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    public decimal totalcramount = 0, totaldbamount = 0;
    public Int64 totalcrentries = 0, totaldbentries = 0;
    public string datechck;
    public string date;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try { datechck = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true); }
            catch { datechck = string.Empty; }

            if (string.IsNullOrEmpty(datechck))
            {
                // showData();
                string todatecurrent = DateTime.Now.ToString("dd/MM/yyyy");
                string fromdatecurrent = "01/" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.ToString("yyyy");
                txtfromdate.Text = fromdatecurrent.Replace("-", "/");
                txttodate.Text = todatecurrent.Replace("-", "/");
                fillgrid(fromdatecurrent, todatecurrent);

            }
            else
            {
                fromtodate.Visible = false;
                fillgrid("", "");

            }
            
        
        
        }

    }
    private void fillgrid(string from, string to)
    {
        string fromdate = string.Empty;
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select stmtid,to_char(fromdatetime,'DD/MM/YYYY HH24:MI:SS') as fromdatetime,to_char(todatetime,'DD/MM/YYYY HH24:MI:SS') as todatetime,totcdntries,totcdamt,totdbntries,totdbamt,(totcdntries+totdbntries) as totalentries from rbi_as_statement rs  ");
        SelectQuery.Append(" where rs.fromdatetime >= @from and rs.fromdatetime <= @to");
        SelectQuery.Append(" order by to_char(fromdatetime,'YYYY/MM/DD')");
        fromdate = Utility.pgsqlFromDateFormat(from);
        
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@from", fromdate);
        SelectCmd.Parameters.AddWithValue("@to", Utility.pgsqlToDateFormat(to));
        
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
        grdaccount.DataSource = dt;
        grdaccount.DataBind();
    }
    protected void btnshowdata_Click(object sender, EventArgs e)
    {
    
       
        fillgrid(txtfromdate.Text, txttodate.Text);
    }
    protected void grdasfiles_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            string stmtid = grdaccount.DataKeys[e.Row.RowIndex].Values["stmtid"].ToString();
            Label lblcramount = (Label)e.Row.FindControl("lblCRamount");
            Label lbldbamount = (Label)e.Row.FindControl("lbldbamount");
            decimal cramount = decimal.Parse(lblcramount.Text);
            decimal dbamount = decimal.Parse(lbldbamount.Text);
            totalcramount += cramount;
            totaldbamount += dbamount;
      
            HyperLink hylnkforcrdntries = (HyperLink)e.Row.FindControl("hylinkcrdnt");
            HyperLink hylnkfordbtntries = (HyperLink)e.Row.FindControl("hylinkdbtnt");
            Int64 crentries = Int64.Parse(hylnkforcrdntries.Text);
            Int64 dbentries = Int64.Parse(hylnkfordbtntries.Text);
            totalcrentries += crentries;
            totaldbentries += dbentries;
            
            
            hylnkforcrdntries.NavigateUrl = md5util.CreateTamperProofURL("~/Reports/AsEntriesDetail.aspx", null, "stmtid=" + MD5Util.Encrypt(stmtid, true) + "&trnstype=" + MD5Util.Encrypt("CRDT", true));
            hylnkfordbtntries.NavigateUrl = md5util.CreateTamperProofURL("~/Reports/AsEntriesDetail.aspx", null, "stmtid=" + MD5Util.Encrypt(stmtid, true) + "&trnstype=" + MD5Util.Encrypt("DBIT", true));

        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            Label lblcramt = (Label)e.Row.FindControl("lblcramt");
            Label lbldbamt = (Label)e.Row.FindControl("lbldbamt");
            Label lblcrntries = (Label)e.Row.FindControl("lblcrntries");
            Label lbldbntries = (Label)e.Row.FindControl("lbldbntries");

            lblcramt.Text = totalcramount.ToString();
            lbldbamt.Text = totaldbamount.ToString();
            lblcrntries.Text = totalcrentries.ToString();
            lbldbntries.Text = totaldbentries.ToString();


        } 

    }

}