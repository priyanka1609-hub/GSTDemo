﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Threading;
using System.Globalization;

public partial class Reports_AfterReconcilationBankWise : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    protected DataTable dtforgrid;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Logout.aspx");
                }
                else
                {
                    if (Request.QueryString["dt"] != null)
                    {
                        string date = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true);
                        fillInitialData(date);
                        fillReconciledData(date);
                    }
                }
            }


        }
    }

    protected void fillInitialData(string date)
    {
        decimal rbiamount = 0,othamount=0;
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select COALESCE(sum(sgst_total),'0.00') taxamt,banktype from transactions_eod_cin tec
                                                        inner join master_gstn_banks mb on mb.bankcode=tec.bank_cd
                                                        where to_char(paymentdatetime,'DD/MM/YYYY')=@date
                                                        group by banktype  ");

        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@date", date);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
        if (dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i]["banktype"].ToString() == "R")
                {
                    rbiamount = rbiamount + Convert.ToDecimal(dt.Rows[i]["taxamt"].ToString());
                }
                
                else
                {
                    othamount =othamount+ Convert.ToDecimal( dt.Rows[i]["taxamt"].ToString());
                }
            }
            lbl138.Text = othamount.ToString();
            lblner.Text = rbiamount.ToString();


        }
    }

    protected void fillReconciledData(string date)
    {
        string defval = "0.00";
        dtforgrid = new DataTable();
        dtforgrid.Clear();
        dtforgrid.Columns.Add("date");
        dtforgrid.Columns.Add("amtpsb");
        dtforgrid.Columns.Add("amtpvt");
        dtforgrid.Columns.Add("amtner");
        dtforgrid.Columns.Add("psbtax");
        dtforgrid.Columns.Add("psbintr");
        dtforgrid.Columns.Add("psbfee");
        dtforgrid.Columns.Add("psbpnlty");
        dtforgrid.Columns.Add("psboth");
        dtforgrid.Columns.Add("pvttax");
        dtforgrid.Columns.Add("pvtintr");
        dtforgrid.Columns.Add("pvtfee");
        dtforgrid.Columns.Add("pvtpnlty");
        dtforgrid.Columns.Add("pvtoth");
        dtforgrid.Columns.Add("nertax");
        dtforgrid.Columns.Add("nerintr");
        dtforgrid.Columns.Add("nerfee");
        dtforgrid.Columns.Add("nerpnlty");
        dtforgrid.Columns.Add("neroth");
         dtforgrid.Columns.Add("tottax");
        dtforgrid.Columns.Add("totintr");
        dtforgrid.Columns.Add("totfee");
        dtforgrid.Columns.Add("totpnlty");
        dtforgrid.Columns.Add("tototh");
        dtforgrid.Columns.Add("ratamt");
        dtforgrid.Columns.Add("totalsgst");
        dtforgrid.Columns.Add("nertotalsgst");
        dtforgrid.Columns.Add("othbnktotal");
        dtforgrid.Columns.Add("rbibnktotal");
        dtforgrid.Columns.Add("paymentdate");


        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select cfileid from compact_files where to_char(paymentdate,'DD/MM/YYYY')=@date and completed = 'Y'");

        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@date", date);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
        if (dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                decimal totalothsgst = 0,totalrbisgst=0,tax=0,intr=0,penlty=0,fee=0,oth=0;

                SelectQuery = new StringBuilder(@"select to_char(tec.paymentdatetime,'DD/MM/YYYY') paymentdatetime,to_char(mc.insertdatetime,'DD/MM/YYYY') date, COALESCE(sum(sgst_total),'0.00') total,COALESCE(sum(sgst_tax),'0.00') tax,COALESCE(sum(sgst_intr),'0.00') intr,COALESCE(sum(sgst_fee),'0.00') fee,COALESCE(sum(sgst_pnlty),'0.00') pnlty,COALESCE(sum(sgst_oth),'0.00') oth,banktype from moe_compact mc 
                                                    inner join transactions_eod_cin tec on tec.cin=mc.cin
                                                    inner join master_gstn_banks mb on mb.bankcode=tec.bank_cd
                                                    where compactfileid=@cfileid
                                                    group by banktype,to_char(mc.insertdatetime,'DD/MM/YYYY'),to_char(tec.paymentdatetime,'DD/MM/YYYY')");

                SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
                SelectCmd.Parameters.AddWithValue("@cfileid", dt.Rows[i]["cfileid"].ToString());
                DataTable dtnew = data.GetDataTable(SelectCmd, "nfs");
                if (dtnew.Rows.Count > 0)
                {
                    DataRow dr = dtforgrid.NewRow();
                    dr["date"] = dtnew.Rows[0]["date"];
                    dr["paymentdate"] = dtnew.Rows[0]["paymentdatetime"];

                    dr["amtpsb"] = defval;
                    dr["psbtax"] = defval;
                    dr["psbintr"] = defval;
                    dr["psbfee"] = defval;
                    dr["psbpnlty"] = defval;
                    dr["psboth"] = defval;
                    dr["amtpvt"] = defval;
                    dr["pvttax"] = defval;
                    dr["pvtintr"] = defval;
                    dr["pvtfee"] = defval;
                    dr["pvtpnlty"] = defval;
                    dr["pvtoth"] = defval;
                    dr["amtner"] = defval;
                    dr["nertax"] = defval;
                    dr["nerintr"] = defval;
                    dr["nerfee"] = defval;
                    dr["nerpnlty"] = defval;
                    dr["neroth"] = defval;
                    dr["tottax"] = defval;
                    dr["totintr"] = defval;
                    dr["totfee"] = defval;
                    dr["totpnlty"] = defval;
                    dr["tototh"] = defval;
                    dr["ratamt"] = defval;
                  
                    dr["totalsgst"] = defval;
                    dr["nertotalsgst"] = defval;



                    for (int j = 0; j < dtnew.Rows.Count; j++)
                    {

                        if (dtnew.Rows[j]["banktype"].ToString() == "R")
                        {
                            //dr["amtpsb"] = dtnew.Rows[j]["total"];
                            //dr["psbtax"] = dtnew.Rows[j]["tax"];
                            //dr["psbintr"] = dtnew.Rows[j]["intr"];
                            //dr["psbfee"] = dtnew.Rows[j]["fee"];
                            //dr["psbpnlty"] = dtnew.Rows[j]["pnlty"];
                            //dr["psboth"] = dtnew.Rows[j]["oth"];
                         
                            tax = tax + Convert.ToDecimal(dtnew.Rows[j]["tax"]);
                            intr = intr + Convert.ToDecimal(dtnew.Rows[j]["intr"]);
                            fee = fee + Convert.ToDecimal(dtnew.Rows[j]["fee"]);
                            penlty = penlty + Convert.ToDecimal(dtnew.Rows[j]["pnlty"]);
                            oth = oth + Convert.ToDecimal(dtnew.Rows[j]["oth"]);
                            totalrbisgst = totalrbisgst + Convert.ToDecimal(dtnew.Rows[j]["total"]);

                        }
                        
                        else
                        {
                            //dr["amtner"] = dtnew.Rows[j]["total"];
                            //dr["nertax"] = dtnew.Rows[j]["tax"];
                            //dr["nerintr"] = dtnew.Rows[j]["intr"];
                            //dr["nerfee"] = dtnew.Rows[j]["fee"];
                            //dr["nerpnlty"] = dtnew.Rows[j]["pnlty"];
                            //dr["neroth"] = dtnew.Rows[j]["oth"];
                            tax = tax + Convert.ToDecimal(dtnew.Rows[j]["tax"]);
                            intr = intr + Convert.ToDecimal(dtnew.Rows[j]["intr"]);
                            fee = fee + Convert.ToDecimal(dtnew.Rows[j]["fee"]);
                            penlty = penlty + Convert.ToDecimal(dtnew.Rows[j]["pnlty"]);
                            oth = oth + Convert.ToDecimal(dtnew.Rows[j]["oth"]);
                            dr["nertotalsgst"] = dtnew.Rows[j]["total"];

                            totalothsgst = totalothsgst + Convert.ToDecimal(dtnew.Rows[j]["total"]);

                        }


                    }
                    
                  
                    dr["tottax"] = tax.ToString("F2");
                    dr["totintr"] = intr.ToString("F2");
                    dr["totfee"] = fee.ToString("F2");
                    dr["totpnlty"] = penlty.ToString("F2");
                    dr["tototh"] = oth.ToString("F2"); 
                    dr["othbnktotal"] = totalothsgst.ToString("F2");
                    dr["rbibnktotal"] = totalrbisgst.ToString("F2");
                    dr["totalsgst"] = (totalothsgst+totalrbisgst).ToString();

                    SelectQuery = new StringBuilder(@"select COALESCE(sum(totaltxnamt),'0.00') rbitotalamt from rbi_response_txns_details where cin not in (select cin from moe_compact  where compactfileid=@cfileid) and  to_char(paymentdatetime,'DD/MM/YYYY')=@date ");
                    SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
                    SelectCmd.Parameters.AddWithValue("@cfileid", dt.Rows[i]["cfileid"].ToString());
                    SelectCmd.Parameters.AddWithValue("@date", date);
                    DataTable dtrbi = data.GetDataTable(SelectCmd, "nfs");

                    if (dtrbi.Rows.Count > 0)
                    {
                        dr["ratamt"] = dtrbi.Rows[0]["rbitotalamt"].ToString();
                    }

                    dtforgrid.Rows.Add(dr);
                }

            }

        }
    }
    protected void imgbtnback_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("HeadwiseReport.aspx");
    }
}