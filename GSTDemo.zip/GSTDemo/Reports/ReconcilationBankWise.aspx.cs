﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;

public partial class Reports_ReconcilationBankWise : System.Web.UI.Page
{

    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();


    protected DataTable dtforgrid;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            //ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState

            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Logout.aspx");
                }
            }

            // showData();
        }

        fillgrid();
    }
    protected void fillgrid()
    {
        string date = string.Empty;

        Double obankamnt = 0.00d, rbibankamnt = 0.00d, tax = 0.00d, intr = 0.00d, fee = 0.00d, pnlty = 0.00d, oth = 0.00d;
        int obanktrns = 0, rbibanktrns = 0;
        StringBuilder SelectQuery = new StringBuilder(@"select tec.cin,sgst_total,to_char(tec.paymentdatetime,'DD/MM/YYYY') payment_dt,tec.paymentdatetime,sgst_tax,sgst_intr,sgst_pnlty,sgst_fee,sgst_oth ,banktype
				    from transactions_eod_cin tec 
				    inner join rbi_response_txns_details rbi on rbi.cin = tec.cin
				    inner join master_gstn_banks mgb on mgb.bankcode=tec.bank_cd
				    where sgst_total != 0.00 and sgst_total=totaltxnamt");

        if (Request.QueryString["dt"] != null)
        {
            date = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true);

            SelectQuery.Append(" and  to_char(tec.paymentdatetime,'DD/MM/YYYY')=@paymentdatetime ");
        }

        SelectQuery.Append(" order by paymentdatetime");

        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdatetime", date);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        if (dt.Rows.Count > 0)
        {
            dtforgrid = new DataTable();
            dtforgrid.Clear();
            dtforgrid.Columns.Add("date");
            dtforgrid.Columns.Add("othbanktrns");
            dtforgrid.Columns.Add("othbankamnt");
            dtforgrid.Columns.Add("rbitxns");
            dtforgrid.Columns.Add("rbiamnt");
            dtforgrid.Columns.Add("totaltrns");
            dtforgrid.Columns.Add("totalamnt");
            dtforgrid.Columns.Add("tax");
            dtforgrid.Columns.Add("intr");
            dtforgrid.Columns.Add("fee");
            dtforgrid.Columns.Add("pnlty");
            dtforgrid.Columns.Add("oth");
            dtforgrid.Columns.Add("minortotamt");


            int i;
            int dtrowscount = dt.Rows.Count;
            for (i = 0; i < dtrowscount; i++)
            {
                if (i == 0)
                {
                    if (dt.Rows[0]["banktype"].ToString() == "R")
                    {
                        rbibankamnt = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                        tax = Convert.ToDouble(dt.Rows[0]["sgst_tax"].ToString());
                        intr = Convert.ToDouble(dt.Rows[0]["sgst_intr"].ToString());
                        fee = Convert.ToDouble(dt.Rows[0]["sgst_fee"].ToString());
                        pnlty = Convert.ToDouble(dt.Rows[0]["sgst_pnlty"].ToString());
                        oth = Convert.ToDouble(dt.Rows[0]["sgst_oth"].ToString());
                        rbibanktrns++;
                    }
                    else
                    {
                        obankamnt = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                        tax = Convert.ToDouble(dt.Rows[0]["sgst_tax"].ToString());
                        intr = Convert.ToDouble(dt.Rows[0]["sgst_intr"].ToString());
                        fee = Convert.ToDouble(dt.Rows[0]["sgst_fee"].ToString());
                        pnlty = Convert.ToDouble(dt.Rows[0]["sgst_pnlty"].ToString());
                        oth = Convert.ToDouble(dt.Rows[0]["sgst_oth"].ToString());
                        obanktrns++;

                    }


                }
                else
                {
                    if (dt.Rows[i]["payment_dt"].ToString() == dt.Rows[i - 1]["payment_dt"].ToString())
                    {
                        if (dt.Rows[i]["banktype"].ToString() == "R")
                        {
                            double newrbibankamnt = rbibankamnt + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            rbibankamnt = newrbibankamnt;
                           
                            double newtax = tax + Convert.ToDouble(dt.Rows[i]["sgst_tax"].ToString());
                            tax = newtax;
                            double newintr = intr + Convert.ToDouble(dt.Rows[i]["sgst_intr"].ToString());
                            intr = newintr;
                            double newfee = fee + Convert.ToDouble(dt.Rows[i]["sgst_fee"].ToString());
                            fee = newfee;
                            double newpnlty = pnlty + Convert.ToDouble(dt.Rows[i]["sgst_pnlty"].ToString());
                            pnlty = newpnlty;
                            double newoth = oth + Convert.ToDouble(dt.Rows[i]["sgst_oth"].ToString());
                            oth = newoth;
                            //amtner = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            rbibanktrns++;
                        }
                        else
                        {
                            double newobankamnt = obankamnt + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            obankamnt = newobankamnt;
                            double newtax = tax + Convert.ToDouble(dt.Rows[i]["sgst_tax"].ToString());
                            tax = newtax;
                            double newintr = intr + Convert.ToDouble(dt.Rows[i]["sgst_intr"].ToString());
                            intr = newintr;
                            double newfee = fee + Convert.ToDouble(dt.Rows[i]["sgst_fee"].ToString());
                            fee = newfee;
                            double newpnlty = pnlty + Convert.ToDouble(dt.Rows[i]["sgst_pnlty"].ToString());
                            pnlty = newpnlty;
                            double newoth = oth + Convert.ToDouble(dt.Rows[i]["sgst_oth"].ToString());
                            oth = newoth;
                            //amtpsb = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            obanktrns++;
                        }

                    }
                    else
                    {
                        DataRow dr = dtforgrid.NewRow();
                        dr["date"] = dt.Rows[i - 1]["payment_dt"];
                        dr["othbanktrns"] = obanktrns.ToString();
                        dr["othbankamnt"] = obankamnt.ToString("F2");
                        dr["rbitxns"] = rbibanktrns.ToString();
                        dr["rbiamnt"] = rbibankamnt.ToString("F2");
                        dr["totaltrns"] = (obanktrns + rbibanktrns).ToString();
                        dr["totalamnt"] = (obankamnt + rbibankamnt).ToString("F2");
                        dr["tax"] = tax.ToString("F2");
                        dr["intr"] = intr.ToString("F2");
                        dr["fee"] = fee.ToString("F2");
                        dr["pnlty"] = pnlty.ToString("F2");
                        dr["oth"] = oth.ToString("F2");
                        dr["minortotamt"] = (tax + intr + fee + pnlty + oth).ToString("F2");


                        dtforgrid.Rows.Add(dr);

                        obankamnt = 0.00d;
                        rbibankamnt = 0.00d;
                        tax = 0.00d;
                        intr = 0.00d;
                        fee = 0.00d;
                        pnlty = 0.00d;
                        oth = 0.00d;
                        obanktrns = 0;
                        rbibanktrns = 0;

                        if (dt.Rows[i]["banktype"].ToString() == "R")
                        {
                            double newrbibankamnt = rbibankamnt + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            rbibankamnt = newrbibankamnt;
                         
                            double newtax = tax + Convert.ToDouble(dt.Rows[i]["sgst_tax"].ToString());
                            tax = newtax;
                            double newintr = intr + Convert.ToDouble(dt.Rows[i]["sgst_intr"].ToString());
                            intr = newintr;
                            double newfee = fee + Convert.ToDouble(dt.Rows[i]["sgst_fee"].ToString());
                            fee = newfee;
                            double newpnlty = pnlty + Convert.ToDouble(dt.Rows[i]["sgst_pnlty"].ToString());
                            pnlty = newpnlty;
                            double newoth = oth + Convert.ToDouble(dt.Rows[i]["sgst_oth"].ToString());
                            oth = newoth;
                            //amtner = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            rbibanktrns++;
                        }
                        else
                        {
                            double newobankamnt = obankamnt + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            obankamnt = newobankamnt;
                            double newtax = tax + Convert.ToDouble(dt.Rows[i]["sgst_tax"].ToString());
                            tax = newtax;
                            double newintr = intr + Convert.ToDouble(dt.Rows[i]["sgst_intr"].ToString());
                            intr = newintr;
                            double newfee = fee + Convert.ToDouble(dt.Rows[i]["sgst_fee"].ToString());
                            fee = newfee;
                            double newpnlty = pnlty + Convert.ToDouble(dt.Rows[i]["sgst_pnlty"].ToString());
                            pnlty = newpnlty;
                            double newoth = oth + Convert.ToDouble(dt.Rows[i]["sgst_oth"].ToString());
                            oth = newoth;
                            //amtpsb = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            obanktrns++;

                        }


                    }
                }

            }

            DataRow droneorlast = dtforgrid.NewRow();
            droneorlast["date"] = dt.Rows[i - 1]["payment_dt"];
            droneorlast["othbanktrns"] = obanktrns.ToString();
            droneorlast["othbankamnt"] = obankamnt.ToString("F2");
            droneorlast["rbitxns"] = rbibanktrns.ToString();
            droneorlast["rbiamnt"] = rbibankamnt.ToString("F2");
            droneorlast["totaltrns"] = (rbibanktrns + obanktrns).ToString();
            droneorlast["totalamnt"] = (rbibankamnt + obankamnt).ToString("F2");
            droneorlast["tax"] = tax.ToString("F2");
            droneorlast["intr"] = intr.ToString("F2");
            droneorlast["fee"] = fee.ToString("F2");
            droneorlast["pnlty"] = pnlty.ToString("F2");
            droneorlast["oth"] = oth.ToString("F2");
            droneorlast["minortotamt"] = (tax + intr + fee + pnlty + oth).ToString("F2");


            dtforgrid.Rows.Add(droneorlast);

            

        }

    }
    protected void imgbtnback_Click(object sender, ImageClickEventArgs e)
    {
        //if (ViewState["PreviousPage"] != null)	//Check if the ViewState 
        ////contains Previous page URL
        //{
        Response.Redirect("../Reports/HeadwiseReport.aspx");//Redirect to 
        //Previous page by retrieving the PreviousPage Url from ViewState.
        //}
    }
    protected void imgbtndownload_Click(object sender, ImageClickEventArgs e)
    {

    }
    protected string gstnTxnDetails(string rowDate, string mode)
    {
        return md5util.CreateTamperProofURL("../Reports/MatchedTxns.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true) + "&banktype=" + MD5Util.Encrypt(mode, true));
    }
  
}