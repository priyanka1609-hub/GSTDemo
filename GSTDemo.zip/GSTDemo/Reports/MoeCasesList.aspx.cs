﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;

public partial class Reports_MoeCasesList : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
        {

            if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
            StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
            {
                Response.Redirect("Login.aspx?id=0");
            }
        }
        if (Request.QueryString["fileid"] != null)
        {
            string fileid = MD5Util.Decrypt(Request.QueryString["fileid"].ToString(), true);
            showcaselist(fileid);
        }

    }

    protected void showcaselist(string fileid)
    {

        StringBuilder SelectQuery = new StringBuilder(@"select description ,caseid,taxid,cin,originalamt, case missingcin when true then 'Yes' else 'No' end missingcin,extrainfo,valdate from moe_cases mc
                                                        inner join master_moe mm on mm.moetype=mc.moetype where moefileid=@moefileid order by caseid ");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@moefileid", fileid);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        if (dt.Rows.Count > 0)
        {
            grdmoecaselist.DataSource = dt;
            grdmoecaselist.DataBind();
        }
        else
        {
            msg.Show("No Data Found");
        }

    }
}