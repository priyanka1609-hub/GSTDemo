﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;

public partial class Reports_RefundAmountEntry : System.Web.UI.Page
{
    MD5Util md5util = new MD5Util();
    public DataTable dt = new DataTable();
    PostgresGetData data = new PostgresGetData();
    List<NpgsqlCommand> cmdlist=new List<NpgsqlCommand>();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
        }
        string gstin = MD5Util.Decrypt(Request.QueryString["gstin"].ToString(), true);
        string cin= MD5Util.Decrypt(Request.QueryString["cin"].ToString(), true);
        fillgrid(gstin,cin);

    }

    public void fillgrid(string gstin, string cin)
    {
        
        StringBuilder SelectQuery = new StringBuilder(@"select tec.cpin,tec.gstin,sgst_tax,sgst_intr,sgst_fee,sgst_pnlty,sgst_oth,sgst_total,tec.cin,pm.modedesc,tec.txnid,bm.bankname,bank_ref_num,to_char(tec.paymentdatetime,'DD/MM/YYYY') as paymentdatetime,utr_num, ack_num,bank_ref_num,br_ifsc_cd, br_location, br_name, instrument_no, instrument_micr_cd, 
                                                        to_char(tec.cpindatetime,'DD/MM/YYYY') as cpindatetime, to_char(tec.pymntackdatetime,'DD/MM/YYYY') as pymntackdatetime, to_char(tec.reportingdatetime,'DD/MM/YYYY') as reportingdatetime from transactions_eod_cin tec
                                                        inner join rbi_response_txns_details rbi on rbi.cin=tec.cin
                                                        inner join master_gstn_pay_mode pm on pm.mode=tec.mode
                                                        inner join master_gstn_banks bm on bm.bankcode=tec.bank_cd
                                                        where tec.gstin=@gstin and tec.cin=@cin");

        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@gstin", gstin);
        SelectCmd.Parameters.AddWithValue("@cin", cin);
        dt = data.GetDataTable(SelectCmd, "nfs");

        if (dt.Rows.Count > 0 && dt != null)
        {
           hdngstn.Value=dt.Rows[0]["gstin"].ToString();
           hdncin.Value = dt.Rows[0]["cin"].ToString();
           hdncpin.Value = dt.Rows[0]["cpin"].ToString();
           hdnpaydate.Value = dt.Rows[0]["paymentdatetime"].ToString();
           hdnsgstamount.Value = dt.Rows[0]["sgst_total"].ToString();
        }
       
    }
    protected void btn_getgstin_Click(object sender, EventArgs e)
    {
        if (Convert.ToDecimal(txtrefundamount.Text) > Convert.ToDecimal(hdnsgstamount.Value))
        {

            lblrefunderror.Visible = true;
            return;
        }
        else
        {
            lblrefunderror.Visible = false;
        }
        string qry = @"INSERT INTO refundedamount(gstin, cin, cpin, gstin_payment_date, refundedamount, refundedby, ipaddress, edatetime)
                     VALUES (@gstin, @cin, @cpin, @gstin_payment_date, @refundedamount, @refundedby, @ipaddress,now());";

        NpgsqlCommand insertdata = new NpgsqlCommand(qry);
        insertdata.Parameters.AddWithValue("@gstin",hdngstn.Value);
        insertdata.Parameters.AddWithValue("@cin",hdncin.Value);
        insertdata.Parameters.AddWithValue("@cpin",hdncpin.Value);
        insertdata.Parameters.AddWithValue("@gstin_payment_date",Utility.converttodate_from_DDMMYYYY(hdnpaydate.Value));
        insertdata.Parameters.AddWithValue("@refundedamount",txtrefundamount.Text);
        insertdata.Parameters.AddWithValue("@refundedby", Session["UC_USER_NAME"]);
        insertdata.Parameters.AddWithValue("@ipaddress",PostgresGetData.GetIP4Address());
        cmdlist.Add(insertdata);
        int records = data.SaveData(cmdlist, "nfs");
        if (records > 0)
        {
            string script = "<script type='text/javascript'>alert('Refund Amount Inserted Successfully.');window.location='/Reports/GstinRefund.aspx';</script>";
            ClientScript.RegisterStartupScript(GetType(), "alert", script);
//            Response.Redirect("/Reports/GstinRefund.aspx");
        }


        

    }
}