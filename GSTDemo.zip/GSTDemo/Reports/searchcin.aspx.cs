﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using Npgsql;
using System.Data;
using GstDelhi.PostgresData;
using Newtonsoft.Json;
using System.Globalization;

public partial class Reports_searchcin : System.Web.UI.Page
{
    protected DataTable sgstdata; protected DataTable rbidata;
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (!IsPostBack)
        //{
        //    //getData(DateTime.Now.ToString("dd-MM-yyyy").ToString());
        //}

    }


    protected void btn_getData_Click(object sender, EventArgs e)
    {
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder("select cpin,sgst_tax,sgst_oth,sgst_fee,sgst_pnlty,sgst_intr,sgst_total,to_char(paymentdatetime,'DD/MM/YYYY HH:MM:SS') as paymentdate , to_char(reportingdatetime,'DD/MM/YYYY HH:MM:SS') as reportingdate from transactions_eod_cin where cin=@cin");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@cin", txtcin.Text.ToUpper());
        sgstdata = new DataTable();
        sgstdata = data.GetDataTable(SelectCmd, "nfs");
        if (sgstdata.Rows.Count > 0)
        {
            divsrch.Visible = true;
            divsgst.Visible = true;
            lblerror.Visible = false;
        }


        StringBuilder Selectrbidata = new StringBuilder("select cpin,to_char(accptncdttm,'DD/MM/YYYY HH:MM:SS') as acceptancedate, to_char(paymentdatetime,'DD/MM/YYYY HH:MM:SS') as paymentdaterbi,totaltxnamt from rbi_response_txns_details  where cin=@cin");
        NpgsqlCommand SelectCmd1 = new NpgsqlCommand(Selectrbidata.ToString());
        SelectCmd1.Parameters.AddWithValue("@cin", txtcin.Text.ToUpper());
        rbidata = new DataTable();
        rbidata = data.GetDataTable(SelectCmd1, "nfs");
        if (rbidata.Rows.Count > 0)
        {
            divsrch.Visible = true;
            divrbi.Visible = true;
            lblerror.Visible = false;

        }
        if (rbidata.Rows.Count == 0 && sgstdata.Rows.Count==0)
        {
            divsrch.Visible = false;
            lblerror.Visible = true;
            txtcin.Text = "";
        }

        
    }
    
}