﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Threading;

public partial class Reports_BankWiseReport : System.Web.UI.Page
{
     PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    protected DataTable dtforgrid;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {


            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Logout.aspx");
                }
            }

            // showData();

            if (Request.QueryString["dt"] != null)
            {
                string date = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true);
                lblheading.Text = "for Date : " + date;
                fillgrid(date, "");
            }
            else
            {
                trselectdate.Visible = true;
            }
        }
    }

    protected void fillgrid(string from, string to)
    {
        string fromdate = string.Empty;
        StringBuilder SelectQuery = new StringBuilder(@"select count(cin) txns,sum(sgst_total) amt ,bank_cd,mb.bankname from transactions_eod_cin tec
                                                        inner join master_gstn_banks mb on mb.bankcode=tec.bank_cd
                                                        where sgst_total <> 0.00  ");

        if (string.IsNullOrEmpty(to))
        {
            SelectQuery.Append(" and to_char(tec.paymentdatetime,'DD/MM/YYYY')=@from");
            fromdate = from;
        }
        else
        {
            SelectQuery.Append(" and tec.paymentdatetime >= @from and tec.paymentdatetime <= @to");
            fromdate = Utility.pgsqlFromDateFormat(from);
        }

        SelectQuery.Append(" group by bank_cd,mb.bankname order by mb.bankname");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@from", fromdate);
        SelectCmd.Parameters.AddWithValue("@to", Utility.pgsqlToDateFormat(to));
        DataTable dtbankwise = data.GetDataTable(SelectCmd, "nfs");

        //decimal totalamt = dtbankwise.AsEnumerable().Sum(row => row.Field<decimal>("amt"));
        //decimal totaltxns = dtbankwise.AsEnumerable().Sum(row => row.Field<decimal>("txns"));
        //gdvbankwise.FooterRow.Cells[1].Text = "Total";
        //gdvbankwise.FooterRow.Cells[2].HorizontalAlign = HorizontalAlign.Right;
        //gdvbankwise.FooterRow.Cells[2].Text = totalamt.ToString("N2");
        //gdvbankwise.FooterRow.Cells[3].Text = totaltxns.ToString();

        //gdvbankwise.ShowFooter = true;
        gdvbankwise.DataSource = dtbankwise;
        gdvbankwise.DataBind();
    }

    protected void btnshowdata_Click(object sender, EventArgs e)
    {
        lblheading.Text = "From " + txtfromdate.Text+ " TO "+txttodate.Text;
        fillgrid(txtfromdate.Text, txttodate.Text);
    }
}