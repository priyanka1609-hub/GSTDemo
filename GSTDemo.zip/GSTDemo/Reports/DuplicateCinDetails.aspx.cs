﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;

public partial class Reports_DuplicateCinDetails : System.Web.UI.Page
{
    MD5Util md5util = new MD5Util();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState
            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Login.aspx?id=0");
                }
                else
                {
                    fillgrid();
                }


            }
            else
            {
                //tbldate.Visible = true;
            }
            fillgrid();
        }

    }

    private void fillgrid()
    {
        string frcid = string.Empty, banktype = string.Empty, paymentdate = string.Empty, tabletoshow = string.Empty;

        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"SELECT eodcinid, gstin, temp_id, cpin, to_char(cpindatetime,'DD/MM/YYYY HH:MI:SS') cpindatetime, pm.modedesc, sgst_tax, 
                                                       sgst_intr, sgst_fee, sgst_pnlty, sgst_oth, sgst_total, eod.cin, txnid, 
                                                       utr_num, ack_num, bank_ref_num, eod.status, total_amt, to_char(paymentdatetime,'DD/MM/YYYY HH:MI:SS') paymentdatetime,
                                                       it.desc as instdesc, mgb.bankname, br_ifsc_cd, br_location, 
                                                       br_name, instrument_no, instrument_micr_cd, to_char(pymntackdatetime,'DD/MM/YYYY HH:MI:SS') pymntackdatetime, 
                                                       to_char(reportingdatetime,'DD/MM/YYYY HH:MI:SS') reportingdatetime, frcid, ms.statusdesc as rconstatus
                                                         FROM  duplicate_eod_cin eod
                                                        inner join master_gstn_banks mgb on mgb.bankcode=eod.bank_cd
                                                        inner join master_gstn_pay_mode pm on pm.mode=eod.mode
                                                        left outer join master_instrument_types it on it.code = eod.instrument_ty
                                                        left outer join moe_compact mc on mc.cin=eod.cin                                
                                                        left outer join master_status ms on ms.statuscode=mc.status
                                                        where 1=1 ");

        if (!string.IsNullOrEmpty(frcid))
        {
            SelectQuery.Append(" and frcid=@frcid");
        }
        if (!string.IsNullOrEmpty(paymentdate))
        {
            SelectQuery.Append(" and to_char(paymentdatetime,'DD/MM/YYYY')=@paymentdatetime");
        }
        if (!string.IsNullOrEmpty(banktype) && banktype.ToString() != "N")
        {
            if (banktype == "O")
            {
                SelectQuery.Append(" and mgb.banktype in ('G','P')  ");
            }
            else
            {
                SelectQuery.Append(" and mgb.banktype=@banktype  ");
            }
        }

        SelectQuery.Append(" and sgst_total <> 0.00 order by paymentdatetime");


        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@frcid", frcid);
        SelectCmd.Parameters.AddWithValue("@paymentdatetime", paymentdate);
        SelectCmd.Parameters.AddWithValue("@banktype", banktype);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
        imgbtndownload.Visible = true;
        //tbldate.Visible = true;
        grdgstfiles.DataSource = dt;
        grdgstfiles.DataBind();

    }
    protected void imgbtnback_Click(object sender, ImageClickEventArgs e)
    {
       
    }
    protected void imgbtndownload_Click(object sender, ImageClickEventArgs e)
    {
    }
}