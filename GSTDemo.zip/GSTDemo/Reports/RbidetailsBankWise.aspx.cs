﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;

public partial class Reports_RbidetailsBankWise : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();


    protected DataTable dtforgrid;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            //ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState

            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Logout.aspx");
                }
            }

            // showData();
        }

        fillgrid();
    }
    protected void fillgrid()
    {
        string date = string.Empty;

        Double obankamnt = 0.00d, rbibankamnt = 0.00d;
        int obanktrns = 0, rbibanktrns = 0;
        StringBuilder SelectQuery = new StringBuilder(@"select mgb.banktype,cin,amt,to_char(paymentdatetime,'DD/MM/YYYY') payment_dt,paymentdatetime ,banktype from rbi_response_txns_details rbi
                                                        inner join master_gstn_banks mgb on mgb.bankcode=substring(rbi.cin from 1 for 4)
                                                        where 1=1");

        if (Request.QueryString["dt"] != null)
        {
            date = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true);

            SelectQuery.Append(" and  to_char(rbi.paymentdatetime,'DD/MM/YYYY')=@paymentdatetime ");
        }

        SelectQuery.Append(" order by paymentdatetime");

        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdatetime", date);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        if (dt.Rows.Count > 0)
        {
            dtforgrid = new DataTable();
            dtforgrid.Clear();
            dtforgrid.Columns.Add("date");
            dtforgrid.Columns.Add("othbanktrns");
            dtforgrid.Columns.Add("othbankamnt");
            dtforgrid.Columns.Add("rbitxns");
            dtforgrid.Columns.Add("rbiamnt");
            dtforgrid.Columns.Add("totaltrns");
            dtforgrid.Columns.Add("totalamnt");


            int i;
            int dtrowscount = dt.Rows.Count;
            for (i = 0; i < dtrowscount; i++)
            {
                if (i == 0)
                {
                    if (dt.Rows[0]["banktype"].ToString() == "R")
                    {
                        rbibankamnt = Convert.ToDouble(dt.Rows[0]["amt"].ToString());
                        rbibanktrns++;
                    }
                    else
                    {
                        obankamnt = Convert.ToDouble(dt.Rows[0]["amt"].ToString());
                        obanktrns++;

                    }


                }
                else
                {
                    if (dt.Rows[i]["payment_dt"].ToString() == dt.Rows[i - 1]["payment_dt"].ToString())
                    {
                        if (dt.Rows[i]["banktype"].ToString() == "R")
                        {
                            double newrbibankamnt = rbibankamnt + Convert.ToDouble(dt.Rows[i]["amt"].ToString());
                            rbibankamnt = newrbibankamnt;
                            //amtner = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            rbibanktrns++;
                        }
                        else
                        {
                            double newobankamnt = obankamnt + Convert.ToDouble(dt.Rows[i]["amt"].ToString());
                            obankamnt = newobankamnt;
                            //amtpsb = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            obanktrns++;
                        }

                    }
                    else
                    {
                        DataRow dr = dtforgrid.NewRow();
                        dr["date"] = dt.Rows[i - 1]["payment_dt"];
                        dr["othbanktrns"] = obanktrns.ToString();
                        dr["othbankamnt"] = obankamnt.ToString("F2");
                        dr["rbitxns"] = rbibanktrns.ToString();
                        dr["rbiamnt"] = rbibankamnt.ToString("F2");
                        dr["totaltrns"] = (obanktrns + rbibanktrns).ToString();
                        dr["totalamnt"] = (obankamnt + rbibankamnt).ToString("F2");


                        dtforgrid.Rows.Add(dr);

                        obankamnt = 0.00d;
                        rbibankamnt = 0.00d;

                        obanktrns = 0;
                        rbibanktrns = 0;

                        if (dt.Rows[i]["banktype"].ToString() == "R")
                        {
                            double newrbibankamnt = rbibankamnt + Convert.ToDouble(dt.Rows[i]["amt"].ToString());
                            rbibankamnt = newrbibankamnt;
                            //amtner = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            rbibanktrns++;
                        }
                        else
                        {
                            double newobankamnt = obankamnt + Convert.ToDouble(dt.Rows[i]["amt"].ToString());
                            obankamnt = newobankamnt;
                            //amtpsb = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            obanktrns++;

                        }


                    }
                }

            }

            DataRow droneorlast = dtforgrid.NewRow();
            droneorlast["date"] = dt.Rows[i - 1]["payment_dt"];
            droneorlast["othbanktrns"] = obanktrns.ToString();
            droneorlast["othbankamnt"] = obankamnt.ToString("F2");
            droneorlast["rbitxns"] = rbibanktrns.ToString();
            droneorlast["rbiamnt"] = rbibankamnt.ToString("F2");
            droneorlast["totaltrns"] = (rbibanktrns + obanktrns).ToString();
            droneorlast["totalamnt"] = (rbibankamnt + obankamnt).ToString("F2");


            dtforgrid.Rows.Add(droneorlast);



        }

    }
    protected void imgbtnback_Click(object sender, ImageClickEventArgs e)
    {
        //if (ViewState["PreviousPage"] != null)	//Check if the ViewState 
        ////contains Previous page URL
        //{
        Response.Redirect("../Reports/HeadwiseReport.aspx");//Redirect to 
        //Previous page by retrieving the PreviousPage Url from ViewState.
        //}
    }
    protected void imgbtndownload_Click(object sender, ImageClickEventArgs e)
    {

    }
    protected string gstnTxnDetails(string rowDate, string mode)
    {
        return md5util.CreateTamperProofURL("../Reports/RbiScrollDetails.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true) + "&banktype=" + MD5Util.Encrypt(mode, true));
    }
    protected string rbiTxnDetails(string rowDate, string mode)
    {
        return md5util.CreateTamperProofURL("../Reports/RbiScrollDetails.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true) + "&banktype=" + MD5Util.Encrypt(mode, true));
    }
}