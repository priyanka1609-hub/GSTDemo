﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;

public partial class Reports_CnMissedNtry : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    protected DataTable dtforgrid;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState

            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Logout.aspx");
                }

                if (Request.QueryString["dt"] != null)
                {
                    fillgrid(MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true));
                }
            }
        }
    }

    protected void fillgrid(string date)
    {
//        StringBuilder SelectQuery = new StringBuilder(@"select accs.ntryref, accs.amt, valdate from rbi_as_entries accs 
//                                                        left outer join rbi_response_entries cn on cn.ntryref=accs.ntryref
//                                                        where cn.ntryref is null and cdordb='CRDT' and rvslind = false and valdate=@valdate order by accs.ntryref");

//        StringBuilder SelectQuery = new StringBuilder(@"select distinct  rsn.filename, accs.ntryref, accs.amt,ras.bigmsgidr,ras.totcdamt, valdate from rbi_as_entries accs 							
//                                                        left outer join rbi_response_entries cn on cn.ntryref=accs.ntryref
//                                                        left outer join rbi_response_notifications rsn on rsn.id=accs.ntryref
//                                                        left outer join rbi_as_statement ras on ras.stmtid=accs.stmtid
//                                                        where cn.ntryref is null and cdordb='CRDT' and rvslind = false and valdate=@valdate order by accs.ntryref");

        StringBuilder SelectQuery = new StringBuilder(@"select COALESCE(a.filename,'NA') filename,sum(b.ttlamt) tt,COALESCE(sum(a.mt),0) ttt, b.bigmsgidr,b.valdate from 

                                                     (select sum(amt) ttlamt, st.bigmsgidr,en.ntryref,valdate from rbi_as_entries en
                                                    inner join rbi_as_statement st on st.stmtid=en.stmtid
                                                    where valdate=@valdate and  cdordb='CRDT' and rvslind = false
                                                    group by bigmsgidr,en.ntryref,valdate) b 

                                                    left outer join 

                                                    (select distinct filename,sum(totaltxnamt) mt,en.ntryref from rbi_response_notifications nf
                                                    inner join rbi_response_entries en on nf.id=en.notifyid
                                                    left outer join rbi_response_txns_details txns on en.ntryref=txns.ntryref
                                                    where en.valdt=@valdate  
                                                    group by filename, en.ntryref) a

                                                    on a.ntryref=b.ntryref  
                                                     group by a.filename,b.bigmsgidr,b.valdate");


        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@valdate", date);
        dtforgrid = data.GetDataTable(SelectCmd, "nfs");

    }
    protected void imgbtnback_Click(object sender, ImageClickEventArgs e)
    {
        if (ViewState["PreviousPage"] != null)	//Check if the ViewState 
        //contains Previous page URL
        {
            Response.Redirect(ViewState["PreviousPage"].ToString());//Redirect to 
            //Previous page by retrieving the PreviousPage Url from ViewState.
        }
    }
    protected void imgbtndownload_Click(object sender, ImageClickEventArgs e)
    {
        if (Request.QueryString["dt"] != null)
        {
            fillgrid(MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true));
            Exportfile exp = new Exportfile();
            exp.exportprint(tbldata, "Missing_Entries_In_CN");
        } 
    }
}