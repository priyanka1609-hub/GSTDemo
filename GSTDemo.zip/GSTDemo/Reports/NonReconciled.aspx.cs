﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;


public partial class Reports_NonReconciled : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();

    protected DataTable dtforgrid;
    public string todatecurrent = string.Empty, fromdatecurrent = string.Empty, status=string.Empty;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            //ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState

            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                //if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                //StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                //{
                //    Response.Redirect("Logout.aspx");
                //}
            }
         if (Request.QueryString["status"] != null)
        {
            status = MD5Util.Decrypt(Request.QueryString["status"].ToString(), true);
        }

            // showData();
             todatecurrent = DateTime.Now.ToString("dd/MM/yyyy");
            fromdatecurrent = "01/" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.ToString("yyyy");
            txtfromdate.Text = fromdatecurrent.Replace("-", "/");
            txttodate.Text = todatecurrent.Replace("-", "/");
            if (!string.IsNullOrEmpty(status)&status=="S")
            {
                if (Session["fromdate"] != null && Session["todate"] != null)
                {
                    txtfromdate.Text = Session["fromdate"].ToString();
                    txttodate.Text = Session["todate"].ToString();
                    fillgrid(Session["fromdate"].ToString(), Session["todate"].ToString());
                }
            }
            else
            {
                fillgrid(fromdatecurrent, todatecurrent);
            }
            
        }

       
    }

    protected void fillgrid(string from, string to)
    {
        string date = string.Empty,fromdate=string.Empty;
        Double amtpsb = 0.00d, amtpvt = 0.00d, amtner = 0.00d;
        int nertxns = 0, psbtxns = 0, pvttxns = 0;
        StringBuilder SelectQuery = new StringBuilder(@"select cin,to_char(paymentdatetime,'DD/MM/YYYY') payment_dt,paymentdatetime,banktype,sgst_total from (
                                                        select tec.cin,tec.paymentdatetime,sgst_total,banktype from transactions_eod_cin tec
                                                        inner join master_gstn_banks mgb on mgb.bankcode=tec.bank_cd
							                            left outer join rbi_response_txns_details rbi on rbi.cin=tec.cin
                                                        where rbi.cin is null and sgst_total <> 0.00
                                                        union
                                                        select tec.cin ,tec.paymentdatetime,sgst_total,banktype from transactions_eod_cin tec
                                                        inner join rbi_response_txns_details rbi on rbi.cin = tec.cin
                                                        inner join master_gstn_banks mgb on mgb.bankcode=tec.bank_cd
                                                        where sgst_total > totaltxnamt) t ");

        if (Request.QueryString["dt"] != null)
        {
            date = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true);

            SelectQuery.Append(" where to_char(paymentdatetime,'DD/MM/YYYY')=@paymentdatetime ");
        }
      
        else
        {
            SelectQuery.Append(" where paymentdatetime >= @from and paymentdatetime <= @to");
            fromdate = Utility.pgsqlFromDateFormat(from);
        }

        SelectQuery.Append(" order by paymentdatetime");

        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdatetime", date);
        SelectCmd.Parameters.AddWithValue("@from", fromdate);
        SelectCmd.Parameters.AddWithValue("@to", Utility.pgsqlToDateFormat(to));
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        if (dt.Rows.Count > 0)
        {
            ImageButton1.Visible = true;
            dtforgrid = new DataTable();
            dtforgrid.Clear();
            dtforgrid.Columns.Add("date");
            dtforgrid.Columns.Add("psbtxns");
            dtforgrid.Columns.Add("psbamt");
            dtforgrid.Columns.Add("pvttxns");
            dtforgrid.Columns.Add("pvtamt");
            dtforgrid.Columns.Add("nertxns");
            dtforgrid.Columns.Add("neramt");
            dtforgrid.Columns.Add("totamt");
            dtforgrid.Columns.Add("tottxns");


            int i;
            int dtrowscount = dt.Rows.Count;
            for (i = 0; i < dtrowscount; i++)
            {
                if (i == 0)
                {
                    if (dt.Rows[0]["banktype"].ToString() == "R")
                    {
                        amtner = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                        nertxns++;
                    }
                    else if (dt.Rows[0]["banktype"].ToString() == "G")
                    {
                        amtpsb = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                        psbtxns++;

                    }
                    else if (dt.Rows[0]["banktype"].ToString() == "P")
                    {
                        amtpvt = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                        pvttxns++;

                    }

                }
                else
                {
                    if (dt.Rows[i]["payment_dt"].ToString() == dt.Rows[i - 1]["payment_dt"].ToString())
                    {
                        if (dt.Rows[i]["banktype"].ToString() == "R")
                        {
                            double newamtner = amtner + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtner = newamtner;
                            //amtner = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            nertxns++;
                        }
                        else if (dt.Rows[i]["banktype"].ToString() == "G")
                        {
                            double newamtpsb = amtpsb + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtpsb = newamtpsb;
                            //amtpsb = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            psbtxns++;

                        }
                        else if (dt.Rows[i]["banktype"].ToString() == "P")
                        {
                            double newamtpvt = amtpvt + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtpvt = newamtpvt;

                            //amtpvt = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            pvttxns++;

                        }
                    }
                    else
                    {
                        DataRow dr = dtforgrid.NewRow();
                        dr["date"] = dt.Rows[i - 1]["payment_dt"];
                        dr["psbtxns"] = psbtxns.ToString();
                        dr["psbamt"] = amtpsb.ToString("F2");
                        dr["pvttxns"] = pvttxns.ToString();
                        dr["pvtamt"] = amtpvt.ToString("F2");
                        dr["nertxns"] = nertxns.ToString();
                        dr["neramt"] = amtner.ToString("F2");
                        dr["totamt"] = (amtpsb + amtpvt + amtner).ToString("F2");
                        dr["tottxns"] = (psbtxns + pvttxns + nertxns).ToString();


                        dtforgrid.Rows.Add(dr);

                        amtner = 0.00d;
                        amtpsb = 0.00d;
                        amtpvt = 0.00d;
                        nertxns = 0;
                        psbtxns = 0;
                        pvttxns = 0;

                        if (dt.Rows[i]["banktype"].ToString() == "R")
                        {
                            double newamtner = amtner + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtner = newamtner;
                            //amtner = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            nertxns++;
                        }
                        else if (dt.Rows[i]["banktype"].ToString() == "G")
                        {
                            double newamtpsb = amtpsb + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtpsb = newamtpsb;
                            //amtpsb = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            psbtxns++;

                        }
                        else if (dt.Rows[i]["banktype"].ToString() == "P")
                        {
                            double newamtpvt = amtpvt + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtpvt = newamtpvt;

                            //amtpvt = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                            pvttxns++;

                        }

                    }
                }

            }

            DataRow droneorlast = dtforgrid.NewRow();
            droneorlast["date"] = dt.Rows[i - 1]["payment_dt"];
            droneorlast["psbtxns"] = psbtxns.ToString();
            droneorlast["psbamt"] = amtpsb.ToString("F2");
            droneorlast["pvttxns"] = pvttxns.ToString();
            droneorlast["pvtamt"] = amtpvt.ToString("F2");
            droneorlast["nertxns"] = nertxns.ToString();
            droneorlast["neramt"] = amtner.ToString("F2");
            droneorlast["totamt"] = (amtpsb + amtpvt + amtner).ToString("F2");
            droneorlast["tottxns"] = (psbtxns + pvttxns + nertxns).ToString();
            dtforgrid.Rows.Add(droneorlast);



        }

    }

    protected string unmatchedxnDetails(string rowDate, string src, string banktype,string todate)
    {

        Session["fromdate"] = txtfromdate.Text;
        Session["todate"] = txttodate.Text;
        return md5util.CreateTamperProofURL("../Reports/TxnsPendingForRecon.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true) + "&src=" + MD5Util.Encrypt(src, true) + "&banktype=" + MD5Util.Encrypt(banktype, true) + "&todate=" + MD5Util.Encrypt(todate, true));
    }
    protected void imgbtnback_Click(object sender, ImageClickEventArgs e)
    {
        //if (ViewState["PreviousPage"] != null)	//Check if the ViewState 
        ////contains Previous page URL
        //{
        //Response.Redirect("../Reports/HeadwiseReport.aspx");//Redirect to 
        Response.Redirect("../PAO/DefaultHome.aspx");
        //Previous page by retrieving the PreviousPage Url from ViewState.
        //}
    }
    protected void imgbtndownload_Click(object sender, ImageClickEventArgs e)
    {
        fillgrid(txtfromdate.Text, txttodate.Text);
        Exportfile exp = new Exportfile();
        exp.exportprint(tbldata, "SUSPENSE_DATA");
    }
    protected void btnshowdata_Click(object sender, EventArgs e)
    {
        lblheading.Text = "From " + txtfromdate.Text + " TO " + txttodate.Text;

        fillgrid(txtfromdate.Text, txttodate.Text);
    }
}