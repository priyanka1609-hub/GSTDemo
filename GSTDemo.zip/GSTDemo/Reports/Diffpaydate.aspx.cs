﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using Npgsql;
using System.Data;
using GstDelhi.PostgresData;
using Newtonsoft.Json;
using System.Globalization;


public partial class Reports_Diffpaydate : System.Web.UI.Page
{
     PostgresGetData data = new PostgresGetData();
    protected DataTable sgstdata; protected DataTable rbidata;
    public decimal totalgstn = 0, totalrbi=0;
    public string datechck, fromdatecurrent = string.Empty, todatecurrent = string.Empty;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            
            todatecurrent = DateTime.Now.ToString("dd/MM/yyyy");
            fromdatecurrent = "01/" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.ToString("yyyy");
            txtfromdate.Text = fromdatecurrent.Replace("-", "/");
            txttodate.Text = todatecurrent.Replace("-", "/");
        }
        ShowData(fromdatecurrent, todatecurrent);
    }
    protected void ShowData(string from, string to)
    {
         string fromdate = string.Empty;
        StringBuilder SelectQuery = new StringBuilder("select rbi.cin,to_char(rbi.paymentdatetime,'DD/MM/YYYY HH24:MI:SS') as rbidate,rbi.totaltxnamt as rbiamount,tec.sgst_total as gstntotal,to_char(tec.paymentdatetime,'DD/MM/YYYY HH24:MI:SS') as gstndate from rbi_response_txns_details rbi inner join transactions_eod_cin tec on tec.cin=rbi.cin where to_char(rbi.paymentdatetime,'DD/MM/YYYY') <> to_char(tec.paymentdatetime,'DD/MM/YYYY')");
        SelectQuery.Append(" and rbi.paymentdatetime >= @from and rbi.paymentdatetime <= @to");
        SelectQuery.Append(" order by to_char(rbi.paymentdatetime,'YYYY/MM/DD')");
        fromdate = Utility.pgsqlFromDateFormat(from);
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
       
        SelectCmd.Parameters.AddWithValue("@from", fromdate);
        SelectCmd.Parameters.AddWithValue("@to", Utility.pgsqlToDateFormat(to));
        sgstdata = new DataTable();
        sgstdata = data.GetDataTable(SelectCmd, "nfs");
        if (sgstdata.Rows.Count > 0)
        {
            
            gvpayday.DataSource = sgstdata;
            gvpayday.DataBind();
            divpayday.Visible = true;
        }
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        //base.VerifyRenderingInServerForm(control);
    }

    protected void gvpayday_rowdatabound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label lblgstnamt = (Label)e.Row.FindControl("lblgstnamount");
            Label lblrbiamt = (Label)e.Row.FindControl("lblrbiamount");
            decimal gstntotalamt = decimal.Parse(lblgstnamt.Text);
            decimal rbitotalamount=decimal.Parse(lblrbiamt.Text);
            totalrbi+=rbitotalamount;
            totalgstn+= gstntotalamt;

        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            Label lblgstn = (Label)e.Row.FindControl("lblgstn");
            Label lblrbi = (Label)e.Row.FindControl("lblrbi");
           
            lblgstn.Text = totalgstn.ToString();
            lblrbi.Text=totalrbi.ToString();
      
        } 
    }
    protected void gvpayday_RowEditing(object sender, System.Web.UI.WebControls.GridViewEditEventArgs e)
    {
        //NewEditIndex property used to determine the index of the row being edited.  
        gvpayday.EditIndex = e.NewEditIndex;
        //ShowData();
    }
    protected void gvpayday_rowupdate(object sender, System.Web.UI.WebControls.GridViewUpdateEventArgs e)
    {
        //Finding the controls from Gridview for the row which is going to update  
        Label cin = gvpayday.Rows[e.RowIndex].FindControl("lblcin") as Label;
        TextBox txtrbipayday = gvpayday.Rows[e.RowIndex].FindControl("txtrbipayday") as TextBox;
        string rbidate = txtrbipayday.Text;
        rbidate = rbidate.Replace(" ", "");
        DateTime? dt = Utility.converttodatetime_from_DDMMYY_HHMMSS(rbidate);

        StringBuilder updaterbidate = new StringBuilder("update rbi_response_txns_details set paymentdatetime=@paymentdate where cin=@cin");
        NpgsqlCommand updatedate = new NpgsqlCommand(updaterbidate.ToString());
        updatedate.Parameters.AddWithValue("@paymentdate", dt);
        updatedate.Parameters.AddWithValue("@cin", cin.Text.ToString());
        int getRecordInseretedInner = data.UpdateData(updatedate, "nfs");

        if (getRecordInseretedInner > 0)
        {
            Response.Redirect("../Reports/Diffpaydate.aspx");
        }
      
    }
    protected void gvpayday_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvpayday.EditIndex = -1;

        //GridViewRow row = gvpayday.Rows[e.RowIndex];
        //gvpayday.EditIndex = e.NewEditIndex;
        //ShowData();
    }
    protected void btnshowdata_Click(object sender, EventArgs e)
    {
        
        ShowData(txtfromdate.Text, txttodate.Text);
    }
    protected void imgbtndownload_Click(object sender, ImageClickEventArgs e)
    {

        ShowData(txtfromdate.Text, txttodate.Text);
        Exportfile exp = new Exportfile();
        exp.exportprintgrd(gvpayday, "Different Payment Dates");
    }
 protected void imgbtnback_Click(object sender, ImageClickEventArgs e)
    {
        //if (ViewState["PreviousPage"] != null)	//Check if the ViewState 
        ////contains Previous page URL
        //{
        Response.Redirect("../Reports/HeadwiseReport.aspx");//Redirect to 
        //Previous page by retrieving the PreviousPage Url from ViewState.
        //}
    }
}