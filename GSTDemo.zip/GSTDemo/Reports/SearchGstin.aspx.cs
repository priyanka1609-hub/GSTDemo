﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;


public partial class Reports_SearchGstin : System.Web.UI.Page
{
    MD5Util md5util = new MD5Util();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
        
                string todatecurrent = DateTime.Now.ToString("dd/MM/yyyy");
                string fromdatecurrent = DateTime.Now.Day - 2 + "/" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.ToString("yyyy");
                txtfromdate.Text = fromdatecurrent.Replace("-", "/");
                txttodate.Text = todatecurrent.Replace("-", "/");
            
        }

    }
    protected void btn_getgstin_Click(object sender, EventArgs e)
    {
       
        
        fillgrid(txtfromdate.Text, txttodate.Text, txtgstin.Text);
    }

    private void fillgrid(string from, string to, string gstin)
    {
        
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select tec.cpin,tec.gstin,sgst_tax,sgst_intr,sgst_fee,sgst_pnlty,sgst_oth,sgst_total,tec.cin,pm.modedesc,tec.txnid,bm.bankname,bank_ref_num,to_char(tec.paymentdatetime,'DD/MM/YYYY') as paymentdatetime,utr_num, ack_num,bank_ref_num,br_ifsc_cd, br_location, br_name, instrument_no, instrument_micr_cd, 
                                                        to_char(tec.cpindatetime,'DD/MM/YYYY') as cpindatetime, to_char(tec.pymntackdatetime,'DD/MM/YYYY') as pymntackdatetime, to_char(tec.reportingdatetime,'DD/MM/YYYY') as reportingdatetime from transactions_eod_cin tec
                                                        inner join rbi_response_txns_details rbi on rbi.cin=tec.cin
                                                        inner join master_gstn_pay_mode pm on pm.mode=tec.mode
                                                        inner join master_gstn_banks bm on bm.bankcode=tec.bank_cd
                                                        where tec.paymentdatetime >= @from and tec.paymentdatetime <= @to");

        if (!string.IsNullOrEmpty(gstin))
        {
            SelectQuery.Append(" and tec.gstin=@gstin");
        }
       
        SelectQuery.Append(" order by tec.paymentdatetime");


        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@from", Utility.pgsqlFromDateFormat(from));
        SelectCmd.Parameters.AddWithValue("@to", Utility.pgsqlToDateFormat(to));
        SelectCmd.Parameters.AddWithValue("@gstin", gstin);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
       
        if (dt.Rows.Count > 0)
        {
            imgbtndownload.Visible = true;
            divsrch.Visible = true;
            grdgstfiles.DataSource = dt;
            grdgstfiles.DataBind();
        }
        else
        {
        }
        

    }
    protected void imgbtndownload_Click(object sender, ImageClickEventArgs e)
    {
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=Report.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        StringWriter sw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(sw);
        hw.AddStyleAttribute("horizontal-align", "center");
        hw.Write("GSTN Transaction Details <br/><br/>");
        grdgstfiles.RenderControl(hw);
        StringReader sr = new StringReader(sw.ToString());
        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        htmlparser.Parse(sr);
        pdfDoc.Close();
        Response.Write(pdfDoc);
        Response.End();
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
           server control at run time. */
    }
}