﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;

public partial class Reports_CompareAsCn : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    public string datechck, fromdatecurrent = string.Empty, todatecurrent = string.Empty;

    protected DataTable dtforgrid;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            //ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState
            todatecurrent = DateTime.Now.ToString("dd/MM/yyyy");

            fromdatecurrent = "01/" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.ToString("yyyy");
            txtfromdate.Text = fromdatecurrent.Replace("-", "/");
            txttodate.Text = todatecurrent.Replace("-", "/");


            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Logout.aspx");
                }
            }

            try { datechck = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true); }
            catch { datechck = string.Empty; }

            if (string.IsNullOrEmpty(datechck))
            {
                // showData();
                fillgrid(fromdatecurrent, todatecurrent);

            }
            else
            {           
                fillgrid("", "");
            }
        }

        lblpymtdate.Text = txtfromdate.Text + "&nbsp;&nbsp;";
        lblTodate.Text = txttodate.Text;
        
    }

    protected void fillgrid(string from, string to)
    {
        string date = string.Empty; string fromdate = string.Empty;

        StringBuilder SelectQuery = new StringBuilder(@"select count(accs.ntryref) asntry,sum(accs.amt) asamt,  count(cn.ntryref) cnntry,sum(cn.amt) cnamt, valdate as date from rbi_as_entries accs 
                                                        left outer join rbi_response_entries cn on cn.ntryref=accs.ntryref
                                                        where cdordb='CRDT' and rvslind = false and valdate::timestamp >= @fromdate and  valdate::timestamp <= @todate
                                                        group by valdate order by valdate");



        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());

        SelectCmd.Parameters.AddWithValue("@fromdate", Utility.pgsqlFromDateFormat(from));
        SelectCmd.Parameters.AddWithValue("@todate", Utility.pgsqlToDateFormat(to));

        dtforgrid = data.GetDataTable(SelectCmd, "nfs");

    }

    protected string diffentryurl(string rowDate)
    {
        return md5util.CreateTamperProofURL("../Reports/CnMissedNtry.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true));
    }


    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
           server control at run time. */
    }
    protected void imgbtnback_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("../PAO/DefaultHome.aspx");
    }
    protected void imgbtndownload_Click(object sender, ImageClickEventArgs e)
    {
        fillgrid(txtfromdate.Text, txttodate.Text);
        Exportfile exp = new Exportfile();
        exp.exportprint(tbldata, "CN_AS_Compare_Report");
    }
    protected void btnshowdata_Click(object sender, EventArgs e)
    {
        fillgrid(txtfromdate.Text,txttodate.Text);
    }
}