﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Threading;
using System.Globalization;

public partial class Reports_MonthlyReconciliation : System.Web.UI.Page
{
    public decimal totalamount = 0, totalrbi = 0;
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    public string date;
    public string datechck, fromdatecurrent = string.Empty, todatecurrent = string.Empty, BankName = string.Empty;
    int cins = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            
            todatecurrent = DateTime.Now.ToString("dd/MM/yyyy");
           
            fromdatecurrent = "01/" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.ToString("yyyy");
            txtfromdate.Text = fromdatecurrent.Replace("-", "/");
            txttodate.Text = todatecurrent.Replace("-", "/");


            FillGrid();
        }

        lblpymtdate.Text = txtfromdate.Text + "&nbsp;&nbsp;";
        lblTodate.Text = txttodate.Text;
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        //base.VerifyRenderingInServerForm(control);
    }


    public void FillGrid()
    {
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select bankname,sum(totaltxnamt) totalamtrbi ,count(tec.cin) cin,bankcode
                            from transactions_eod_cin tec 
                            inner join rbi_response_txns_details rbi on rbi.cin = tec.cin
                            inner join master_gstn_banks mgb on mgb.bankcode=tec.bank_cd
                            where sgst_total != 0.00 and sgst_total=totaltxnamt and rbi.paymentdatetime>=@fromDate and 
                                                        rbi.paymentdatetime<=@toDate group by  bankname,bankcode order by bankname");


        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@fromDate", Utility.pgsqlFromDateFormat(txtfromdate.Text) );
        SelectCmd.Parameters.AddWithValue("@toDate", Utility.pgsqlToDateFormat(txttodate.Text));
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        if (dt.Rows.Count > 0)
        {


            
            grdmatchedtxns.DataSource = dt;
            grdmatchedtxns.DataBind();
        }

    }



    protected void btnshowdata_Click(object sender, EventArgs e)
    {
        FillGrid();
    }
    protected void grdmatchedtxns_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label lblrbiamt = (Label)e.Row.FindControl("lblrbiamt");
            LinkButton lnkbtncin = (LinkButton)e.Row.FindControl("lnkbtncin");
            Label lblBankName = (Label)e.Row.FindControl("lblBankName");
            BankName = lblBankName.Text.ToString();
            decimal amount = decimal.Parse(lblrbiamt.Text);
            int cin = Convert.ToInt32(lnkbtncin.Text.ToString());

            totalamount += amount;
            cins += cin;
        }

        if (e.Row.RowType == DataControlRowType.Footer)
        { 
            Label lblrbiTotalAmount = (Label)e.Row.FindControl("lblrbiTotalAmount");
            lblrbiTotalAmount.Text = totalamount.ToString();
            Label lblTotalcin = (Label)e.Row.FindControl("lblTotalcin");
            lblTotalcin.Text = cins.ToString();
        }
    }


    protected void MyButtonClick(object sender, EventArgs e)
    {
        LinkButton lnkButton = (LinkButton)sender;
        GridViewRow Grow = (GridViewRow)lnkButton.NamingContainer;
        Label lblBankName = (Label)Grow.FindControl("lblBankName");
        //HiddenField bankcode = (HiddenField)Grow.FindControl("bankcode");

        string bankcode = grdmatchedtxns.DataKeys[Grow.RowIndex].Values[0].ToString();
        
          
        //string bankcode = grdmatchedtxns.DataKeys[bankcode].Values[0].ToString();

        Response.Redirect("../Reports/BankwiseMatchedCINDetails.aspx?dtf=" + MD5Util.Encrypt(txtfromdate.Text, true) + "&dtto=" + MD5Util.Encrypt(txttodate.Text, true) + "&BankCode=" + MD5Util.Encrypt(bankcode, true));
    }

    protected void imgbtndownload_Click(object sender, ImageClickEventArgs e)
    {
        FillGrid();
        Exportfile exp = new Exportfile();
        exp.exportprint(tbldata, "MATCHED DATA");
    }
    
}