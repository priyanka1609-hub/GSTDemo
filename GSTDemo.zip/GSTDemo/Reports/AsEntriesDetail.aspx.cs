﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;


public partial class Reports_AsEntriesDetail : System.Web.UI.Page
{
    MD5Util md5util = new MD5Util();
    public string trnstype = string.Empty;
    public decimal totalamount = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState
            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Login.aspx?id=0");
                }
                else
                {
                    fillgrid();
                }


            }
            else
            {
                //tbldate.Visible = true;
            }
        }
    }


    private void fillgrid()
    {

        string stmtid = string.Empty;
        if (Request.QueryString["stmtid"] != null)
        {
            stmtid = MD5Util.Decrypt(Request.QueryString["stmtid"].ToString(), true);
        }
        if (Request.QueryString["trnstype"] != null)
        {
            trnstype = MD5Util.Decrypt(Request.QueryString["trnstype"].ToString(), true);
        }


        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select amt,cdordb,rvslind,status,bookingdate,valdate from rbi_as_entries where 1=1 ");
        if (!string.IsNullOrEmpty(stmtid))
        {
            SelectQuery.Append(" and stmtid=@stmtid");
        }
        if (!string.IsNullOrEmpty(trnstype))
        {
            SelectQuery.Append(" and cdordb=@trnstype");
        }
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@trnstype", trnstype.ToString());
        SelectCmd.Parameters.AddWithValue("@stmtid", stmtid.ToString());
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
        if (dt.Rows.Count > 0)
        {
            grdntries.DataSource = dt;
            grdntries.DataBind();
        }


    }
    protected void gvpayday_rowdatabound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            Label lblamount = (Label)e.Row.FindControl("lblamount");
            decimal amt = decimal.Parse(lblamount.Text);

            totalamount += amt;
            

        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            Label lblamt = (Label)e.Row.FindControl("lblamt");


            lblamt.Text = totalamount.ToString();
         

        }
    }
    protected void imgbtnback_Click(object sender, ImageClickEventArgs e)
    {
        if (ViewState["PreviousPage"] != null)	//Check if the ViewState 
        //contains Previous page URL
        {
            Response.Redirect(ViewState["PreviousPage"].ToString());//Redirect to 
            //Previous page by retrieving the PreviousPage Url from ViewState.
        }
    }
}