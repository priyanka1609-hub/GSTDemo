﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;

public partial class Reports_YearWiseTransReport : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    decimal totalamount;
    long totaltrans;
    public string datechck, fromdatecurrent = string.Empty, todatecurrent = string.Empty;
    StringBuilder SelectQuery = null;

    protected DataTable dtforgrid;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {

            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Logout.aspx");
                }
            }
            FillDdl();
            ddlYear.SelectedValue = DateTime.Now.ToString("yyyy");
        }
        FillGrid();
        lblYear.Text = ddlYear.SelectedValue.ToString();

    }

    public void FillDdl()
    {
        var source = new Dictionary<int, int>();
        for (int startyear = 2017; startyear <= Convert.ToInt32(DateTime.Now.ToString("yyyy")); startyear++)
        {
            source.Add(startyear, startyear);
        }

        ddlYear.DataSource = source;
        ddlYear.DataTextField = "Key";
        ddlYear.DataValueField = "Value";
        ddlYear.DataBind();

    }

    public void FillGrid()
    {
        PostgresGetData data = new PostgresGetData();
        if (rdbtnRbiGst.SelectedValue == "RBI")
        {
            SelectQuery = new StringBuilder(@"select count(cin) totoaltrans,sum(amt) totalamount ,to_char(to_timestamp (date_part('month',  paymentdatetime)::text, 'MM'), 'Month') payment_dt ,EXTRACT(MONTH FROM  paymentdatetime) payment_dt1
                                        from rbi_response_txns_details  where date_part('year', paymentdatetime) =@paymentdatetime  
                                      group by EXTRACT(MONTH FROM  paymentdatetime),to_char(to_timestamp (date_part('month',  paymentdatetime)::text, 'MM'), 'Month') order by EXTRACT(MONTH FROM  paymentdatetime) ");
        }

        else
        {
            SelectQuery = new StringBuilder(@"select count(cin) totoaltrans,sum(sgst_total) totalamount ,to_char(to_timestamp (date_part('month',  paymentdatetime)::text, 'MM'), 'Month') payment_dt ,EXTRACT(MONTH FROM  paymentdatetime) payment_dt1
                                        from transactions_eod_cin  where date_part('year', paymentdatetime) =@paymentdatetime  group by EXTRACT(MONTH FROM  paymentdatetime), to_char(to_timestamp (date_part('month',  paymentdatetime)::text, 'MM'), 'Month') order by EXTRACT(MONTH FROM  paymentdatetime) ");
        }
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@paymentdatetime ", ddlYear.SelectedValue.ToString());
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        if (dt.Rows.Count > 0)
        {
            grdmatchedtxns.DataSource = dt;
            grdmatchedtxns.DataBind();
        }
    }

    protected void grdmatchedtxns_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label lblAmount = (Label)e.Row.FindControl("lblAmount");
            Label lblTotalTrans = (Label)e.Row.FindControl("lblTotalTrans");

            decimal amount = decimal.Parse(lblAmount.Text);
            int trans = Convert.ToInt32(lblTotalTrans.Text.ToString());

            totalamount += amount;
            totaltrans += trans;
        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            Label lblTotalTransF = (Label)e.Row.FindControl("lblTotalTransF");
            Label lblTotalAmount = (Label)e.Row.FindControl("lblTotalAmount");
            lblTotalTransF.Text = totaltrans.ToString();
            lblTotalAmount.Text = totalamount.ToString();
        }
    }


    protected void imgbtndownload_Click(object sender, ImageClickEventArgs e)
    {
        FillGrid();
        Exportfile exp = new Exportfile();
        exp.exportprint(tbldata, "MonthWiseReport");
    }
    public override void VerifyRenderingInServerForm(Control control)
    {
        //base.VerifyRenderingInServerForm(control);
    }
}