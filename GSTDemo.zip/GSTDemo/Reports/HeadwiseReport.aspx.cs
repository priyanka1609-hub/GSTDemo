﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;
using System.Globalization;



public partial class Reports_HeadwiseReport : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();

    protected DataTable dtforgrid;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {    
            fillYearDDL();
            fillMonthDDL();
        }
        fillgrid();
           
    }

    public void fillYearDDL()
    {
        ddlyear.DataTextField = "Year";
        ddlyear.DataValueField = "Year";
        Int64 defyr = 2017;
        Int64 diff = Convert.ToInt64(DateTime.Now.Year) - defyr;
        for (int i=0;i<=diff;i++)
        {
            string value = Convert.ToString(defyr + i);
            ddlyear.Items.Add(new ListItem(value,value));
        }

        ddlyear.SelectedValue = DateTime.Now.Year.ToString();
    }
    public void fillMonthDDL()
    {
        ddlmonth.Items.Clear();
        int startval = 1;
        int lastval = 12;
        if (ddlyear.SelectedValue == "2017")
        {
            startval = 6;
        }

        if (ddlyear.SelectedValue == DateTime.Now.Year.ToString())
        {
            lastval = DateTime.Now.Month;
        }
        for ( int i=startval; i <= lastval; i++)
        {
            string val;
            if (i.ToString().Length == 1)
            {
                val = "0" + i + "";
            }
            else
            {
                val = i.ToString();
            }

            ddlmonth.Items.Add(new System.Web.UI.WebControls.ListItem(DateTimeFormatInfo.CurrentInfo.GetMonthName(i), val));
        }
        string crntmonth = DateTime.Now.Month.ToString();
        if (crntmonth.Length == 1)
        {
            crntmonth = "0" + crntmonth + "";
        }
        ddlmonth.SelectedValue = crntmonth;

    }
    protected void fillgrid()
    {
        Double amtner = 0.00d, amtepy = 0.00d;
        int nertxns = 0, epytxns = 0;
        string mnthyr = ddlmonth.SelectedValue + "/" + ddlyear.SelectedValue;
        StringBuilder SelectQuery = new StringBuilder(@"select cin,mode,sgst_total,to_char(paymentdatetime,'DD/MM/YYYY') payment_dt,paymentdatetime from transactions_eod_cin where sgst_total != 0.00 and to_char(Paymentdatetime,'MM/YYYY')=@monthyear order by paymentdatetime");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@monthyear", mnthyr);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        if (dt.Rows.Count > 0)
        {
            dtforgrid = new DataTable();
            dtforgrid.Clear();
            dtforgrid.Columns.Add("date");
            //dtforgrid.Columns.Add("neramt");
            dtforgrid.Columns.Add("epyamt");
            dtforgrid.Columns.Add("rbiamt");
            dtforgrid.Columns.Add("matchedamt");
            dtforgrid.Columns.Add("unmatchedamt");
            dtforgrid.Columns.Add("suspense");
            dtforgrid.Columns.Add("rat");
            //dtforgrid.Columns.Add("nertxns");
            dtforgrid.Columns.Add("epytxns");
            dtforgrid.Columns.Add("rbitxns");
            dtforgrid.Columns.Add("matchedtxns");
            dtforgrid.Columns.Add("suspensetxns");
            dtforgrid.Columns.Add("rattxns");
            dtforgrid.Columns.Add("ratsustxns");
            dtforgrid.Columns.Add("tax");
            dtforgrid.Columns.Add("intr");
            dtforgrid.Columns.Add("pnlty");
            dtforgrid.Columns.Add("fee");
            dtforgrid.Columns.Add("oth");
            dtforgrid.Columns.Add("totalminor");

            int i;
            int dtrowscount = dt.Rows.Count;
            for (i=0; i < dtrowscount; i++)
            {
                if (i == 0)
                {
                    if (dt.Rows[0]["mode"].ToString() == "ner")
                    {
                        amtner = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                        nertxns++;
                    }
                    else
                    {
                        amtepy = Convert.ToDouble(dt.Rows[0]["sgst_total"].ToString());
                        epytxns++;
                        
                    }

                }
                else
                {
                    if (dt.Rows[i]["payment_dt"].ToString() == dt.Rows[i - 1]["payment_dt"].ToString())
                    {
                        if (dt.Rows[i]["mode"].ToString() == "ner")
                        {
                            double newamt = amtner + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtner = newamt;
                            nertxns++;
                        }
                        else
                        {
                            double newamt = amtepy + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtepy = newamt;
                            epytxns++;
                        }
                    }
                    else
                    {
                        DataRow dr = dtforgrid.NewRow();
                        dr["date"] = dt.Rows[i - 1]["payment_dt"];
                        //dr["neramt"] = amtner.ToString("F2");
                        dr["epyamt"] = (amtepy+amtner).ToString("F2");
                        //dr["nertxns"] = nertxns.ToString();
                        dr["epytxns"] = (epytxns+nertxns).ToString();
                        dtforgrid.Rows.Add(dr);

                        amtner = 0;
                        amtepy = 0;
                        nertxns = 0;
                        epytxns = 0;

                        if (dt.Rows[i]["mode"].ToString() == "ner")
                        {
                            double newamt = amtner + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtner = newamt;
                            nertxns++;
                        }
                        else
                        {
                            double newamt = amtepy + Convert.ToDouble(dt.Rows[i]["sgst_total"].ToString());
                            amtepy = newamt;
                            epytxns++;
                        }

                    }
                }

            }

            DataRow droneorlast = dtforgrid.NewRow();
            droneorlast["date"] = dt.Rows[dtrowscount-1]["payment_dt"];
            //droneorlast["neramt"] = amtner.ToString("F2");
            droneorlast["epyamt"] = (amtepy + amtner).ToString("F2");
            //dr["nertxns"] = nertxns.ToString();
            droneorlast["epytxns"] = (epytxns + nertxns).ToString();
            dtforgrid.Rows.Add(droneorlast);

            for (int j = 0; j < dtforgrid.Rows.Count; j++)
            {
                SelectQuery = new StringBuilder(@"select COALESCE(sum(tec.sgst_tax),'0.00') sgst_tax,COALESCE(sum(tec.sgst_intr),'0.00') sgst_intr,COALESCE(sum(tec.sgst_pnlty),'0.00') sgst_pnlty,COALESCE(sum(tec.sgst_oth),'0.00') sgst_oth, COALESCE(sum(tec.sgst_fee),'0.00') sgst_fee,COALESCE(sum(amt),'0.00') sum,COALESCE(sum(sgst_total),'0.00') matchedsum, count(rbi.cin) rbitxns, count(tec.cin) matchedtxns  from rbi_response_txns_details rbi
                                                left outer join transactions_eod_cin tec on tec.cin = rbi.cin and rbi.totaltxnamt=tec.sgst_total 
                                                where to_char(rbi.paymentdatetime,'DD/MM/YYYY') = @paymentdatetime ");
                SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
                SelectCmd.Parameters.AddWithValue("@paymentdatetime", dtforgrid.Rows[j]["date"].ToString());
                dt = data.GetDataTable(SelectCmd, "nfs");

                dtforgrid.Rows[j]["rbitxns"] = dt.Rows[0]["rbitxns"].ToString();
                dtforgrid.Rows[j]["matchedtxns"] = dt.Rows[0]["matchedtxns"].ToString();
                //dtforgrid.Rows[j]["suspensetxns"] = Math.Max(0,(Convert.ToInt32(dtforgrid.Rows[j]["epytxns"].ToString()) + Convert.ToInt32(dtforgrid.Rows[j]["nertxns"].ToString())) - Convert.ToInt32(dt.Rows[0]["matchedtxns"].ToString()));
                dtforgrid.Rows[j]["suspensetxns"] = Math.Max(0, (Convert.ToInt32(dtforgrid.Rows[j]["epytxns"].ToString()) - Convert.ToInt32(dt.Rows[0]["matchedtxns"].ToString())));
                dtforgrid.Rows[j]["rattxns"] = Math.Abs(Convert.ToInt32(dt.Rows[0]["rbitxns"].ToString()) - Convert.ToInt32(dt.Rows[0]["matchedtxns"].ToString()));
                dtforgrid.Rows[j]["ratsustxns"] = Convert.ToInt32(dtforgrid.Rows[j]["suspensetxns"].ToString()) + Convert.ToInt32(dtforgrid.Rows[j]["rattxns"].ToString());
                dtforgrid.Rows[j]["tax"] = dt.Rows[0]["sgst_tax"].ToString();
                dtforgrid.Rows[j]["intr"] = dt.Rows[0]["sgst_intr"].ToString();
                dtforgrid.Rows[j]["pnlty"] = dt.Rows[0]["sgst_pnlty"].ToString();
                dtforgrid.Rows[j]["fee"] = dt.Rows[0]["sgst_fee"].ToString();
                dtforgrid.Rows[j]["oth"] = dt.Rows[0]["sgst_oth"].ToString();
                dtforgrid.Rows[j]["totalminor"] = (Convert.ToDecimal(dt.Rows[0]["sgst_tax"].ToString())+Convert.ToDecimal(dt.Rows[0]["sgst_intr"].ToString())+Convert.ToDecimal(dt.Rows[0]["sgst_pnlty"].ToString())+Convert.ToDecimal(dt.Rows[0]["sgst_fee"].ToString())+Convert.ToDecimal(dt.Rows[0]["sgst_oth"].ToString()));
                
                if (dt.Rows[0]["sum"].ToString() == "0")
                {
                    dtforgrid.Rows[j]["rbiamt"] = "---";
                }
                else
                {
                    dtforgrid.Rows[j]["rbiamt"] = dt.Rows[0]["sum"].ToString();
                    dtforgrid.Rows[j]["matchedamt"] = dt.Rows[0]["matchedsum"].ToString();
                    //dtforgrid.Rows[j]["suspense"] = Math.Max(0,(Convert.ToDecimal(dtforgrid.Rows[j]["epyamt"].ToString()) + Convert.ToDecimal(dtforgrid.Rows[j]["neramt"].ToString())) - Convert.ToDecimal(dt.Rows[0]["matchedsum"].ToString())).ToString();
                    dtforgrid.Rows[j]["suspense"] = Math.Max(0, (Convert.ToDecimal(dtforgrid.Rows[j]["epyamt"].ToString())) - Convert.ToDecimal(dt.Rows[0]["matchedsum"].ToString())).ToString();
                    dtforgrid.Rows[j]["rat"] = Math.Abs(Convert.ToDecimal(dt.Rows[0]["sum"].ToString()) - Convert.ToDecimal(dt.Rows[0]["matchedsum"].ToString())).ToString();
                    dtforgrid.Rows[j]["unmatchedamt"] = Math.Abs(Convert.ToDecimal(dtforgrid.Rows[j]["rat"].ToString()) + (Convert.ToDecimal(dtforgrid.Rows[j]["suspense"].ToString()))).ToString();
                    dtforgrid.Rows[j]["tax"] = dt.Rows[0]["sgst_tax"].ToString();
                    dtforgrid.Rows[j]["intr"] = dt.Rows[0]["sgst_intr"].ToString();
                    dtforgrid.Rows[j]["pnlty"] = dt.Rows[0]["sgst_pnlty"].ToString();
                    dtforgrid.Rows[j]["fee"] = dt.Rows[0]["sgst_fee"].ToString();
                    dtforgrid.Rows[j]["oth"] = dt.Rows[0]["sgst_oth"].ToString();
                    dtforgrid.Rows[j]["totalminor"] = (Convert.ToDecimal(dt.Rows[0]["sgst_tax"].ToString()) + Convert.ToDecimal(dt.Rows[0]["sgst_intr"].ToString()) + Convert.ToDecimal(dt.Rows[0]["sgst_pnlty"].ToString()) + Convert.ToDecimal(dt.Rows[0]["sgst_fee"].ToString()) + Convert.ToDecimal(dt.Rows[0]["sgst_oth"].ToString()));
                    
                }

            }

           
        }
        
    }

    

    protected string ReturnURl(string rowDate)
    {
            
       return  md5util.CreateTamperProofURL("../Reports/MinorHeadReport.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true));        
    }


    protected string bankWiseURL(string rowDate)
    {

        return md5util.CreateTamperProofURL("../Reports/BankWiseReport.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true));
    }

    protected string matchedURL(string rowDate)
    {

        //return md5util.CreateTamperProofURL("../Reports/MatchedTxns.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true));

        return md5util.CreateTamperProofURL("../Reports/Reconciliation.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true));
    }

    protected string gstnTxnDetails(string rowDate, string mode)
    {

        //return md5util.CreateTamperProofURL("../Reports/GstnEodcinDetails.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true) + "&mode=" + MD5Util.Encrypt(mode, true));
        return md5util.CreateTamperProofURL("../Reports/GstnRecHeads.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true) + "&mode=" + MD5Util.Encrypt(mode, true));
    }
    protected string rbiTxnDetails(string rowDate)
    {

        //return md5util.CreateTamperProofURL("../Reports/RbiScrollDetails.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true));

        return md5util.CreateTamperProofURL("../Reports/RbiRecHeads.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true));
    }
    protected string unmatchedxnDetails(string rowDate, string src)
    {

        return md5util.CreateTamperProofURL("../Reports/TxnsPendingForRecon.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true) + "&src=" + MD5Util.Encrypt(src, true));
    }

    protected string suspenseTxnDetails(string rowDate)
    {

        return md5util.CreateTamperProofURL("../Reports/NonReconciled.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true));
    }
    protected string ratTxnDetails(string rowDate)
    {

        return md5util.CreateTamperProofURL("../Reports/NonReconciledRat.aspx", null, "dt=" + MD5Util.Encrypt(rowDate, true));
    }

    protected void ddlyear_SelectedIndexChanged(object sender, EventArgs e)
    {
        fillMonthDDL();
    }
    protected void btnshow_Click(object sender, EventArgs e)
    {
        fillgrid();
    }
}