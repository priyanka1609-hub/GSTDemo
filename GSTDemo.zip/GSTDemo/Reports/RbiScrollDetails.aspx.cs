﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;

public partial class Reports_RbiScrollDetails : System.Web.UI.Page
{
    MD5Util md5util = new MD5Util();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState

            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Login.aspx?id=0");
                }
                else
                {
                    fillgrid();
                }
            }
        }


    }


    private void fillgrid()
    {
        string filedate = string.Empty, paymentdate = string.Empty, banktype = string.Empty, filename = string.Empty;
        if (Request.QueryString["filedt"] != null)
        {
            filedate = MD5Util.Decrypt(Request.QueryString["filedt"].ToString(), true);
        }
        if (Request.QueryString["dt"] != null)
        {
            paymentdate = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true);
        }
        if (Request.QueryString["banktype"] != null)
        {
            banktype = MD5Util.Decrypt(Request.QueryString["banktype"].ToString(), true);
        }
        if (Request.QueryString["filenm"] != null)
        {
            filename = MD5Util.Decrypt(Request.QueryString["filenm"].ToString(), true);
        }

        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select rt.cin,rbirefno,cpin,utrno,brn,chqno,senderifsc,micrbranchcode,majorhead, to_char(accptncdttm,'DD/MM/YYYY HH:MI:SS') as accptncdttm,to_char(paymentdatetime,'DD/MM/YYYY HH:MI:SS') as txndttm,pm.modedesc,rt.totaltxnamt,ms.statusdesc rconstatus from rbi_response_notifications rn
                                                        inner join rbi_response_entries re on re.notifyid=rn.id
                                                        inner join rbi_response_txns_details rt on rt.ntryref=re.ntryref
                                                        inner join master_rbi_pay_mode pm on pm.mode=rt.mode
                                                        inner join master_gstn_banks mgb on mgb.bankcode=substring(cin from 1 for 4)
                                                        left outer join moe_compact mc on mc.cin=rt.cin
                                                        left outer join master_status ms on ms.statuscode=mc.status
                                                        where 1=1 ");

        if (!string.IsNullOrEmpty(filedate))
        {
            SelectQuery.Append(" and to_char(scrolldate,'DD/MM/YYYY')=@filedate");
        }
        if (!string.IsNullOrEmpty(paymentdate))
        {
            SelectQuery.Append(" and to_char(paymentdatetime,'DD/MM/YYYY')=@paymentdate");
        }
        if (!string.IsNullOrEmpty(banktype))
        {
            SelectQuery.Append(" and mgb.banktype=@banktype");
        }
        //if (!string.IsNullOrEmpty(banktype) && banktype.ToString() != "N")
        //{
        //    if (banktype == "O")
        //    {
        //        SelectQuery.Append(" and mgb.banktype in ('G','P')  ");
        //    }
        //    else
        //    {
        //        SelectQuery.Append(" and mgb.banktype=@banktype  ");
        //    }
        //}
        if (!string.IsNullOrEmpty(filename))
        {
            SelectQuery.Append(" and rn.filename=@filename");
        }

        SelectQuery.Append(" order by paymentdatetime ;");

        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@filedate", filedate);
        SelectCmd.Parameters.AddWithValue("@paymentdate", paymentdate);
        SelectCmd.Parameters.AddWithValue("@banktype", banktype);
        SelectCmd.Parameters.AddWithValue("@filename", filename);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
        ImageButton1.Visible = true;
        grdrbitxndetails.DataSource = dt;
        grdrbitxndetails.DataBind();

    }
    protected void imgbtndownload_Click(object sender, ImageClickEventArgs e)
    {
        Response.ContentType = "application/pdf";
        Response.AddHeader("content-disposition", "attachment;filename=Rbitxndetails.pdf");
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        StringWriter sw = new StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(sw);
        hw.AddStyleAttribute("horizontal-align", "center");
        hw.Write("RBI Transaction Details <br/><br/>");
        grdrbitxndetails.RenderControl(hw);
        StringReader sr = new StringReader(sw.ToString());
        Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
        HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        pdfDoc.Open();
        htmlparser.Parse(sr);
        pdfDoc.Close();
        Response.Write(pdfDoc);
        Response.End();
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Confirms that an HtmlForm control is rendered for the specified ASP.NET
           server control at run time. */
    }
    protected void imgbtnback_Click(object sender, ImageClickEventArgs e)
    {
        if (ViewState["PreviousPage"] != null)	//Check if the ViewState 
        //contains Previous page URL
        {
            Response.Redirect(ViewState["PreviousPage"].ToString());//Redirect to 
            //Previous page by retrieving the PreviousPage Url from ViewState.
        }
    }
}