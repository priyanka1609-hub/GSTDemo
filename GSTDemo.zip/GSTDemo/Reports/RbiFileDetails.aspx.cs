﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Threading;

public partial class Reports_RbiFileDetails : System.Web.UI.Page
{
    MD5Util md5util = new MD5Util();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState

            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Login.aspx?id=0");
                }
                else
                {
                    fillgrid();
                }
            }
        }
    }

    private void fillgrid()
    {
        string filedate = string.Empty, paymentdate = string.Empty, banktype = string.Empty;
        if (Request.QueryString["filedt"] != null)
        {
            filedate = MD5Util.Decrypt(Request.QueryString["filedt"].ToString(), true);
        }
   

        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select bizmsgidr as filename,sum(nboftxs) txns,to_char(rh.acksentdate,'DD/MM/YYYY HH24:MI:SS') ackdate ,acksent,to_char(rh.scrolldate,'DD/MM/YYYY') filedate, count(rn.nbofntries) ntries from rbi_response_header rh
                                                        inner join rbi_response_notifications rn on rh.bizmsgidr=rn.filename
                                                        inner join rbi_response_entries re on re.notifyid=rn.id
                                                        where to_char(rh.scrolldate,'DD/MM/YYYY')=@filedate
                                                        group by bizmsgidr ");

        //if (!string.IsNullOrEmpty(filedate))
        //{
        //    SelectQuery.Append(" and to_char(scrolldate,'DD/MM/YYYY')=@filedate");
        //}
        //if (!string.IsNullOrEmpty(paymentdate))
        //{
        //    SelectQuery.Append(" and to_char(paymentdatetime,'DD/MM/YYYY')=@paymentdate");
        //}
        //if (!string.IsNullOrEmpty(banktype))
        //{
        //    SelectQuery.Append(" and mgb.banktype=@banktype");
        //}

        //SelectQuery.Append(" order by paymentdatetime ;");

        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@filedate", filedate);
        //SelectCmd.Parameters.AddWithValue("@paymentdate", paymentdate);
        //SelectCmd.Parameters.AddWithValue("@banktype", banktype);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
        //ImageButton1.Visible = true;
        grdrbitxndetails.DataSource = dt;
        grdrbitxndetails.DataBind();

        

       

    }


    protected void grdrbifiles_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            string flname = grdrbitxndetails.DataKeys[e.Row.RowIndex].Values["filename"].ToString();
            HyperLink hylnktxns = (HyperLink)e.Row.FindControl("hylnktxns");
            hylnktxns.NavigateUrl = md5util.CreateTamperProofURL("~/Reports/RbiScrollDetails.aspx", null, "filenm=" + MD5Util.Encrypt(flname, true));
        }

    }
    protected void grdrbifiles_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "download")
        {
            LinkButton lnkView = (LinkButton)e.CommandSource;
            GridViewRow myRow = (GridViewRow)lnkView.Parent.Parent;  // the row
            GridView myGrid = (GridView)sender;
            string filename = myGrid.DataKeys[myRow.RowIndex].Values["filename"].ToString();

            try
            {
                string filenamexml =  ""+filename+".XML";
                string path = Constants.SAVED_FILE_PATH + "RBI\\RAWDATA\\" + filenamexml;
                System.IO.FileStream fs = null;
                fs = System.IO.File.Open(path, System.IO.FileMode.Open);
                byte[] btFile = new byte[fs.Length];
                fs.Read(btFile, 0, Convert.ToInt32(fs.Length));
                fs.Close();
                Response.AddHeader("Content-disposition", "attachment; filename=" + filename);
                Response.ContentType = "application/octet-stream";
                Response.BinaryWrite(btFile);
                Response.End();
            }
            catch (ThreadAbortException ex1)
            {
                // do nothing
            }
            catch (Exception ex)
            {
                ExceptionLogging.logException(ex);
            }
        }
    }
    protected void imgbtnback_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("RbiDownloadedFiles.aspx");
    }
}