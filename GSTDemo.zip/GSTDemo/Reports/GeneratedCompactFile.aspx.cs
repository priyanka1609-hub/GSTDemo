﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Threading;

public partial class Reports_GeneratedCompactFile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        fillgrid();
    }

    protected void fillgrid()
    {
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select to_char(insertdatetime,'DD/MM/YYYY HH24:MI:SS') gendatetime, filename, mu.uc_name, to_char(insertdatetime,'YYYYMMDD') gendate from compact_files cf
                                                        inner join master_users mu on mu.user_id=cf.userid  where completed = 'Y' order by insertdatetime desc");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        grdcompact.DataSource = dt;
        grdcompact.DataBind();
    }


    protected void grdcompact_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        try
        {
            string[] arg = new string[2];
            arg = e.CommandArgument.ToString().Split(';');
            string date = arg[0];
            string filename = arg[1];
            string path = Constants.SAVED_FILE_PATH + "PAO\\" + date.Substring(0, 4) + "\\" + date.Substring(4, 2) + "\\" + date.Substring(6, 2) + "\\" + filename;
            System.IO.FileStream fs = null;
            fs = System.IO.File.Open(path, System.IO.FileMode.Open);
            byte[] btFile = new byte[fs.Length];
            fs.Read(btFile, 0, Convert.ToInt32(fs.Length));
            fs.Close();
            Response.AddHeader("Content-disposition", "attachment; filename=" + filename);
            Response.ContentType = "application/octet-stream";
            Response.BinaryWrite(btFile);
            Response.End();
        }
        catch (ThreadAbortException ex1)
        {
            // do nothing
        }
        catch (Exception ex)
        {
            ExceptionLogging.logException(ex);
        }

        
    }
}