﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;


public partial class Reports_GstnDownloadedFiles : System.Web.UI.Page
{

    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    public string datechck;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            try { datechck = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true); }
            catch { datechck = string.Empty; }

            if (string.IsNullOrEmpty(datechck))
            {
                // showData();
                string todatecurrent = DateTime.Now.ToString("dd/MM/yyyy");
                string fromdatecurrent = "01/" + DateTime.Now.ToString("MM") + "/" + DateTime.Now.ToString("yyyy");
                txtfromdate.Text = fromdatecurrent.Replace("-", "/");
                txttodate.Text = todatecurrent.Replace("-", "/");
                fillgrid(fromdatecurrent, todatecurrent);

            }
            else
            {
                fromtodate.Visible = false;
                fillgrid("", "");

            }
        }
    }

    private void fillgrid(string from, string to)
    {
        string fromdate = string.Empty;
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select fcountid,num_files,count(frcid) incorporated,to_char(fc.filedate,'DD/MM/YYYY') as filedate,fc.filetype from files_count fc
                                                        inner join file_record_count frc on fc.fcountid = frc.filecntid 
                                                        where fc.status='1' and frc.validfile='Y'");
        if (!string.IsNullOrEmpty(from))
        {
            SelectQuery.Append(" and frc.filedate >= @from and frc.filedate <= @to");
            fromdate = Utility.pgsqlFromDateFormat(from);
        }
        SelectQuery.Append("  group by fcountid,fc.filetype,fc.filedate,num_files order by fc.filedate desc");
       
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@from", fromdate);
        SelectCmd.Parameters.AddWithValue("@to", Utility.pgsqlToDateFormat(to));
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");

        grdgstfiles.DataSource = dt;
        grdgstfiles.DataBind();
    }

    protected void grdgstfiles_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            string id = grdgstfiles.DataKeys[e.Row.RowIndex].Values["fcountid"].ToString();
            HyperLink hylnkhylnkincor = (HyperLink)e.Row.FindControl("hylnkincor");
            hylnkhylnkincor.NavigateUrl = md5util.CreateTamperProofURL("~/Reports/GstnFileRecCount.aspx", null, "id=" + MD5Util.Encrypt(id, true));
        }

    }

    protected void btnshowdata_Click(object sender, EventArgs e)
    {
        fillgrid(txtfromdate.Text, txttodate.Text);
    }
}