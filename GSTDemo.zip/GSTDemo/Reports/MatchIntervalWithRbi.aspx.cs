﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;


public partial class Reports_MatchIntervalWithRbi : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    public string datechck, fromdatecurrent = string.Empty, todatecurrent = string.Empty;

    public DataTable dtboth=new DataTable();
    public DataTable dtgstn = new DataTable();
    public DataTable dtrbi = new DataTable();



    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) //check if the webpage is loaded for the first time.
        {
            //ViewState["PreviousPage"] = Request.UrlReferrer;//Saves the Previous page url in ViewState

            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Logout.aspx");
                }
            }



        }




        fillgrid();
    }

    protected string gstnTxnDetails(string month, string matchtype)
    {
        return md5util.CreateTamperProofURL("../Reports/MatchintervalrbiDetails.aspx", null, "month=" + MD5Util.Encrypt(month, true) + "&matchtype=" + MD5Util.Encrypt(matchtype, true));
    }
    public void fillgrid()
    {
        StringBuilder SelectQuery = new StringBuilder(@"select count(tc.cin) as countboth,substring(payment_dt from 4 for 7) as paymentmonth,sum(sgst_amt) as gstnamount,sum(totaltxnamt) as rbiamount  from transactions_cin tc inner join  rbi_response_txns_details rrtd on tc.cin=rrtd.cin  where  substring(payment_dt from 7 for 4)<>@year group by substring(payment_dt from 4 for 7)");
        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@year", "2018");
         dtboth = data.GetDataTable(SelectCmd, "nfs");

         StringBuilder SelectQuery1 = new StringBuilder(@"select count(tc.cin) as countgstn,substring(payment_dt from 4 for 7) as paymentmonth,sum(sgst_amt) as gstnamount from transactions_cin tc left outer join  rbi_response_txns_details rrtd on tc.cin=rrtd.cin  where substring(payment_dt from 7 for 4)<>@year and rrtd.cin is null group by substring(payment_dt from 4 for 7)");
        NpgsqlCommand SelectCmd1 = new NpgsqlCommand(SelectQuery1.ToString());
        SelectCmd1.Parameters.AddWithValue("@year", "2018");
        //SelectCmd1.Parameters.AddWithValue("@month", "08/2017");
        dtgstn = data.GetDataTable(SelectCmd1, "nfs");

        StringBuilder SelectQuery2 = new StringBuilder(@"select count(tc.cin) as countrbi,substring(to_char(paymentdatetime,'DD/MM/YYYY') from 4 for 7) as paymentmonth,sum(totaltxnamt) as rbiamount from rbi_response_txns_details  tc left outer join  transactions_cin rrtd on tc.cin=rrtd.cin  where substring(to_char(paymentdatetime,'DD/MM/YYYY') from 7 for 4)<>@year and  rrtd.cin is null group by substring(to_char(paymentdatetime,'DD/MM/YYYY') from 4 for 7)");
        NpgsqlCommand SelectCmd2 = new NpgsqlCommand(SelectQuery2.ToString());
        SelectCmd2.Parameters.AddWithValue("@year", "2018");
        //SelectCmd2.Parameters.AddWithValue("@month", "08/2017");
        dtrbi = data.GetDataTable(SelectCmd2, "nfs");
    }
}