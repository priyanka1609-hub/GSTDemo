﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GstDelhi.PostgresData;
using System.Text;
using Npgsql;
using System.Data;
using System.Xml;
using System.Security.Cryptography.Xml;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Threading;
using System.Globalization;

public partial class Reports_AfterReconciliation : System.Web.UI.Page
{
    PostgresGetData data = new PostgresGetData();
    MD5Util md5util = new MD5Util();
    message msg = new message();
    protected DataTable dtforgrid;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (StringUtil.GetQueryString(Request.Url.ToString()) != null)
            {

                if (md5util.IsURLTampered(StringUtil.GetWithoutDigest(StringUtil.GetQueryString(Request.Url.ToString())),
                StringUtil.GetDigest(StringUtil.GetQueryString(Request.Url.ToString()))) == true)
                {
                    Response.Redirect("Logout.aspx");
                }
                else
                {
                    if (Request.QueryString["dt"] != null)
                    {
                        string date = MD5Util.Decrypt(Request.QueryString["dt"].ToString(), true);
                        fromtodate.Visible = false;
                        fillInitialData(date);
                        fillReconciledData(date);
                        aftrrecncldiv.Visible = true;
                        lblerror.Visible = false;
                    }
                    //else
                    //{
                    //    string date = txtdate.Text;
                    //    chckrecords(date);
                      
                    //    aftrrecncldiv.Visible = true;
                    //}
                }
            }

            
        }
    }
    protected void chckrecords(string date)
    {
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectchcQuery = new StringBuilder(@"select cfileid from compact_files where to_char(paymentdate,'DD/MM/YYYY')=@date  ");
        NpgsqlCommand SelectchckCmd = new NpgsqlCommand(SelectchcQuery.ToString());
        SelectchckCmd.Parameters.AddWithValue("@date", date);
        DataTable dtchck = data.GetDataTable(SelectchckCmd, "nfs");
        if (dtchck.Rows.Count > 0)
        {
            fillInitialData(date);
            fillReconciledData(date);
            aftrrecncldiv.Visible = true;
            lblerror.Visible = false;
        }
        else
        {
            lblerror.Visible = true;
            aftrrecncldiv.Visible = false;
        }
    }
    protected void fillInitialData(string date)
    {
        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select COALESCE(sum(sgst_total),'0.00') taxamt,banktype from transactions_eod_cin tec
                                                        inner join master_gstn_banks mb on mb.bankcode=tec.bank_cd
                                                        where to_char(paymentdatetime,'DD/MM/YYYY')=@date
                                                        group by banktype  ");

        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@date", date);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
        if (dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i]["banktype"].ToString() == "G")
                {
                    lbl108.Text = dt.Rows[i]["taxamt"].ToString();
                }
                else if (dt.Rows[i]["banktype"].ToString() == "P")
                {
                    lbl138.Text = dt.Rows[i]["taxamt"].ToString();
                }
                else
                {
                    lblner.Text = dt.Rows[i]["taxamt"].ToString();
                }
            }

        }
    }

    protected void fillReconciledData(string date)
    {
        string defval = "0.00";
        dtforgrid = new DataTable();
        dtforgrid.Clear();
        dtforgrid.Columns.Add("date");
        dtforgrid.Columns.Add("paydate");
        dtforgrid.Columns.Add("amtpsb");
        dtforgrid.Columns.Add("amtpvt");
        dtforgrid.Columns.Add("amtner");
        dtforgrid.Columns.Add("psbtax");
        dtforgrid.Columns.Add("psbintr");
        dtforgrid.Columns.Add("psbfee");
        dtforgrid.Columns.Add("psbpnlty");
        dtforgrid.Columns.Add("psboth");
        dtforgrid.Columns.Add("pvttax");
        dtforgrid.Columns.Add("pvtintr");
        dtforgrid.Columns.Add("pvtfee");
        dtforgrid.Columns.Add("pvtpnlty");
        dtforgrid.Columns.Add("pvtoth");
        dtforgrid.Columns.Add("nertax");
        dtforgrid.Columns.Add("nerintr");
        dtforgrid.Columns.Add("nerfee");
        dtforgrid.Columns.Add("nerpnlty");
        dtforgrid.Columns.Add("neroth");
        dtforgrid.Columns.Add("ratamt");
        dtforgrid.Columns.Add("totalsgst");
        dtforgrid.Columns.Add("nertotalsgst");
        

        PostgresGetData data = new PostgresGetData();
        StringBuilder SelectQuery = new StringBuilder(@"select to_char(paymentdate,'DD/MM/YYYY') paydate,cfileid from compact_files where to_char(paymentdate,'DD/MM/YYYY')=@date and completed = 'Y'");

        NpgsqlCommand SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
        SelectCmd.Parameters.AddWithValue("@date", date);
        DataTable dt = data.GetDataTable(SelectCmd, "nfs");
        if (dt.Rows.Count > 0)
        {
            string paydate = dt.Rows[0]["paydate"].ToString();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                decimal totalsgst = 0;

                SelectQuery = new StringBuilder(@"select   to_char(mc.insertdatetime,'DD/MM/YYYY') date, COALESCE(sum(sgst_total),'0.00') total,COALESCE(sum(sgst_tax),'0.00') tax,COALESCE(sum(sgst_intr),'0.00') intr,COALESCE(sum(sgst_fee),'0.00') fee,COALESCE(sum(sgst_pnlty),'0.00') pnlty,COALESCE(sum(sgst_oth),'0.00') oth,banktype from moe_compact mc 
                                                            
                                                    inner join transactions_eod_cin tec on tec.cin=mc.cin
                                                    inner join master_gstn_banks mb on mb.bankcode=tec.bank_cd
                                                    where compactfileid=@cfileid
                                                    group by banktype,to_char(mc.insertdatetime,'DD/MM/YYYY')");

                SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
                SelectCmd.Parameters.AddWithValue("@cfileid", dt.Rows[i]["cfileid"].ToString());
                DataTable dtnew = data.GetDataTable(SelectCmd, "nfs");
                if (dtnew.Rows.Count > 0)
                {
                    DataRow dr = dtforgrid.NewRow();
                    dr["date"] = dtnew.Rows[0]["date"];
                    dr["paydate"] = paydate;
                    dr["amtpsb"] = defval;
                    dr["psbtax"] = defval;
                    dr["psbintr"] = defval;
                    dr["psbfee"] = defval;
                    dr["psbpnlty"] = defval;
                    dr["psboth"] = defval;
                    dr["amtpvt"] = defval;
                    dr["pvttax"] = defval;
                    dr["pvtintr"] = defval;
                    dr["pvtfee"] = defval;
                    dr["pvtpnlty"] = defval;
                    dr["pvtoth"] = defval;
                    dr["amtner"] = defval;
                    dr["nertax"] = defval;
                    dr["nerintr"] = defval;
                    dr["nerfee"] = defval;
                    dr["nerpnlty"] = defval;
                    dr["neroth"] = defval;
                    dr["ratamt"] = defval;
                    dr["totalsgst"] = defval;
                    dr["nertotalsgst"] = defval;



                    for (int j = 0; j < dtnew.Rows.Count; j++)
                    {
                            
                        if (dtnew.Rows[j]["banktype"].ToString() == "G")
                        {
                            dr["amtpsb"] = dtnew.Rows[j]["total"];
                            dr["psbtax"] = dtnew.Rows[j]["tax"];
                            dr["psbintr"] = dtnew.Rows[j]["intr"];
                            dr["psbfee"] = dtnew.Rows[j]["fee"];
                            dr["psbpnlty"] = dtnew.Rows[j]["pnlty"];
                            dr["psboth"] = dtnew.Rows[j]["oth"];

                            totalsgst = totalsgst + Convert.ToDecimal(dtnew.Rows[j]["total"]);
                           
                        }
                        else if (dtnew.Rows[j]["banktype"].ToString() == "P")
                        {
                            dr["amtpvt"] = dtnew.Rows[j]["total"];
                            dr["pvttax"] = dtnew.Rows[j]["tax"];
                            dr["pvtintr"] = dtnew.Rows[j]["intr"];
                            dr["pvtfee"] = dtnew.Rows[j]["fee"];
                            dr["pvtpnlty"] = dtnew.Rows[j]["pnlty"];
                            dr["pvtoth"] = dtnew.Rows[j]["oth"];

                            totalsgst = totalsgst + Convert.ToDecimal(dtnew.Rows[j]["total"]);
                            
                        }
                        else
                        {
                            dr["amtner"] = dtnew.Rows[j]["total"];
                            dr["nertax"] = dtnew.Rows[j]["tax"];
                            dr["nerintr"] = dtnew.Rows[j]["intr"];
                            dr["nerfee"] = dtnew.Rows[j]["fee"];
                            dr["nerpnlty"] = dtnew.Rows[j]["pnlty"];
                            dr["neroth"] = dtnew.Rows[j]["oth"];

                            dr["nertotalsgst"] = dtnew.Rows[j]["total"];

                            totalsgst = totalsgst + Convert.ToDecimal(dtnew.Rows[j]["total"]);
                            
                        }

                        
                    }

                    dr["totalsgst"] =totalsgst.ToString("F2");

                    SelectQuery = new StringBuilder(@"select COALESCE(sum(totaltxnamt),'0.00') rbitotalamt from rbi_response_txns_details where cin not in (select cin from moe_compact  where compactfileid=@cfileid) and  to_char(paymentdatetime,'DD/MM/YYYY')=@date ");
                    SelectCmd = new NpgsqlCommand(SelectQuery.ToString());
                    SelectCmd.Parameters.AddWithValue("@cfileid", dt.Rows[i]["cfileid"].ToString());
                    SelectCmd.Parameters.AddWithValue("@date", date);
                    DataTable dtrbi = data.GetDataTable(SelectCmd, "nfs");

                    if (dtrbi.Rows.Count > 0)
                    {
                        dr["ratamt"] = dtrbi.Rows[0]["rbitotalamt"].ToString();
                    }

                    dtforgrid.Rows.Add(dr);
                }
                
            }

        }
    }
    protected void btnshowdata_Click(object sender, EventArgs e)
    {
        string date = txtdate.Text;
        chckrecords(date);

        
    }
}