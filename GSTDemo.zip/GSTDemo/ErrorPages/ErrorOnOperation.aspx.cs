using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class ErrorOnOperation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Session.Abandon();
        Session.RemoveAll();
        Session.Clear();
        FormsAuthentication.SignOut();
     }
    //protected void Btn_onclick(object sender, EventArgs e)
    //{
    //    Session.Abandon();
    //    Session.RemoveAll();

    //    FormsAuthentication.SignOut();

    //    string nextpage = ResolveClientUrl("~/Login.aspx");

    //    string WriteFunction = @"";
    //    WriteFunction = WriteFunction + " var Backlen=history.length;";
    //    WriteFunction = WriteFunction + " history.go(-Backlen);";
    //    WriteFunction = WriteFunction + " window.location.href='" + nextpage + "';";

    //    string myScript = WriteFunction;// +" ClearHistoryData();";
    //    this.Page.ClientScript.RegisterStartupScript(this.GetType(), "MyScript", myScript, true);
    //}
}
